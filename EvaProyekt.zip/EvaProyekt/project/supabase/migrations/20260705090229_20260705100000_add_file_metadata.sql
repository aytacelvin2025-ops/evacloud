/*
# Add File Metadata Fields

## Summary
Adds metadata fields to files table for tracking:
- Last accessed time
- Device info at upload
- Width/Height for images/videos
- Duration for audio/videos
*/

ALTER TABLE files ADD COLUMN IF NOT EXISTS last_accessed_at timestamptz;
ALTER TABLE files ADD COLUMN IF NOT EXISTS uploaded_from_device text;
ALTER TABLE files ADD COLUMN IF NOT EXISTS width integer;
ALTER TABLE files ADD COLUMN IF NOT EXISTS height integer;
ALTER TABLE files ADD COLUMN IF NOT EXISTS duration_seconds integer;
ALTER TABLE files ADD COLUMN IF NOT EXISTS access_count integer DEFAULT 0;