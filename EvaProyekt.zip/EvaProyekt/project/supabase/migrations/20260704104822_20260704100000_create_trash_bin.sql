/*
# Create Trash Bin Table + Auto-Cleanup Settings

## Summary
Adds a `trash_bin` table for soft-deleted files.
Adds trash auto-cleanup settings to user_preferences.

## New Tables

### trash_bin
Tracks soft-deleted files with:
- Same columns as files + deleted_at timestamp + original_file_id
- Files are moved here on "delete", can be restored or permanently deleted

## Modified Tables

### user_preferences
- trash_auto_cleanup_days integer -- 0 = never, 30 = 30 days, 60 = 60 days, etc.
*/

-- Create trash_bin table
CREATE TABLE IF NOT EXISTS trash_bin (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  original_file_id uuid NOT NULL,
  name text NOT NULL,
  size bigint NOT NULL DEFAULT 0,
  mime_type text NOT NULL DEFAULT 'application/octet-stream',
  category text NOT NULL DEFAULT 'other'
    CHECK (category IN ('photos', 'videos', 'documents', 'music', 'other')),
  storage_path text NOT NULL,
  storage_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_trash_bin_user_id ON trash_bin(user_id);
CREATE INDEX IF NOT EXISTS idx_trash_bin_deleted_at ON trash_bin(user_id, deleted_at DESC);

-- RLS
ALTER TABLE trash_bin ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_trash" ON trash_bin;
CREATE POLICY "select_own_trash" ON trash_bin FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_trash" ON trash_bin;
CREATE POLICY "insert_own_trash" ON trash_bin FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_trash" ON trash_bin;
CREATE POLICY "delete_own_trash" ON trash_bin FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Add trash auto-cleanup setting to user_preferences
ALTER TABLE user_preferences ADD COLUMN IF NOT EXISTS trash_auto_cleanup_days integer DEFAULT 30;

-- Function to auto-cleanup old trash items (can be called via cron or manually)
CREATE OR REPLACE FUNCTION cleanup_old_trash()
RETURNS void AS $$
DECLARE
  user_record RECORD;
  cutoff_date timestamptz;
BEGIN
  FOR user_record IN SELECT id, 
    COALESCE(
      (SELECT trash_auto_cleanup_days FROM user_preferences WHERE user_id = id),
      30
    ) as cleanup_days
    FROM auth.users
  LOOP
    IF user_record.cleanup_days > 0 THEN
      cutoff_date := now() - (user_record.cleanup_days || ' days')::interval;
      DELETE FROM trash_bin 
      WHERE user_id = user_record.id 
      AND deleted_at < cutoff_date;
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;