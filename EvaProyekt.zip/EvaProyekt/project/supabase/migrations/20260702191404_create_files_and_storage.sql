/*
# Create Files Table + Storage Setup

## Summary
Adds a `files` table to track every file a user uploads through EVA Cloud X.
Enables Supabase Storage with a user-files bucket (per-user folders).
Updates the profiles table with storage_used / storage_limit columns so the 
dashboard shows accurate numbers.

## New Tables

### files
Tracks every uploaded file with:
- `id` — UUID primary key
- `user_id` — owner (defaults to auth.uid(), FK to auth.users)
- `name` — original filename shown in UI
- `size` — file size in bytes
- `mime_type` — MIME type (image/jpeg, application/pdf, etc.)
- `category` — one of: photos, videos, documents, music, other
- `storage_path` — Supabase Storage object path for retrieval
- `storage_url` — public or signed URL for display
- `created_at` — upload timestamp

## Modified Tables

### profiles
- `storage_used` bigint — bytes currently used (updated on upload/delete)
- `storage_limit` bigint — plan limit in bytes (default 10 GB)

## Security

- RLS enabled on `files`, policies scoped to `authenticated` (owner-only).
- `user_id` defaults to `auth.uid()` so inserts without user_id still pass RLS.
*/

-- Add storage columns to profiles if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'storage_used'
  ) THEN
    ALTER TABLE profiles ADD COLUMN storage_used bigint NOT NULL DEFAULT 0;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'storage_limit'
  ) THEN
    ALTER TABLE profiles ADD COLUMN storage_limit bigint NOT NULL DEFAULT 10737418240;
  END IF;
END $$;

-- Create files table
CREATE TABLE IF NOT EXISTS files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  size bigint NOT NULL DEFAULT 0,
  mime_type text NOT NULL DEFAULT 'application/octet-stream',
  category text NOT NULL DEFAULT 'other'
    CHECK (category IN ('photos', 'videos', 'documents', 'music', 'other')),
  storage_path text NOT NULL,
  storage_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_files_user_id ON files(user_id);
CREATE INDEX IF NOT EXISTS idx_files_category ON files(user_id, category);
CREATE INDEX IF NOT EXISTS idx_files_created_at ON files(user_id, created_at DESC);

-- RLS
ALTER TABLE files ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_files" ON files;
CREATE POLICY "select_own_files" ON files FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_files" ON files;
CREATE POLICY "insert_own_files" ON files FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_files" ON files;
CREATE POLICY "update_own_files" ON files FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_files" ON files;
CREATE POLICY "delete_own_files" ON files FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Function to keep storage_used in sync on files table changes
CREATE OR REPLACE FUNCTION update_profile_storage_used()
RETURNS trigger AS $$
DECLARE
  total bigint;
BEGIN
  IF TG_OP = 'DELETE' THEN
    SELECT COALESCE(SUM(size), 0) INTO total FROM files WHERE user_id = OLD.user_id;
    UPDATE profiles SET storage_used = total WHERE id = OLD.user_id;
  ELSE
    SELECT COALESCE(SUM(size), 0) INTO total FROM files WHERE user_id = NEW.user_id;
    UPDATE profiles SET storage_used = total WHERE id = NEW.user_id;
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_update_storage_used ON files;
CREATE TRIGGER trg_update_storage_used
  AFTER INSERT OR UPDATE OR DELETE ON files
  FOR EACH ROW EXECUTE FUNCTION update_profile_storage_used();
