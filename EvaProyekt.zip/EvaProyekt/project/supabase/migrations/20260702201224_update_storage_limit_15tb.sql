/*
# Update Storage Limit to 15 TB

Changes the default storage_limit on all new and existing profiles to 15 TB.
15 TB = 16,492,674,416,640 bytes.
*/

ALTER TABLE profiles
  ALTER COLUMN storage_limit SET DEFAULT 16492674416640;

UPDATE profiles SET storage_limit = 16492674416640 WHERE storage_limit = 10737418240;
