CREATE TABLE IF NOT EXISTS user_preferences (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  -- Notification prefs
  notif_upload_complete boolean DEFAULT true,
  notif_auto_backup boolean DEFAULT true,
  notif_new_login boolean DEFAULT true,
  notif_security_alert boolean DEFAULT true,
  notif_storage_warning boolean DEFAULT true,
  notif_newsletter boolean DEFAULT false,
  -- Settings prefs
  auto_backup_enabled boolean DEFAULT false,
  wifi_only boolean DEFAULT true,
  backup_photos boolean DEFAULT true,
  backup_videos boolean DEFAULT false,
  backup_docs boolean DEFAULT true,
  camera_auto_upload boolean DEFAULT false,
  -- Timestamps
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_prefs" ON user_preferences FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "insert_own_prefs" ON user_preferences FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "update_own_prefs" ON user_preferences FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);