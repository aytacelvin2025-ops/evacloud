
/*
# Fix User Profile Trigger - Add Exception Handling

## Problem
The handle_new_user trigger was causing "Database error saving new user" when any error
occurred during profile insert (e.g., constraint violations, timing issues).

## Fix
Wrap the INSERT in a nested BEGIN/EXCEPTION block so trigger errors never block
user creation. If the profile insert fails for any reason, the user is still created
and the profile can be upserted manually afterward from the app.
*/

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  BEGIN
    INSERT INTO profiles (id, first_name, last_name, avatar_url)
    VALUES (
      NEW.id,
      COALESCE(NEW.raw_user_meta_data->>'first_name', ''),
      COALESCE(NEW.raw_user_meta_data->>'last_name', ''),
      NEW.raw_user_meta_data->>'avatar_url'
    )
    ON CONFLICT (id) DO UPDATE
      SET
        first_name = COALESCE(EXCLUDED.first_name, profiles.first_name),
        last_name  = COALESCE(EXCLUDED.last_name,  profiles.last_name),
        updated_at = now();
  EXCEPTION WHEN others THEN
    -- Never block user creation due to profile insert failure
    NULL;
  END;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
