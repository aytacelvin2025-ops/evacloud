/*
# Create user-files Storage Bucket + RLS Policies

Creates the Supabase Storage bucket for EVA Cloud X file uploads.
Each user gets a private folder scoped by their user ID.
Storage objects are private by default (bucket is not public).
*/

-- Create the bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('user-files', 'user-files', false, 52428800)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to upload to their own folder (user_id/filename)
DROP POLICY IF EXISTS "Users upload own files" ON storage.objects;
CREATE POLICY "Users upload own files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'user-files' AND
  (storage.foldername(name))[1] = (auth.uid())::text
);

-- Allow authenticated users to read their own files
DROP POLICY IF EXISTS "Users read own files" ON storage.objects;
CREATE POLICY "Users read own files"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'user-files' AND
  (storage.foldername(name))[1] = (auth.uid())::text
);

-- Allow authenticated users to delete their own files
DROP POLICY IF EXISTS "Users delete own files" ON storage.objects;
CREATE POLICY "Users delete own files"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'user-files' AND
  (storage.foldername(name))[1] = (auth.uid())::text
);
