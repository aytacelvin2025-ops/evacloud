-- Add is_favorited column to files table
ALTER TABLE files ADD COLUMN IF NOT EXISTS is_favorited BOOLEAN DEFAULT FALSE;

-- Create index for faster favorites queries
CREATE INDEX IF NOT EXISTS idx_files_favorited ON files(user_id, is_favorited) WHERE is_favorited = TRUE;
