CREATE TABLE IF NOT EXISTS user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  device_name text,
  browser text,
  platform text,
  ip_address text,
  country text,
  city text,
  last_active_at timestamptz NOT NULL DEFAULT now(),
  signed_in_at timestamptz NOT NULL DEFAULT now(),
  is_current boolean DEFAULT false
);

ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_sessions" ON user_sessions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "insert_own_sessions" ON user_sessions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "update_own_sessions" ON user_sessions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "delete_own_sessions" ON user_sessions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);