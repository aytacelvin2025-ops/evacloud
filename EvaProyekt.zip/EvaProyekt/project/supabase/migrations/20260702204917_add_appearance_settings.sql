ALTER TABLE user_preferences 
ADD COLUMN IF NOT EXISTS theme text DEFAULT 'dark',
ADD COLUMN IF NOT EXISTS accent_color text DEFAULT 'blue',
ADD COLUMN IF NOT EXISTS font_size text DEFAULT 'default';