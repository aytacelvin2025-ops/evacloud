
/*
# Create User Profiles Table

## Purpose
Stores extended profile information for authenticated users beyond what Supabase auth.users provides.

## New Tables
- `profiles`
  - `id` (uuid, primary key) — references auth.users(id), cascade delete
  - `first_name` (text) — user's first name
  - `last_name` (text) — user's last name
  - `username` (text, unique) — unique display handle
  - `avatar_url` (text) — profile picture URL
  - `storage_used` (bigint) — bytes used, default 0
  - `storage_limit` (bigint) — bytes allowed, default 10GB
  - `country` (text) — user's country
  - `phone` (text) — phone number
  - `onboarding_completed` (boolean) — whether onboarding was shown
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

## Security
- RLS enabled on profiles
- Authenticated users can only SELECT, INSERT, UPDATE their own row
- Auto-create profile on signup via trigger
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  first_name text,
  last_name text,
  username text UNIQUE,
  avatar_url text,
  storage_used bigint NOT NULL DEFAULT 0,
  storage_limit bigint NOT NULL DEFAULT 10737418240,
  country text,
  phone text,
  onboarding_completed boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO profiles (id, first_name, last_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'first_name',
    NEW.raw_user_meta_data->>'last_name',
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();
