export const colors = {
  background: '#000000',
  surface: 'rgba(255, 255, 255, 0.05)',
  surfaceMid: 'rgba(255, 255, 255, 0.08)',
  surfaceHigh: 'rgba(255, 255, 255, 0.12)',
  border: 'rgba(255, 255, 255, 0.10)',
  borderHigh: 'rgba(255, 255, 255, 0.18)',

  primary: '#1E6FFF',
  primaryLight: '#4D91FF',
  primaryDark: '#0A4FCC',

  secondary: '#00D4FF',
  secondaryLight: '#4DE0FF',

  accent: '#7B2FFF',
  accentLight: '#A066FF',

  success: '#34C759',
  warning: '#FF9F0A',
  error: '#FF3B30',

  text: '#FFFFFF',
  textSecondary: 'rgba(255, 255, 255, 0.6)',
  textTertiary: 'rgba(255, 255, 255, 0.35)',

  gradientBlue: ['#0A1628', '#000000'] as [string, string],
  gradientPrimary: ['#1E6FFF', '#00D4FF'] as [string, string],
  gradientAccent: ['#7B2FFF', '#1E6FFF'] as [string, string],
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
};

export const typography = {
  h1: { fontSize: 32, fontWeight: '700' as const, lineHeight: 38 },
  h2: { fontSize: 24, fontWeight: '700' as const, lineHeight: 29 },
  h3: { fontSize: 20, fontWeight: '600' as const, lineHeight: 24 },
  body: { fontSize: 16, fontWeight: '400' as const, lineHeight: 24 },
  bodySmall: { fontSize: 14, fontWeight: '400' as const, lineHeight: 21 },
  caption: { fontSize: 12, fontWeight: '400' as const, lineHeight: 18 },
  button: { fontSize: 16, fontWeight: '600' as const, lineHeight: 24 },
};
