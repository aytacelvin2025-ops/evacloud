import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { Platform } from 'react-native';
import { Session, User } from '@supabase/supabase-js';
import { supabase, Profile } from '@/lib/supabase';

function detectBrowser(): string {
  if (Platform.OS === 'ios') return 'iPhone App';
  if (Platform.OS === 'android') return 'Android App';
  if (typeof navigator === 'undefined') return 'Browser';
  const ua = navigator.userAgent;
  if (ua.includes('Edg/')) return 'Edge';
  if (ua.includes('Chrome')) return 'Chrome';
  if (ua.includes('Firefox')) return 'Firefox';
  if (ua.includes('Safari')) return 'Safari';
  return 'Browser';
}

function detectOS(): string {
  if (Platform.OS === 'ios') return 'iOS';
  if (Platform.OS === 'android') return 'Android';
  if (typeof navigator === 'undefined') return 'Unknown';
  const ua = navigator.userAgent;
  if (ua.includes('Windows NT 11')) return 'Windows 11';
  if (ua.includes('Windows NT 10')) return 'Windows 10';
  if (ua.includes('Windows')) return 'Windows';
  if (ua.includes('Mac OS X')) return 'macOS';
  if (ua.includes('Linux')) return 'Linux';
  if (ua.includes('iPhone') || ua.includes('iPad')) return 'iOS';
  if (ua.includes('Android')) return 'Android';
  return 'Unknown';
}

async function recordSession(userId: string) {
  // Run in background — don't block sign-in flow
  (async () => {
    try {
      const browser = detectBrowser();
      const os = detectOS();
      const deviceName = `${browser} · ${os}`;

      // Insert session first without IP (fast), update IP later
      const { data: sessionData } = await supabase.from('user_sessions').insert({
        user_id: userId,
        device_name: deviceName,
        browser,
        platform: os,
        ip_address: '',
        is_current: true,
        signed_in_at: new Date().toISOString(),
        last_active_at: new Date().toISOString(),
      }).select('id').single();

      // Mark old sessions as not current (non-blocking)
      supabase.from('user_sessions')
        .update({ is_current: false })
        .neq('id', sessionData?.id ?? '')
        .eq('user_id', userId)
        .then(() => {});

      // Fetch IP in background (non-blocking, 3s timeout)
      if (sessionData?.id) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 3000);
        try {
          const res = await fetch('https://api.ipify.org?format=json', { signal: controller.signal });
          const data = await res.json();
          clearTimeout(timeout);
          if (data.ip) {
            await supabase.from('user_sessions')
              .update({ ip_address: data.ip })
              .eq('id', sessionData.id);
          }
        } catch {
          clearTimeout(timeout);
          // IP fetch failed — session still recorded without IP
        }
      }
    } catch {
      // Session recording is non-critical
    }
  })();
}

type AuthContextType = {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType>({
  session: null,
  user: null,
  profile: null,
  loading: true,
  signOut: async () => {},
  refreshProfile: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const mounted = useRef(true);

  async function loadProfile(userId: string) {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();
      if (!error && mounted.current) {
        setProfile(data as Profile | null);
      }
    } catch {
      // Profile load failure is non-fatal; app still works without it
    }
  }

  async function refreshProfile() {
    const currentUser = (await supabase.auth.getUser()).data.user;
    if (currentUser) await loadProfile(currentUser.id);
  }

  useEffect(() => {
    mounted.current = true;

    // Timeout safety: resolve loading after 5s max to avoid stuck splash
    const loadingTimeout = setTimeout(() => {
      if (mounted.current) setLoading(false);
    }, 5000);

    supabase.auth.getSession().then(({ data: { session: s } }) => {
      if (!mounted.current) return;
      clearTimeout(loadingTimeout);
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) {
        loadProfile(s.user.id).finally(() => {
          if (mounted.current) setLoading(false);
        });
      } else {
        setLoading(false);
      }
    }).catch(() => {
      if (mounted.current) setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, s) => {
      (async () => {
        if (!mounted.current) return;
        setSession(s);
        setUser(s?.user ?? null);
        if (s?.user) {
          await loadProfile(s.user.id);
          if (event === 'SIGNED_IN') {
            recordSession(s.user.id);
          }
        } else {
          setProfile(null);
        }
        // Ensure loading is cleared after any auth event
        if (mounted.current) setLoading(false);
      })();
    });

    return () => {
      mounted.current = false;
      clearTimeout(loadingTimeout);
      subscription.unsubscribe();
    };
  }, []);

  async function signOut() {
    try {
      await supabase.auth.signOut();
    } catch {
      // Force clear local state even if network sign-out fails
      setSession(null);
      setUser(null);
      setProfile(null);
    }
  }

  return (
    <AuthContext.Provider value={{ session, user, profile, loading, signOut, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
