import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
  Dimensions,
  Animated,
  Easing,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  X, Minus, Maximize, Minimize, PictureInPicture2,
  ChevronLeft, Volume2,
} from 'lucide-react-native';
import { colors, spacing, radius, typography } from '@/constants/theme';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export type WindowMode = 'fullscreen' | 'windowed' | 'minimized' | 'pip';

type Props = {
  title: string;
  subtitle?: string;
  mode: WindowMode;
  onModeChange: (mode: WindowMode) => void;
  onClose: () => void;
  onBack?: () => void;
  accentColor?: string;
  children: React.ReactNode;
  minimizedContent?: React.ReactNode;
};

export function PlayerWindow({
  title,
  subtitle,
  mode,
  onModeChange,
  onClose,
  onBack,
  accentColor = colors.primary,
  children,
  minimizedContent,
}: Props) {
  const slideAnim = React.useRef(new Animated.Value(mode === 'minimized' ? 0 : 1)).current;

  React.useEffect(() => {
    Animated.timing(slideAnim, {
      toValue: mode === 'minimized' ? 0 : 1,
      duration: 300,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
  }, [mode]);

  // Minimized floating bar
  if (mode === 'minimized') {
    return (
      <View style={styles.minimizedContainer}>
        <LinearGradient colors={['#0A1628', '#050D1A']} style={StyleSheet.absoluteFill} />
        <TouchableOpacity
          style={styles.minimizedBar}
          onPress={() => onModeChange('windowed')}
          activeOpacity={0.9}
        >
          <View style={[styles.minimizedIcon, { backgroundColor: accentColor + '20' }]}>
            {minimizedContent ?? <Volume2 size={18} color={accentColor} strokeWidth={1.8} />}
          </View>
          <View style={styles.minimizedInfo}>
            <Text style={styles.minimizedTitle} numberOfLines={1}>{title}</Text>
            {subtitle ? <Text style={styles.minimizedSub} numberOfLines={1}>{subtitle}</Text> : null}
          </View>
          <View style={styles.minimizedControls}>
            <TouchableOpacity
              style={styles.minBtn}
              onPress={(e) => { e.stopPropagation?.(); onModeChange('pip'); }}
            >
              <PictureInPicture2 size={16} color={colors.textSecondary} strokeWidth={1.8} />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.minBtn}
              onPress={(e) => { e.stopPropagation?.(); onModeChange('fullscreen'); }}
            >
              <Maximize size={16} color={colors.textSecondary} strokeWidth={1.8} />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.minBtn, styles.minBtnClose]}
              onPress={(e) => { e.stopPropagation?.(); onClose(); }}
            >
              <X size={16} color={colors.error} strokeWidth={2} />
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </View>
    );
  }

  // PiP (picture-in-picture) floating window
  if (mode === 'pip') {
    return (
      <View style={styles.pipContainer}>
        <View style={styles.pipWindow}>
          <LinearGradient colors={['#0A1628', '#050D1A']} style={StyleSheet.absoluteFill} />
          <View style={styles.pipHeader}>
            <TouchableOpacity
              style={styles.pipBtn}
              onPress={() => onModeChange('windowed')}
            >
              <ChevronLeft size={16} color={colors.text} strokeWidth={2} />
            </TouchableOpacity>
            <Text style={styles.pipTitle} numberOfLines={1}>{title}</Text>
            <View style={styles.pipControls}>
              <TouchableOpacity
                style={styles.pipBtn}
                onPress={() => onModeChange('minimized')}
              >
                <Minus size={16} color={colors.textSecondary} strokeWidth={2} />
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.pipBtn}
                onPress={() => onModeChange('fullscreen')}
              >
                <Maximize size={16} color={colors.textSecondary} strokeWidth={1.8} />
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.pipBtn, styles.pipBtnClose]}
                onPress={onClose}
              >
                <X size={16} color={colors.error} strokeWidth={2} />
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.pipContent}>
            {children}
          </View>
        </View>
      </View>
    );
  }

  // Fullscreen or windowed mode
  const isFullscreen = mode === 'fullscreen';
  return (
    <View style={[styles.container, isFullscreen && styles.containerFullscreen]}>
      <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />

      {/* Title bar with window controls */}
      <View style={styles.titleBar}>
        <View style={styles.titleBarLeft}>
          {onBack && (
            <TouchableOpacity style={styles.titleBtn} onPress={onBack}>
              <ChevronLeft size={20} color={colors.text} strokeWidth={2} />
            </TouchableOpacity>
          )}
          <View style={styles.titleInfo}>
            <Text style={styles.titleText} numberOfLines={1}>{title}</Text>
            {subtitle ? <Text style={styles.subtitleText} numberOfLines={1}>{subtitle}</Text> : null}
          </View>
        </View>
        <View style={styles.windowControls}>
          <TouchableOpacity
            style={styles.windowBtn}
            onPress={() => onModeChange('minimized')}
          >
            <Minus size={16} color={colors.textSecondary} strokeWidth={2} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.windowBtn}
            onPress={() => onModeChange('pip')}
          >
            <PictureInPicture2 size={16} color={colors.textSecondary} strokeWidth={1.8} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.windowBtn}
            onPress={() => onModeChange(isFullscreen ? 'windowed' : 'fullscreen')}
          >
            {isFullscreen ? (
              <Minimize size={16} color={colors.textSecondary} strokeWidth={1.8} />
            ) : (
              <Maximize size={16} color={colors.textSecondary} strokeWidth={1.8} />
            )}
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.windowBtn, styles.windowBtnClose]}
            onPress={onClose}
          >
            <X size={16} color={colors.error} strokeWidth={2} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Content */}
      <View style={styles.content}>
        {children}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  containerFullscreen: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    zIndex: 9999,
  },
  titleBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: Platform.OS === 'ios' ? 52 : 40,
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(30,111,255,0.15)',
  },
  titleBarLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    flex: 1,
  },
  titleBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center', justifyContent: 'center',
  },
  titleInfo: { flex: 1 },
  titleText: { color: colors.text, fontSize: 16, fontWeight: '700' },
  subtitleText: { color: colors.textSecondary, fontSize: 12, marginTop: 2 },
  windowControls: {
    flexDirection: 'row',
    gap: 6,
  },
  windowBtn: {
    width: 34, height: 34, borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center', justifyContent: 'center',
  },
  windowBtnClose: {
    backgroundColor: 'rgba(255,59,48,0.12)',
  },
  content: { flex: 1 },
  // Minimized
  minimizedContainer: {
    position: 'absolute',
    bottom: Platform.OS === 'ios' ? 100 : 80,
    left: spacing.lg, right: spacing.lg,
    zIndex: 9999,
    borderRadius: radius.lg,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(30,111,255,0.25)',
  },
  minimizedBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: 10,
    paddingHorizontal: spacing.md,
  },
  minimizedIcon: {
    width: 40, height: 40, borderRadius: 12,
    alignItems: 'center', justifyContent: 'center',
  },
  minimizedInfo: { flex: 1 },
  minimizedTitle: { color: colors.text, fontSize: 13, fontWeight: '600' },
  minimizedSub: { color: colors.textTertiary, fontSize: 11, marginTop: 2 },
  minimizedControls: { flexDirection: 'row', gap: 4 },
  minBtn: {
    width: 32, height: 32, borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center', justifyContent: 'center',
  },
  minBtnClose: { backgroundColor: 'rgba(255,59,48,0.12)' },
  // PiP
  pipContainer: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 9999,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  pipWindow: {
    width: SCREEN_WIDTH * 0.85,
    maxWidth: 480,
    height: '70%',
    maxHeight: 500,
    borderRadius: radius.xl,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(30,111,255,0.3)',
  },
  pipHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(30,111,255,0.15)',
  },
  pipBtn: {
    width: 30, height: 30, borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center', justifyContent: 'center',
  },
  pipBtnClose: { backgroundColor: 'rgba(255,59,48,0.12)' },
  pipTitle: { color: colors.text, fontSize: 13, fontWeight: '600', flex: 1, marginLeft: spacing.sm },
  pipControls: { flexDirection: 'row', gap: 4 },
  pipContent: { flex: 1 },
});
