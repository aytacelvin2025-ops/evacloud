import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Animated,
  TextInput, ScrollView, Platform, Image, Dimensions,
  KeyboardAvoidingView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  X, Send, HardDrive, Shield, User, Home, ChevronRight,
  ArrowLeft, Trash2, Edit3, RotateCcw, Copy, Check,
  Bot, Heart, Star, Film, Image as ImageIcon, Music,
  FileText, Search, Download, Share2, Lock, Bell, Globe,
} from 'lucide-react-native';
import { router } from 'expo-router';
import { colors, spacing, radius } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import { listFiles, getFileStats, formatBytes } from '@/lib/files';
import { useLanguage } from '@/context/LanguageContext';

const EVA_LOGO = require('../assets/images/eva-logo.png');
const WIN = Dimensions.get('window');

type Message = {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  action?: { label: string; route: string };
  timestamp?: Date;
};

const COMMAND_SUGGESTIONS = [
  { icon: Home, label: 'Ana Səhifə', cmd: 'ana səhifə' },
  { icon: HardDrive, label: 'Yaddaş', cmd: 'yaddaş vəziyyəti' },
  { icon: ImageIcon, label: 'Şəkillərim', cmd: 'şəkillərim' },
  { icon: Film, label: 'Videolarım', cmd: 'videolarım' },
  { icon: Heart, label: 'Sevimlilər', cmd: 'sevimlilərim' },
  { icon: Shield, label: 'Təhlükəsizlik', cmd: 'təhlükəsizlik' },
  { icon: Trash2, label: 'Zibil', cmd: 'zibil qutusu' },
  { icon: User, label: 'Profil', cmd: 'profilim' },
  { icon: Download, label: 'Yüklə', cmd: 'fayl yüklə' },
  { icon: Search, label: 'Axtar', cmd: 'fayl axtar' },
];

const EVA_GREETING = `Salam! Mən EVA AI-yəm. 🤖✨

Yeni nəsil yapay zəka köməkçisiyəm — Gemini və ChatGPT drayvrləri əsaslı. İnsan kimi danışır, hər şeyi bilirəm!

Bacarıqlarım:
📁 Fayl və yaddaş idarəetməsi
🔒 Təhlükəsizlik və məxfilik
📊 Statistika və analiz
📤 Yükləmə və endirmə köməyi
🎨 Dizayn və istifadəçi təcrübəsi
💡 Ümumi suallar və məsləhətlər
ℹ️ Proqram və yaradıcı haqqında

Nə istəsəniz soruşun — hər şeyi cavablaya bilərəm! 😊`;

async function buildResponse(
  input: string,
  userId: string,
  t: (k: string) => string
): Promise<{ text: string; action?: { label: string; route: string } }> {
  const q = input.toLowerCase().trim();
  const isAz = !/^[a-z\s]+$/i.test(q) || /[əöüğışçə]/i.test(q);

  // Navigation
  if (/\b(home|ana|əsas|başlanğıc|baş səhifə)\b/.test(q))
    return {
      text: 'Ana səhifəyə gedirəm. 🏠\n\nOrada son fayllarınızı, yaddaş istifadənizi və sürətli əməliyyatları görə bilərsiniz.',
      action: { label: 'Ana Səhifəyə Get', route: '/(tabs)/' },
    };

  if (/\b(yaddaş vəziyyəti|storage status|bulud yaddaş)\b/.test(q)) {
    try {
      const stats = await getFileStats(userId);
      return {
        text: `Yaddaş Vəziyyəti 💾:\n\n📷 Şəkillər: ${stats.by_category.photos.count} fayl (${formatBytes(stats.by_category.photos.size)})\n🎬 Videolar: ${stats.by_category.videos.count} fayl (${formatBytes(stats.by_category.videos.size)})\n🎵 Musiqi: ${stats.by_category.music.count} fayl (${formatBytes(stats.by_category.music.size)})\n📄 Sənədlər: ${stats.by_category.documents.count} fayl (${formatBytes(stats.by_category.documents.size)})\n\n✅ Cəmi: ${stats.total_count} fayl, ${formatBytes(stats.total_size)}`,
        action: { label: 'Yaddaşa Bax', route: '/(tabs)/storage' },
      };
    } catch {
      return { text: 'Yaddaş məlumatları yüklənə bilmədi.', action: { label: 'Yaddaş', route: '/(tabs)/storage' } };
    }
  }

  if (/\b(yaddaş|storage|fayl|cloud|bulud)\b/.test(q) && !/vəziyyəti|status/.test(q))
    return { text: 'Yaddaş bölməsinə gedirəm. ☁️\n\nOrada bütün fayllarınızı kateqoriyalara görə idarə edə bilərsiniz: şəkillər, videolar, musiqi, sənədlər.', action: { label: 'Yaddaş', route: '/(tabs)/storage' } };

  if (/\b(security|təhlükəsizlik|password|şifrə|hesab|mühafizə|giriş|session)\b/.test(q))
    return {
      text: 'Təhlükəsizlik mərkəzinə gedirəm. 🔒\n\nOrada:\n• Aktiv sessiyaları idarə edə bilərsiniz\n• Şifrənizi dəyişə bilərsiniz\n• İki faktorlu doğrulamanı aktivləşdirə bilərsiniz\n• Təhlükəsizlik statusunuzu yoxlaya bilərsiniz',
      action: { label: 'Təhlükəsizlik', route: '/(tabs)/security' },
    };

  if (/\b(profile|profil|settings|tənzim|ayarlar|hesab)\b/.test(q))
    return {
      text: 'Profil bölməsinə gedirəm. 👤\n\nOrada:\n• Profili redaktə edə bilərsiniz\n• Dil seçimini dəyişə bilərsiniz (AZ/EN)\n• Görünüşü tənzimləyə bilərsiniz (dark/light)\n• Bildiriş ayarlarını idarə edə bilərsiniz',
      action: { label: 'Profil', route: '/(tabs)/profile' },
    };

  if (/\b(zibil|trash|çöp|silinmiş)\b/.test(q))
    return {
      text: 'Zibil qutusuna gedirəm. 🗑️\n\nZibil qutusunda:\n• Silinmiş faylları bərpa edə bilərsiniz\n• Birdəfəlik silə bilərsiniz\n• Avtomatik silinmə müddəti ayarlaya bilərsiniz (30/60/90 gün)',
      action: { label: 'Zibil Qutusu', route: '/(tabs)/trash' },
    };

  // Favorites
  if (/\b(sevimli|favorite|bəyən|like|ürək)\b/.test(q)) {
    try {
      const files = await listFiles(userId);
      const favs = files.filter(f => f.is_favorited);
      if (favs.length === 0) {
        return {
          text: 'Hələ sevimlilər yoxdur. ❤️\n\nFayl sevimlilərə əlavə etmək üçün:\n• Şəkil/video üzərinde ⋮ düyməsinə basın → "Sevimlilərə Əlavə Et"\n• Siyahı görünüşündə ❤️ düyməsinə basın',
          action: { label: 'Yaddaş', route: '/(tabs)/storage' },
        };
      }
      return {
        text: `${favs.length} sevimli faylınız var. ❤️\n\n${favs.slice(0, 5).map(f => `• ${f.name}`).join('\n')}${favs.length > 5 ? `\n• və ${favs.length - 5} fayl daha...` : ''}`,
        action: { label: 'Sevimlilərə Bax', route: '/(tabs)/storage' },
      };
    } catch {
      return { text: 'Sevimli fayllar yüklənə bilmədi.' };
    }
  }

  // Photos
  if (/\b(şəkil|photo|image|foto|şəkillərim)\b/.test(q)) {
    try {
      const files = await listFiles(userId, 'photos');
      if (files.length === 0) {
        return {
          text: 'Hələ şəkil yoxdur. 📷\n\nŞəkil yükləmək üçün:\n1. "Yaddaş" bölməsinə keçin\n2. "Fayl Yüklə" düyməsinə basın\n3. Şəkilləri seçin\n\nYüklənən şəkillər avtomatik kateqoriyaya ayrılır və şəbəkə görünüşündə nümayiş olunur.',
          action: { label: 'Şəkil Yüklə', route: '/(tabs)/storage' },
        };
      }
      const total = formatBytes(files.reduce((s, f) => s + f.size, 0));
      return {
        text: `📷 ${files.length} şəkliniz var, cəmi ${total}.\n\nSon yüklənən: "${files[0].name}"\nTarix: ${new Date(files[0].created_at).toLocaleDateString('az-AZ')}\n\nŞəkilləri görmək üçün "Yaddaş → Şəkillər" bölməsinə keçin. Hər şəkilə toxunaraq tam ekranda baxa, endirə və paylaşa bilərsiniz.`,
        action: { label: 'Şəkilləri Aç', route: '/(tabs)/storage' },
      };
    } catch {
      return { text: 'Şəkillər yüklənə bilmədi.' };
    }
  }

  // Videos
  if (/\b(video|vidyo|videolarım)\b/.test(q)) {
    try {
      const files = await listFiles(userId, 'videos');
      if (files.length === 0) {
        return {
          text: 'Hələ video yoxdur. 🎬\n\nVideo yükləmək üçün "Fayl Yüklə" düyməsinə basın. MP4, WebM, MOV və digər formatlar dəstəklənir.',
          action: { label: 'Video Yüklə', route: '/(tabs)/storage' },
        };
      }
      const total = formatBytes(files.reduce((s, f) => s + f.size, 0));
      return {
        text: `🎬 ${files.length} videounuz var, cəmi ${total}.\n\n"Yaddaş → Videolar" bölməsindən baxın. Hər videonun üz qabığı (thumbnail) avtomatik yaradılır. Videoya toxunaraq tam ekranda oynada, endirə və paylaşa bilərsiniz.`,
        action: { label: 'Videoları Aç', route: '/(tabs)/storage' },
      };
    } catch {
      return { text: 'Videolar yüklənə bilmədi.' };
    }
  }

  // Music
  if (/\b(musiqi|music|audio|mahnı|muzika)\b/.test(q)) {
    try {
      const files = await listFiles(userId, 'music');
      if (files.length === 0)
        return { text: 'Hələ musiqi yoxdur. 🎵 "Fayl Yüklə" ilə musiqi faylı əlavə edin. MP3, WAV, OGG, FLAC və M4A formatları dəstəklənir.', action: { label: 'Musiqi Yüklə', route: '/(tabs)/storage' } };
      return {
        text: `🎵 ${files.length} musiqi faylınız var (${formatBytes(files.reduce((s, f) => s + f.size, 0))}).\n\n"Yaddaş → Musiqi" bölməsindən dinləyə bilərsiniz. Daxili musiqi pleyerdə oynatma, fasilə, irəli/geri və səs səviyyəsi idarəeti mövcuddur.`,
        action: { label: 'Musiqiyə Bax', route: '/(tabs)/storage' },
      };
    } catch {
      return { text: 'Musiqi faylları yüklənə bilmədi.' };
    }
  }

  // Documents
  if (/\b(sənəd|document|doc|pdf|word|excel|fayl)\b/.test(q)) {
    try {
      const files = await listFiles(userId, 'documents');
      if (files.length === 0)
        return { text: 'Hələ sənəd yoxdur. 📄 PDF, Word, Excel, PowerPoint faylları yükləyə bilərsiniz. Sənədlər brauzerdə birbaşa görünə bilir.', action: { label: 'Sənəd Yüklə', route: '/(tabs)/storage' } };
      return {
        text: `📄 ${files.length} sənədiniz var (${formatBytes(files.reduce((s, f) => s + f.size, 0))}).\n\nSon: "${files[0].name}"\n\nSənədləri "Yaddaş → Sənədlər" bölməsindən açıb oxuya bilərsiniz. PDF faylları daxili pleyerdə, Word/Excel isə Google Docs Viewer vasitəsilə nümayiş olunur.`,
        action: { label: 'Sənədlərə Bax', route: '/(tabs)/storage' },
      };
    } catch {
      return { text: 'Sənədlər yüklənə bilmədi.' };
    }
  }

  // Full stats
  if (/\b(stat|neçə|nə qədər|how many|size|ölçü|cəmi|ümumi|hamısı)\b/.test(q)) {
    try {
      const stats = await getFileStats(userId);
      return {
        text: `📊 Ümumi Statistika:\n\n📷 ${stats.by_category.photos.count} şəkil — ${formatBytes(stats.by_category.photos.size)}\n🎬 ${stats.by_category.videos.count} video — ${formatBytes(stats.by_category.videos.size)}\n🎵 ${stats.by_category.music.count} musiqi — ${formatBytes(stats.by_category.music.size)}\n📄 ${stats.by_category.documents.count} sənəd — ${formatBytes(stats.by_category.documents.size)}\n📁 ${stats.by_category.other.count} digər — ${formatBytes(stats.by_category.other.size)}\n\n💾 Cəmi: ${stats.total_count} fayl, ${formatBytes(stats.total_size)}`,
        action: { label: 'Yaddaşa Bax', route: '/(tabs)/storage' },
      };
    } catch {
      return { text: 'Statistika yüklənə bilmədi.' };
    }
  }

  // Upload
  if (/\b(upload|yüklə|əlavə et|fayl yüklə)\b/.test(q))
    return {
      text: 'Fayl yükləmək üçün: 📤\n\n1. "Yaddaş" bölməsinə keçin\n2. "Fayl Yüklə" düyməsinə basın\n3. Şəkil, video, musiqi, sənəd seçin\n\n⚙️ Şəbəkə parametrini "Yalnız Wi-Fi" və ya "Mobil internet + Wi-Fi" kimi tənzimləyə bilərsiniz.\n\n🔒 Bütün fayllar yüklənmədən əvvəl AES-256 ilə şifrələnir.',
      action: { label: 'Yaddaş', route: '/(tabs)/storage' },
    };

  // Delete
  if (/\b(sil|delete|zibil at)\b/.test(q))
    return {
      text: 'Fayl silmək üçün: 🗑️\n\n📱 Şəbəkə görünüşündə:\n• Fayl üzərində ⋮ (üç nöqtə) düyməsinə basın\n• "Zibilə At" seçin\n\n📋 Siyahı görünüşündə:\n• Sağdakı 🗑️ düyməsinə basın\n\n✅ Toplu silmə:\n• "Seç" düyməsinə basın → Faylları seçin → "Sil"\n\nℹ️ Silinmiş fayllar 30/60/90 gün ərzində zibil qutusunda saxlanılır və bərpa edilə bilər.',
      action: { label: 'Yaddaş', route: '/(tabs)/storage' },
    };

  // Download - enhanced
  if (/\b(endir|download|telefona|geri yüklə|yukle|save)\b/.test(q))
    return {
      text: 'Fayl endirmək üçün: ⬇️\n\n• Siyahı görünüşündə faylın yanında ⬇️ düyməsinə basın\n• Şəbəkə görünüşündə ⋮ → "Yüklə (Endir)"\n• Faylı açıb "Yüklə" düyməsindən istifadə edin\n\n✨ Yeni xüsusiyyətlər:\n• Avtomatik format düzəlişi — fayl adına doğru uzantı əlavə olunur\n• Endirmə prosesi zamanı faiz göstəricisi\n• Toplu endirmə — birdən çox fayl seçib endirin\n• Fayl telefonun yaddaşına birbaşa yüklənir\n\nEndirilən fayllar cihazınızın "Endirilənlər" qovluğunda görünəcək.',
      action: { label: 'Yaddaş', route: '/(tabs)/storage' },
    };

  // Share
  if (/\b(paylaş|share)\b/.test(q))
    return {
      text: 'Fayl paylaşmaq üçün: 📤\n\n1. "Seç" düyməsinə basın\n2. Paylaşmaq istədiyiniz faylları seçin\n3. "Paylaş" düyməsinə basın\n\nPaylaşma linki yaradılır və istədiyiniz yerə göndərə bilərsiniz.',
      action: { label: 'Yaddaş', route: '/(tabs)/storage' },
    };

  // Search
  if (/\b(axtar|search|tap|find)\b/.test(q))
    return {
      text: 'Fayl axtarmaq üçün: 🔍\n\nYaddaş bölməsindəki 🔍 (böyüdücü şüşə) düyməsinə basın və fayl adını yazın. Nəticələr anlık filtrlənir.\n\n💡 İpucu: Axtarış fayl adına görə işləyir. Kateqoriyalara görə də filtrləyə bilərsiniz (Şəkillər, Videolar, Musiqi, Sənədlər).',
      action: { label: 'Yaddaş', route: '/(tabs)/storage' },
    };

  // Sort
  if (/\b(sırala|sort|tarix|ad|ölçü)\b/.test(q))
    return {
      text: 'Faylları sıralamaq üçün: ↕️\n\n"Yaddaş" bölməsindəki ↕️ düyməsinə basın:\n• Ən yeni → Ən köhnə\n• Ən köhnə → Ən yeni\n• Ad A → Z\n• Ad Z → A\n• Ən böyük → Ən kiçik\n• Ən kiçik → Ən böyük',
      action: { label: 'Yaddaş', route: '/(tabs)/storage' },
    };

  // Security advice
  if (/\b(təhlükə|danger|risk|xəbərdarlıq|hack|qoruma)\b/.test(q))
    return {
      text: 'Hesab Təhlükəsizliyi 🔐:\n\n✅ Tövsiyələr:\n• Güclü şifrə istifadə edin (minimum 8 simvol, rəqəm və simvol ilə)\n• Aktiv sessiyaları müntəzəm yoxlayın\n• Naməlum cihazları bloklayın\n• İki faktorlu doğrulamanı aktivləşdirin\n• Şifrənizi heç kimlə paylaşmayın\n\n⚠️ Şübhəli fəaliyyət görsəniz dərhal "Bütün Sessiyalardan Çıx" edin və şifrənizi dəyişin.\n\n🔒 EVA Cloud X-də bütün fayllar AES-256 ilə şifrələnir. Heç kəs fayllarınıza daxil ola bilmir.',
      action: { label: 'Təhlükəsizlik', route: '/(tabs)/security' },
    };

  // WiFi settings
  if (/\b(wifi|wi-fi|şəbəkə|mobil internet|data)\b/.test(q))
    return {
      text: 'Şəbəkə Parametrləri 📶:\n\nYaddaş bölməsindəki "Yalnız Wi-Fi / İstənilən Şəbəkə" düyməsindən:\n• Yalnız Wi-Fi: Mobil datadan qənaət\n• İstənilən Şəbəkə: Wi-Fi + Mobil internet\n\nBu ayar faylların yüklənmə şəbəkəsini idarə edir.',
      action: { label: 'Yaddaş', route: '/(tabs)/storage' },
    };

  // About the app / creator
  if (/\b(haqqımızda|haqqinda|about|kim yaradib|kim yaratdı|yaradıcı|creator|kimin|əmək|app adı|programın adı|proqram|tətbiq|elvin|əliyev|eliyev|versiya|version|yeniləmə|update|changelog)\b/.test(q))
    return {
      text: `EVA Cloud X haqqında ℹ️\n\n📱 Proqram adı: EVA Cloud X v2.1.0\n👤 Yaradıcı və developer: Elvin Əliyev\n🎨 Dizayn: Elvin Əliyev\n🤖 Yapay Zəka: EVA AI (Gemini əsaslı)\n\n🆕 Son yenilənmə (08.07.2026):\n• Müasir endirmə sistemi (format düzəlişi, progress)\n• EVA AI 20+ yeni mövzu\n• Performans optimallaşdırması (2x sürət)\n• Yeniləmə Mərkəzi (versiya tarixi)\n\n📬 Əlaqə:\n• E-poçt: elvinaliyev11@gmail.com\n• WhatsApp: +994517571777\n\nŞikayət və yeniləmələr üçün bizimlə əlaqə saxlayın! 😊`,
      action: { label: 'Yeniləmələrə Bax', route: '/updates' },
    };

  // Contact info
  if (/\b(əlaqə|elaqe|contact|poçt|email|mail|whatsapp|telefon|nömrə|nomre|yardım|kömək|support|dəstək)\b/.test(q))
    return {
      text: `Əlaqə Məlumatları 📬\n\n📧 E-poçt: elvinaliyev11@gmail.com\n💬 WhatsApp: +994517571777\n\nİş saatları: 9:00 - 18:00 (AZT)\n\nŞikayət, təklif və ya yeniləmələr haqqında bizimlə əlaqə saxlaya bilərsiniz. Hər mesaj vacibdir! 😊\n\nWhatsApp düyməsinə toxunduqda birbaşa söhbət açılır.`,
      action: { label: 'Yardım Səhifəsi', route: '/help' },
    };

  // Who are you / AI identity
  if (/\b(sən kim|sen kim|who are you|sən nə|nə sən|ai|yapay|süni|intellekt|zeka|necə işləyirsən|necə isleyirsen|hardan|mən sən|men sen)\b/.test(q))
    return {
      text: `Mən EVA AI-yəm! 🤖✨\n\nEVA Cloud X-in süni intellekt köməkçisiyəm. Gemini və ChatGPT drayvrlərinə əsaslanan yeni nəsil yapay zəka sistemiyəm.\n\nBacarıqlarım:\n• 📁 Fayl və yaddaş idarəetməsi\n• 🔒 Təhlükəsizlik məsləhətləri\n• 📊 Statistika və analiz\n• 💬 Tam insan kimi danışma\n• 🧠 Hər şeyi bilmək və cavablamaq\n• 🎨 Dizayn və istifadəçi təcrübəsi məsləhəti\n• 📤 Yükləmə və endirmə köməyi\n\nSual verin, cavablayım! 😊`,
    };

  // Language settings
  if (/\b(dil|language|azərbaycan|english|ingilis|dilini|dil dəyiş)\b/.test(q))
    return {
      text: 'Dil Parametrləri 🌐\n\nProqram iki dildə işləyir:\n• 🇦🇿 Azərbaycan dili\n• 🇬🇧 English\n\nDili dəyişmək üçün:\n1. "Profil" bölməsinə keçin\n2. "Dil" bölməsini seçin\n3. İstədiyiniz dili seçin\n\nBütün interfeys dərhal seçilmiş dilə keçir.',
      action: { label: 'Dil Seçimi', route: '/language' },
    };

  // Appearance / theme
  if (/\b(görünüş|theme|tema|dark|light|qara|ağ|rəng|appearance|fon)\b/.test(q))
    return {
      text: 'Görünüş Parametrləri 🎨\n\nProfil > Görünüş bölməsindən:\n• 🌙 Qara tema (defolt)\n• ☀️ Açıq tema\n• 🌌 Avtomatik (sistemə uyğun)\n\nHəmçinin vurğu rəngini dəyişə bilərsiniz: mavi, yaşıl, qırmızı və s.',
      action: { label: 'Görünüş', route: '/profile-appearance' },
    };

  // Notifications
  if (/\b(bildiriş|notification|push|xəbərdarlıq|alert)\b/.test(q))
    return {
      text: 'Bildiriş Parametrləri 🔔\n\nProfil > Bildirişlər bölməsindən:\n• Yükləmə tamamlananda bildiriş\n• Yeni cihaz girişində bildiriş\n• Yaddaş dolmağa yaxınlaşanda xəbərdarlıq\n• Təhlükəsizlik xəbərdarlıqları\n\nHər bildiriş növünü ayrıca açıb-bağlaya bilərsiniz.',
      action: { label: 'Bildirişlər', route: '/profile-notifications' },
    };

  // Subscription / pricing
  if (/\b(abonəlik|subscription|premium|pro|ödəniş|qiymət|plan|pulsuz)\b/.test(q))
    return {
      text: 'Abonəlik Planları 💎\n\n🆓 Pulsuz Plan:\n• 15 TB yaddaş\n• Bütün əsas funksiyalar\n• EVA AI köməkçisi\n\n💎 Premium Plan (yaxında):\n• Limitsiz yaddaş\n• Prioritet dəstək\n• Əlavə təhlükəsizlik xüsusiyyətləri\n\nHazırda bütün istifadəçilər üçün Pulsuz Plan aktivdir.',
      action: { label: 'Abonəlik', route: '/subscription' },
    };

  // Onboarding / getting started
  if (/\b(başlamaq|başla|start|begin|ilk|necə istifadə|təlimat|guide|getting started)\b/.test(q))
    return {
      text: 'EVA Cloud X-ə xoş gəlmisiniz! 👋\n\nTez başlamaq üçün:\n\n1️⃣ Qeydiyyatdan keçin və ya daxil olun\n2️⃣ "Yaddaş" bölməsinə keçin\n3️⃣ "Fayl Yüklə" ilə fayllarınızı yükləyin\n4️⃣ Şəkillər, videolar, musiqi və sənədləri idarə edin\n5️⃣ "Təhlükəsizlik" bölməsindən hesabınızı qoruyun\n\n💡 İpucu: EVA AI-yə (sağ alt küncdəki düymə) hər şeyi soruşa bilərsiniz!',
      action: { label: 'Yaddaş', route: '/(tabs)/storage' },
    };

  // Encryption / privacy
  if (/\b(şifrələmə|encrypt|encryption|məxfilik|privacy|AES|təhlükəsiz|secure)\b/.test(q))
    return {
      text: 'Məxfilik və Şifrələmə 🔐\n\nEVA Cloud X-də məxfilik prioritetdir:\n\n🔒 AES-256 şifrələmə — bütün fayllar saxlanmadan əvvəl şifrələnir\n🔑 Açar idarəetməsi — şifrələmə açarları ayrıca saxlanılır\n🚫 Sıfır bilik — heç kəs fayllarınıza daxil ola bilmir\n📱 Cihaz səviyyəsində — şifrələmə cihazınızda baş verir\n\nFayllarınız yalnız sizin tərəfinizdən əlçatandır. EVA Cloud X işçiləri belə fayllarınıza daxil ola bilmir.',
      action: { label: 'Təhlükəsizlik', route: '/(tabs)/security' },
    };

  // Help
  if (/\b(necə|how|help|kömək|yardım|nə edir|əmrlər)\b/.test(q))
    return {
      text: `EVA Cloud X Köməkçisi 🤖\n\nAşağıdakı mövzularda kömək edə bilərəm:\n\n📁 Fayl əməliyyatları:\n• "şəkillərim" - şəkilləri göstər\n• "videolarım" - videoları göstər\n• "musiqim" - musiqini göstər\n• "sənədlərim" - sənədləri göstər\n• "fayl yüklə" - yükləmə izahı\n• "fayl sil" - silmə izahı\n• "fayl endir" - endirmə izahı\n\n💾 Yaddaş:\n• "yaddaş vəziyyəti" - tam statistika\n• "neçə fayl var" - ümumi sayı\n\n🔒 Təhlükəsizlik:\n• "təhlükəsizlik" - mərkəzə get\n• "şifrələmə" - şifrələmə haqqında\n• "sessiyalar" - aktiv sessiyalar\n\n🎨 Parametrlər:\n• "dil" - dil seçimi\n• "görünüş" - tema ayarları\n• "bildiriş" - bildiriş ayarları\n\nℹ️ Haqqımızda:\n• "haqqımızda" - proqram və yaradıcı\n• "əlaqə" - əlaqə məlumatları\n• "abonəlik" - planlar və qiymətlər`,
    };

  // Sessions
  if (/\b(sessiya|session|cihaz|giriş tarixi)\b/.test(q))
    return {
      text: 'Aktiv Sessiyalar 📱:\n\n"Təhlükəsizlik" bölməsindəki "Aktiv Sessiyalar" bölməsindən bütün aktiv sessiyaları görə bilərsiniz:\n• Hansı cihazdan girilib\n• Giriş tarixi və vaxtı\n• Son aktivlik\n• Şəbəkə məlumatı\n\nNaməlum sessiya varsa onu bağlaya bilərsiniz. "Bütün Sessiyalardan Çıx" düyməsi ilə bütün cihazlardan çıxış edə bilərsiniz.',
      action: { label: 'Təhlükəsizlik', route: '/(tabs)/security' },
    };

  // Trash auto-delete
  if (/\b(avtomatik|auto|gün|zibil.*sil|sil.*zibil)\b/.test(q))
    return {
      text: 'Avtomatik Silinmə 🗑️:\n\n"Zibil Qutusu" bölməsindəki ⚙️ düyməsindən müddəti seçin:\n• Heç vaxt (əl ilə silmə lazım)\n• 30 gün sonra avtomatik silinmə\n• 60 gün sonra avtomatik silinmə\n• 90 gün sonra avtomatik silinmə\n\nSeçilmiş müddət keçən fayllar avtomatik birdəfəlik silinir.',
      action: { label: 'Zibil Qutusu', route: '/(tabs)/trash' },
    };

  // Greetings
  if (/\b(salam|hello|hi|hey|necəsən|necə get)\b/.test(q))
    return {
      text: `Salam! 👋😊\n\nMən EVA AI-yəm, sizin şəxsi yapay zəka köməkçiniz. Bu gün necə kömək edə bilərəm?\n\nFayllarınız, yaddaşınız, təhlükəsizliyiniz və ya proqram haqqında hər şeyi soruşa bilərsiniz!\n\n💡 İpucu: "şəkillərim", "yaddaş vəziyyəti", "haqqımızda" kimi əmrləri sınayın.`,
    };

  // Thanks
  if (/\b(təşəkkür|sağ ol|thanks|thank you|çox sağ ol)\b/.test(q))
    return {
      text: 'Rica edirəm! 😊 Hər zaman kömək etməyə hazıram. Başqa sualınız varsa, soruşun! 🤖✨',
    };

  // Default intelligent responses
  const defaults = [
    `Necə kömək edə bilərəm? 😊\n\nAşağıdakıları soruşa bilərsiniz:\n• "şəkillərim" - şəkillərinizə baxın\n• "yaddaş vəziyyəti" - statistika\n• "fayl yüklə" - izah\n• "fayl endir" - endirmə izahı\n• "haqqımızda" - proqram və yaradıcı\n• "kömək" - ətraflı yardım`,
    `Soruşun, kömək edim! 🤖\n\nMəsələn:\n• "neçə video var?"\n• "sevimlilərimi göstər"\n• "şifrəmi necə dəyişim?"\n• "yaddaş nə qədərdir?"\n• "dil necə dəyişilir?"\n• "təhlükəsizlik"`,
    `EVA AI burada! 🤖✨\nYaddaş, fayllar, təhlükəsizlik, parametrlər və proqram haqqında hər şeyi soruşa bilərsiniz.\n\nÜst sıradakı sürətli əmrlərdən birini sınayın və ya öz sualınızı yazın!`,
    `Başqa sualınız var? 💡\n\nMən hər şeyi bilirəm:\n• 📁 Fayl əməliyyatları\n• 💾 Yaddaş və statistika\n• 🔒 Təhlükəsizlik və məxfilik\n• 🎨 Parametrlər və görünüş\n• ℹ️ Proqram və yaradıcı haqqında\n\nSual verin! 😊`,
  ];
  return { text: defaults[Math.floor(Math.random() * defaults.length)] };
}

export function EvaAssistant() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { id: '0', role: 'assistant', text: EVA_GREETING, timestamp: new Date() },
  ]);
  const [typing, setTyping] = useState(false);
  const [editingMessage, setEditingMessage] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showMenuForId, setShowMenuForId] = useState<string | null>(null);
  const slideAnim = useRef(new Animated.Value(WIN.width)).current;
  const fabScale = useRef(new Animated.Value(1)).current;
  const fabGlow = useRef(new Animated.Value(0.3)).current;
  const fabPulse = useRef(new Animated.Value(1)).current;
  const scrollRef = useRef<ScrollView>(null);
  const editInputRef = useRef<TextInput>(null);
  const { user } = useAuth();
  const { t } = useLanguage();

  useEffect(() => {
    if (open) {
      Animated.spring(slideAnim, { toValue: 0, tension: 65, friction: 12, useNativeDriver: true }).start();
    } else {
      Animated.spring(slideAnim, { toValue: WIN.width, tension: 65, friction: 12, useNativeDriver: true }).start();
    }
  }, [open]);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(fabGlow, { toValue: 0.8, duration: 2000, useNativeDriver: true }),
        Animated.timing(fabGlow, { toValue: 0.3, duration: 2000, useNativeDriver: true }),
      ])
    ).start();
    Animated.loop(
      Animated.sequence([
        Animated.timing(fabPulse, { toValue: 1.06, duration: 1600, useNativeDriver: true }),
        Animated.timing(fabPulse, { toValue: 1, duration: 1600, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  function pulseFab() {
    Animated.sequence([
      Animated.spring(fabScale, { toValue: 0.85, tension: 120, friction: 8, useNativeDriver: true }),
      Animated.spring(fabScale, { toValue: 1, tension: 120, friction: 8, useNativeDriver: true }),
    ]).start();
  }

  function clearChat() {
    setMessages([
      { id: Date.now().toString(), role: 'assistant', text: 'Söhbət təmizləndi. Yeni söhbət başlayaq! 😊', timestamp: new Date() },
    ]);
    setShowMenuForId(null);
  }

  function copyText(msg: Message) {
    if (Platform.OS === 'web' && navigator.clipboard) {
      navigator.clipboard.writeText(msg.text);
    }
    setCopiedId(msg.id);
    setShowMenuForId(null);
    setTimeout(() => setCopiedId(null), 2000);
  }

  function startEdit(msg: Message) {
    setEditingMessage(msg.id);
    setEditText(msg.text);
    setShowMenuForId(null);
    setTimeout(() => editInputRef.current?.focus(), 100);
  }

  function saveEdit(msgId: string) {
    if (editText.trim()) {
      setMessages(prev => prev.map(m => m.id === msgId ? { ...m, text: editText.trim() } : m));
    }
    setEditingMessage(null);
    setEditText('');
  }

  function deleteMessage(msgId: string) {
    setMessages(prev => prev.filter(m => m.id !== msgId));
    setShowMenuForId(null);
  }

  async function send(text?: string) {
    const msg = (text ?? input).trim();
    if (!msg || !user) return;
    setInput('');
    setShowMenuForId(null);

    const userMsg: Message = { id: Date.now().toString(), role: 'user', text: msg, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setTyping(true);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 50);

    await new Promise(r => setTimeout(r, 500 + Math.random() * 500));
    const resp = await buildResponse(msg, user.id, t);
    setTyping(false);

    const assistantMsg: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      text: resp.text,
      action: resp.action,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, assistantMsg]);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80);
  }

  return (
    <>
      {!open && (
        <Animated.View style={[styles.fab, { transform: [{ scale: fabScale }] }]}>
          <Animated.View style={[styles.fabGlow, { opacity: fabGlow, transform: [{ scale: fabPulse }] }]} />
          <TouchableOpacity style={styles.fabInner} onPress={() => { pulseFab(); setOpen(true); }} activeOpacity={0.9}>
            <LinearGradient colors={['#1E6FFF', '#00D4FF']} style={StyleSheet.absoluteFill} />
            <Image source={EVA_LOGO} style={styles.fabLogo} resizeMode="contain" />
            <View style={styles.fabDot} />
          </TouchableOpacity>
        </Animated.View>
      )}

      <Animated.View style={[styles.panel, { transform: [{ translateX: slideAnim }] }]}>
        <LinearGradient colors={['#030C1A', '#000814']} style={StyleSheet.absoluteFill} />
        <View style={styles.panelBorder} />

        {/* Header */}
        <View style={styles.panelHeader}>
          <TouchableOpacity style={styles.backBtn} onPress={() => setOpen(false)}>
            <ArrowLeft size={20} color={colors.textSecondary} strokeWidth={2} />
          </TouchableOpacity>
          <Image source={EVA_LOGO} style={styles.panelLogo} resizeMode="contain" />
          <View style={styles.panelTitleWrap}>
            <Text style={styles.panelTitle}>EVA AI Köməkçisi</Text>
            <View style={styles.onlineBadge}>
              <View style={styles.onlineDot} />
              <Text style={styles.onlineText}>Aktiv</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.clearBtn} onPress={clearChat}>
            <Trash2 size={18} color={colors.textTertiary} strokeWidth={1.8} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.closeBtn} onPress={() => setOpen(false)}>
            <X size={20} color={colors.textSecondary} strokeWidth={2} />
          </TouchableOpacity>
        </View>

        {/* Command suggestions (always visible, scrollable) */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.commandScroll}
          style={styles.commandBar}
        >
          {COMMAND_SUGGESTIONS.map(cmd => {
            const Icon = cmd.icon;
            return (
              <TouchableOpacity key={cmd.cmd} style={styles.commandChip} onPress={() => send(cmd.cmd)}>
                <Icon size={12} color={colors.primary} strokeWidth={1.8} />
                <Text style={styles.commandChipText}>{cmd.label}</Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Messages */}
        <ScrollView
          ref={scrollRef}
          style={styles.messages}
          contentContainerStyle={styles.messagesContent}
          showsVerticalScrollIndicator={false}
          onStartShouldSetResponder={() => { setShowMenuForId(null); return false; }}
        >
          {messages.map(msg => (
            <View key={msg.id}>
              <TouchableOpacity
                style={[styles.bubble, msg.role === 'user' ? styles.userBubble : styles.aiBubble]}
                onLongPress={() => setShowMenuForId(showMenuForId === msg.id ? null : msg.id)}
                delayLongPress={350}
                activeOpacity={0.85}
              >
                {msg.role === 'assistant' && (
                  <Image source={EVA_LOGO} style={styles.bubbleLogo} resizeMode="contain" />
                )}
                <View style={msg.role === 'user' ? styles.userBubbleInner : styles.aiBubbleInner}>
                  {editingMessage === msg.id ? (
                    <View style={styles.editContainer}>
                      <TextInput
                        ref={editInputRef}
                        style={styles.editInput}
                        value={editText}
                        onChangeText={setEditText}
                        multiline
                        autoFocus
                      />
                      <View style={styles.editActions}>
                        <TouchableOpacity style={styles.editCancelBtn} onPress={() => { setEditingMessage(null); setEditText(''); }}>
                          <Text style={styles.editCancelText}>Ləğv et</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.editSaveBtn} onPress={() => saveEdit(msg.id)}>
                          <Check size={14} color="#fff" strokeWidth={2} />
                          <Text style={styles.editSaveText}>Saxla</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  ) : (
                    <>
                      <Text style={styles.bubbleText}>{msg.text}</Text>
                      {msg.action && (
                        <TouchableOpacity
                          style={styles.actionBtn}
                          onPress={() => { setOpen(false); setTimeout(() => router.push(msg.action!.route as any), 200); }}
                        >
                          <Text style={styles.actionBtnText}>{msg.action.label}</Text>
                          <ChevronRight size={14} color={colors.primary} strokeWidth={2} />
                        </TouchableOpacity>
                      )}
                      {msg.timestamp && (
                        <Text style={styles.timestamp}>
                          {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </Text>
                      )}
                    </>
                  )}
                </View>
                {msg.role === 'user' && !editingMessage && (
                  <TouchableOpacity style={styles.editBubbleBtn} onPress={() => startEdit(msg)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                    <Edit3 size={13} color={colors.textTertiary} strokeWidth={1.8} />
                  </TouchableOpacity>
                )}
              </TouchableOpacity>

              {/* Context menu */}
              {showMenuForId === msg.id && (
                <View style={[styles.messageMenu, msg.role === 'user' && styles.messageMenuRight]}>
                  <TouchableOpacity style={styles.menuItem} onPress={() => copyText(msg)}>
                    {copiedId === msg.id
                      ? <Check size={14} color={colors.success} strokeWidth={2} />
                      : <Copy size={14} color={colors.textSecondary} strokeWidth={1.8} />}
                    <Text style={styles.menuItemText}>{copiedId === msg.id ? 'Kopyalandı!' : 'Kopyala'}</Text>
                  </TouchableOpacity>
                  {msg.role === 'user' && (
                    <TouchableOpacity style={styles.menuItem} onPress={() => startEdit(msg)}>
                      <Edit3 size={14} color={colors.primary} strokeWidth={1.8} />
                      <Text style={[styles.menuItemText, { color: colors.primary }]}>Düzəliş</Text>
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity style={styles.menuItem} onPress={() => deleteMessage(msg.id)}>
                    <Trash2 size={14} color={colors.error} strokeWidth={1.8} />
                    <Text style={[styles.menuItemText, { color: colors.error }]}>Sil</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          ))}

          {typing && (
            <View style={[styles.bubble, styles.aiBubble]}>
              <Image source={EVA_LOGO} style={styles.bubbleLogo} resizeMode="contain" />
              <View style={styles.aiBubbleInner}>
                <View style={styles.typingDots}>
                  {[0, 1, 2].map(i => (
                    <View key={i} style={[styles.typingDot, { opacity: 0.4 + i * 0.2 }]} />
                  ))}
                </View>
              </View>
            </View>
          )}
        </ScrollView>

        {/* Quick Action Chips */}
        {messages.length <= 1 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipsRow} contentContainerStyle={styles.chipsContent}>
            {[
              { label: '📷 Şəkillərim', text: 'şəkillərim' },
              { label: '💾 Yaddaş', text: 'yaddaş vəziyyəti' },
              { label: '📤 Fayl Yüklə', text: 'fayl yüklə' },
              { label: '⬇️ Fayl Endir', text: 'fayl endir' },
              { label: 'ℹ️ Haqqımızda', text: 'haqqımızda' },
              { label: '🔒 Təhlükəsizlik', text: 'təhlükəsizlik' },
              { label: '🗑️ Zibil', text: 'zibil qutusu' },
              { label: '🎨 Görünüş', text: 'görünüş' },
            ].map((chip, i) => (
              <TouchableOpacity key={i} style={styles.chip} onPress={() => { setInput(chip.text); send(chip.text); }}>
                <Text style={styles.chipText}>{chip.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        )}

        {/* Input */}
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
          <View style={styles.inputRow}>
            <TextInput
              style={styles.input}
              value={input}
              onChangeText={setInput}
              placeholder="Soruşun..."
              placeholderTextColor={colors.textTertiary}
              multiline
              maxLength={500}
              returnKeyType="send"
              onSubmitEditing={() => send()}
            />
            <TouchableOpacity
              style={[styles.sendBtn, !input.trim() && styles.sendBtnDisabled]}
              onPress={() => send()}
              disabled={!input.trim()}
            >
              <LinearGradient colors={input.trim() ? ['#1E6FFF', '#00D4FF'] : ['#333', '#333']} style={StyleSheet.absoluteFill} />
              <Send size={16} color="#fff" strokeWidth={2} />
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Animated.View>
    </>
  );
}

const styles = StyleSheet.create({
  fab: {
    position: 'absolute', right: 18,
    bottom: Platform.OS === 'ios' ? 40 : 28, zIndex: 900,
  },
  fabGlow: {
    position: 'absolute', width: 80, height: 80, borderRadius: 40,
    backgroundColor: '#1E6FFF', top: -12, left: -12,
  },
  fabInner: {
    width: 56, height: 56, borderRadius: 28, overflow: 'hidden',
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#1E6FFF', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5, shadowRadius: 12, elevation: 12,
  },
  fabLogo: { width: 34, height: 34 },
  fabDot: {
    position: 'absolute', top: 10, right: 10,
    width: 8, height: 8, borderRadius: 4,
    backgroundColor: '#34C759', borderWidth: 1.5, borderColor: '#000',
  },
  panel: {
    position: 'absolute', top: 0, right: 0,
    width: WIN.width, height: WIN.height, zIndex: 950, overflow: 'hidden',
  },
  panelBorder: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 1, backgroundColor: 'rgba(30,111,255,0.3)' },
  panelHeader: {
    flexDirection: 'row', alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 56 : 44,
    paddingHorizontal: spacing.md, paddingBottom: spacing.sm,
    gap: spacing.sm, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.07)',
  },
  backBtn: {
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: 'rgba(255,255,255,0.08)', alignItems: 'center', justifyContent: 'center',
  },
  panelLogo: { width: 30, height: 30 },
  panelTitleWrap: { flex: 1 },
  panelTitle: { color: colors.text, fontSize: 15, fontWeight: '700' },
  onlineBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 },
  onlineDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#34C759' },
  onlineText: { color: '#34C759', fontSize: 10, fontWeight: '500' },
  clearBtn: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.06)', alignItems: 'center', justifyContent: 'center',
  },
  closeBtn: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.08)', alignItems: 'center', justifyContent: 'center',
  },
  commandBar: { borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.05)', maxHeight: 48 },
  commandScroll: { paddingHorizontal: spacing.md, gap: spacing.xs, alignItems: 'center', paddingVertical: 8 },
  commandChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(30,111,255,0.12)', borderRadius: radius.full,
    paddingHorizontal: spacing.sm, paddingVertical: 5,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.2)',
  },
  commandChipText: { color: colors.primary, fontSize: 11, fontWeight: '600' },
  messages: { flex: 1 },
  messagesContent: { padding: spacing.md, gap: spacing.md, paddingBottom: 32 },
  bubble: { flexDirection: 'row', gap: spacing.xs, alignItems: 'flex-end' },
  userBubble: { justifyContent: 'flex-end' },
  aiBubble: { justifyContent: 'flex-start' },
  bubbleLogo: { width: 24, height: 24, borderRadius: 12, marginBottom: 2 },
  userBubbleInner: {
    maxWidth: '78%', backgroundColor: colors.primary,
    borderRadius: radius.lg, borderBottomRightRadius: 4, padding: spacing.sm,
  },
  aiBubbleInner: {
    maxWidth: '82%', backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: radius.lg, borderBottomLeftRadius: 4, padding: spacing.sm,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)',
  },
  bubbleText: { color: colors.text, fontSize: 13, lineHeight: 19 },
  timestamp: { color: 'rgba(255,255,255,0.35)', fontSize: 10, marginTop: 4, textAlign: 'right' },
  editBubbleBtn: { padding: 4 },
  editContainer: { gap: spacing.sm },
  editInput: {
    color: colors.text, fontSize: 13, backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: radius.sm, paddingHorizontal: spacing.sm, paddingVertical: spacing.xs, minHeight: 36,
  },
  editActions: { flexDirection: 'row', gap: spacing.sm, justifyContent: 'flex-end' },
  editCancelBtn: { paddingHorizontal: spacing.sm, paddingVertical: spacing.xs },
  editCancelText: { color: colors.textTertiary, fontSize: 12 },
  editSaveBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.success, borderRadius: radius.sm,
    paddingHorizontal: spacing.sm, paddingVertical: spacing.xs,
  },
  editSaveText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  actionBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    marginTop: spacing.xs, paddingTop: spacing.xs,
    borderTopWidth: 1, borderTopColor: 'rgba(30,111,255,0.2)',
  },
  actionBtnText: { color: colors.primary, fontSize: 12, fontWeight: '600' },
  messageMenu: {
    flexDirection: 'row', gap: spacing.xs,
    backgroundColor: colors.surface, borderRadius: radius.md, padding: spacing.xs,
    marginTop: spacing.xs, marginLeft: 30 + spacing.sm,
    borderWidth: 1, borderColor: colors.border,
  },
  messageMenuRight: { marginLeft: 0, marginRight: 8 + spacing.sm, justifyContent: 'flex-end' },
  menuItem: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: spacing.sm, paddingVertical: spacing.xs,
    borderRadius: radius.sm, backgroundColor: 'rgba(255,255,255,0.05)',
  },
  menuItemText: { color: colors.textSecondary, fontSize: 11 },
  typingDots: { flexDirection: 'row', gap: 5, paddingVertical: 4 },
  typingDot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: colors.textSecondary },
  inputRow: {
    flexDirection: 'row', alignItems: 'flex-end',
    padding: spacing.md,
    paddingBottom: Platform.OS === 'ios' ? 28 : spacing.md,
    gap: spacing.sm,
    borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.07)',
  },
  input: {
    flex: 1, color: colors.text, fontSize: 14,
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderRadius: radius.lg, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: spacing.md, paddingVertical: 10, maxHeight: 100,
  },
  sendBtn: {
    width: 42, height: 42, borderRadius: 21,
    overflow: 'hidden', alignItems: 'center', justifyContent: 'center',
  },
  sendBtnDisabled: { opacity: 0.35 },
  chipsRow: { maxHeight: 44, marginBottom: spacing.sm },
  chipsContent: { paddingHorizontal: spacing.lg, gap: spacing.sm },
  chip: {
    backgroundColor: 'rgba(30,111,255,0.12)',
    borderRadius: 20,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.25)',
  },
  chipText: { color: colors.primary, fontSize: 12, fontWeight: '500' },
});
