import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  Image,
  ActivityIndicator,
  Platform,
  Modal,
  Share,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  X, Image as ImageIcon, ChevronLeft, ChevronRight,
  Grid, Share2, Download, Info, ZoomIn, Calendar,
} from 'lucide-react-native';
import { FileRecord, formatBytes } from '@/lib/files';
import { downloadFileModern } from '@/lib/download';
import { useLanguage } from '@/context/LanguageContext';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { PlayerWindow, WindowMode } from './PlayerWindow';

const { width, height } = Dimensions.get('window');
const GRID_COLS = 3;
const CELL_SIZE = (width - spacing.xl * 2 - 4 * (GRID_COLS - 1)) / GRID_COLS;

type Props = {
  files: FileRecord[];
  onBack: () => void;
};

export function GalleryViewer({ files, onBack }: Props) {
  const { t } = useLanguage();
  const [selected, setSelected] = useState<number | null>(null);
  const [imageLoading, setImageLoading] = useState<Record<string, boolean>>({});
  const [showInfo, setShowInfo] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadToast, setDownloadToast] = useState<string | null>(null);
  const [windowMode, setWindowMode] = useState<WindowMode>('windowed');

  const currentFile = selected !== null ? files[selected] : null;

  function goPrev() {
    if (selected !== null && selected > 0) setSelected(selected - 1);
  }
  function goNext() {
    if (selected !== null && selected < files.length - 1) setSelected(selected + 1);
  }

  async function handleShare() {
    if (!currentFile?.storage_url) return;
    try {
      if (Platform.OS === 'web') {
        if (navigator.share) await navigator.share({ title: currentFile.name, url: currentFile.storage_url });
        else { await navigator.clipboard.writeText(currentFile.storage_url); Alert.alert('Link Copied', 'Image link copied to clipboard.'); }
      } else {
        await Share.share({ message: `${currentFile.name}\n${currentFile.storage_url}`, url: currentFile.storage_url });
      }
    } catch {}
  }

  async function handleDownload() {
    if (!currentFile) return;
    setDownloading(true);
    const result = await downloadFileModern(currentFile);
    setDownloading(false);
    if (result.success) setDownloadToast(`✓ ${currentFile.name} endirildi`);
    else setDownloadToast(`✕ ${result.error ?? 'Xəta'}`);
    setTimeout(() => setDownloadToast(null), 3000);
  }

  if (files.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />
        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={onBack}>
            <X size={22} color={colors.text} strokeWidth={2} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>{t('gallery')}</Text>
          <View style={{ width: 40 }} />
        </View>
        <View style={styles.emptyWrap}>
          <ImageIcon size={56} color={colors.textTertiary} strokeWidth={1.5} />
          <Text style={styles.emptyTitle}>{t('no_photo_files')}</Text>
          <Text style={styles.emptySub}>{t('players_empty_sub')}</Text>
        </View>
      </View>
    );
  }

  return (
    <PlayerWindow
      title={t('gallery')}
      subtitle={`${files.length} ${t('files')}`}
      mode={windowMode}
      onModeChange={setWindowMode}
      onClose={onBack}
      onBack={onBack}
      accentColor="#FF9F0A"
      minimizedContent={<ImageIcon size={18} color="#FF9F0A" strokeWidth={1.8} />}
    >
      <View style={styles.container}>
        <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />

        <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <View style={styles.grid}>
            {files.map((file, i) => (
              <TouchableOpacity
                key={file.id}
                style={styles.gridCell}
                onPress={() => setSelected(i)}
                activeOpacity={0.85}
              >
                {imageLoading[file.id] !== false && (
                  <View style={styles.cellLoader}>
                    <ActivityIndicator size="small" color={colors.primary} />
                  </View>
                )}
                {file.storage_url && (
                  <Image
                    source={{ uri: file.storage_url }}
                    style={styles.gridImage}
                    resizeMode="cover"
                    onLoad={() => setImageLoading(prev => ({ ...prev, [file.id]: false }))}
                    onError={() => setImageLoading(prev => ({ ...prev, [file.id]: false }))}
                  />
                )}
                <View style={styles.cellOverlay}>
                  <Text style={styles.cellName} numberOfLines={1}>{file.name}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>

        {/* Fullscreen image viewer */}
        <Modal visible={selected !== null} transparent animationType="fade" onRequestClose={() => setSelected(null)}>
          <View style={styles.fullscreenContainer}>
            <LinearGradient colors={['rgba(0,0,0,0.7)', 'transparent']} style={styles.topGrad} />
            <LinearGradient colors={['transparent', 'rgba(0,0,0,0.8)']} style={styles.bottomGrad} />

            <View style={styles.fullHeader}>
              <TouchableOpacity style={styles.iconBtn} onPress={() => setSelected(null)}>
                <X size={22} color="#fff" strokeWidth={2} />
              </TouchableOpacity>
              {currentFile && (
                <View style={styles.fullInfo}>
                  <Text style={styles.fullName} numberOfLines={1}>{currentFile.name}</Text>
                  <Text style={styles.fullMeta}>
                    {formatBytes(currentFile.size)} · {selected! + 1}/{files.length}
                  </Text>
                </View>
              )}
              <TouchableOpacity style={styles.iconBtn} onPress={() => setShowInfo(!showInfo)}>
                <Info size={20} color={showInfo ? colors.primary : '#fff'} strokeWidth={1.8} />
              </TouchableOpacity>
            </View>

            {currentFile?.storage_url && (
              <ScrollView
                style={styles.imageScroll}
                contentContainerStyle={styles.imageScrollContent}
                maximumZoomScale={5}
                minimumZoomScale={1}
                showsHorizontalScrollIndicator={false}
                showsVerticalScrollIndicator={false}
                centerContent
              >
                <Image source={{ uri: currentFile.storage_url }} style={styles.fullImage} resizeMode="contain" />
              </ScrollView>
            )}

            {selected !== null && selected > 0 && (
              <TouchableOpacity style={styles.navLeft} onPress={goPrev}>
                <ChevronLeft size={28} color="#fff" strokeWidth={2} />
              </TouchableOpacity>
            )}
            {selected !== null && selected < files.length - 1 && (
              <TouchableOpacity style={styles.navRight} onPress={goNext}>
                <ChevronRight size={28} color="#fff" strokeWidth={2} />
              </TouchableOpacity>
            )}

            {showInfo && currentFile && (
              <View style={styles.infoPanel}>
                <Text style={styles.infoTitle}>{t('info_title') || 'File Info'}</Text>
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>{t('info_name') || 'Name:'}</Text>
                  <Text style={styles.infoValue}>{currentFile.name}</Text>
                </View>
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>{t('info_size') || 'Size:'}</Text>
                  <Text style={styles.infoValue}>{formatBytes(currentFile.size)}</Text>
                </View>
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>{t('info_type') || 'Type:'}</Text>
                  <Text style={styles.infoValue}>{currentFile.mime_type}</Text>
                </View>
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>{t('info_uploaded') || 'Uploaded:'}</Text>
                  <Text style={styles.infoValue}>{new Date(currentFile.created_at).toLocaleDateString()}</Text>
                </View>
                {(currentFile.width || currentFile.height) && (
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>{t('info_dimensions') || 'Dimensions:'}</Text>
                    <Text style={styles.infoValue}>{currentFile.width}×{currentFile.height}</Text>
                  </View>
                )}
              </View>
            )}

            <View style={styles.fullActions}>
              <TouchableOpacity style={styles.actionBtn} onPress={handleShare}>
                <Share2 size={22} color="#fff" strokeWidth={1.8} />
                <Text style={styles.actionLabel}>{t('share') || 'Share'}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionBtn} onPress={handleDownload} disabled={downloading}>
                {downloading ? <ActivityIndicator size="small" color="#fff" /> : <Download size={22} color="#fff" strokeWidth={1.8} />}
                <Text style={styles.actionLabel}>{t('download') || 'Download'}</Text>
              </TouchableOpacity>
            </View>

            {files.length > 1 && files.length <= 30 && (
              <View style={styles.dots}>
                {files.map((_, i) => (
                  <TouchableOpacity key={i} onPress={() => setSelected(i)}>
                    <View style={[styles.dot, i === selected && styles.dotActive]} />
                  </TouchableOpacity>
                ))}
              </View>
            )}

            {downloadToast && (
              <View style={styles.toastWrap}>
                <View style={styles.toastCard}>
                  <Text style={styles.toastText}>{downloadToast}</Text>
                </View>
              </View>
            )}
          </View>
        </Modal>
      </View>
    </PlayerWindow>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.xl, paddingBottom: spacing.md,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { color: colors.text, fontSize: 20, fontWeight: '700' },
  headerCount: { color: colors.textTertiary, fontSize: 12, marginTop: 2 },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: spacing.xl, paddingBottom: 100 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 4 },
  gridCell: {
    width: CELL_SIZE, height: CELL_SIZE,
    borderRadius: radius.md, overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.04)', position: 'relative',
  },
  cellLoader: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  gridImage: { width: '100%', height: '100%' },
  cellOverlay: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: 'rgba(0,0,0,0.5)', paddingHorizontal: 6, paddingVertical: 4,
  },
  cellName: { color: '#fff', fontSize: 10, fontWeight: '500' },
  fullscreenContainer: { flex: 1, backgroundColor: '#000' },
  topGrad: { position: 'absolute', top: 0, left: 0, right: 0, height: 130, zIndex: 1 },
  bottomGrad: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 180, zIndex: 1 },
  fullHeader: {
    position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10,
    flexDirection: 'row', alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 52 : 40,
    paddingHorizontal: spacing.xl, paddingBottom: spacing.lg, gap: spacing.md,
  },
  iconBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  fullInfo: { flex: 1 },
  fullName: { color: '#fff', fontSize: 15, fontWeight: '600' },
  fullMeta: { color: 'rgba(255,255,255,0.6)', fontSize: 12, marginTop: 2 },
  imageScroll: { flex: 1, width },
  imageScrollContent: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  fullImage: { width, height: height * 0.7 },
  navLeft: {
    position: 'absolute', left: spacing.md, top: height / 2 - 22, zIndex: 5,
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center',
  },
  navRight: {
    position: 'absolute', right: spacing.md, top: height / 2 - 22, zIndex: 5,
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center',
  },
  infoPanel: {
    position: 'absolute', top: 130, left: spacing.md, right: spacing.md,
    backgroundColor: 'rgba(0,0,0,0.9)', borderRadius: radius.lg,
    padding: spacing.lg, zIndex: 20, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
  },
  infoTitle: { color: colors.text, fontSize: 16, fontWeight: '700', marginBottom: spacing.sm },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  infoLabel: { color: colors.textTertiary, fontSize: 12 },
  infoValue: { color: colors.text, fontSize: 12, fontWeight: '500', maxWidth: '60%', textAlign: 'right' },
  fullActions: {
    position: 'absolute', bottom: Platform.OS === 'ios' ? 52 : 36, left: 0, right: 0, zIndex: 10,
    flexDirection: 'row', justifyContent: 'center', gap: 40,
  },
  actionBtn: { alignItems: 'center', gap: 6 },
  actionLabel: { color: '#fff', fontSize: 12, fontWeight: '500' },
  dots: {
    position: 'absolute', bottom: 100, left: 0, right: 0, zIndex: 10,
    flexDirection: 'row', justifyContent: 'center', flexWrap: 'wrap', gap: 5,
  },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.3)' },
  dotActive: { backgroundColor: '#fff', width: 18 },
  toastWrap: {
    position: 'absolute', bottom: 100, left: spacing.lg, right: spacing.lg,
    zIndex: 1000, alignItems: 'center',
  },
  toastCard: {
    backgroundColor: 'rgba(10,20,40,0.95)', borderRadius: radius.lg,
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)',
  },
  toastText: { color: colors.text, fontSize: 13, fontWeight: '500' },
  emptyContainer: { flex: 1, backgroundColor: colors.background },
  emptyWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.sm },
  emptyTitle: { color: colors.text, fontSize: 18, fontWeight: '600' },
  emptySub: { color: colors.textSecondary, fontSize: 13, textAlign: 'center' },
});
