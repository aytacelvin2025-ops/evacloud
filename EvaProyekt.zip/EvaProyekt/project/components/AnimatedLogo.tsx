import React, { useEffect, useRef } from 'react';
import {
  View,
  Image,
  Animated,
  StyleSheet,
  Easing,
  Platform,
} from 'react-native';

const EVA_LOGO = require('../assets/images/eva-logo.png');

type Props = {
  size?: number;
  glowColor?: string;
};

export function AnimatedLogo({ size = 180, glowColor = '#1E6FFF' }: Props) {
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const rotateRevAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(0.97)).current;
  const glowAnim = useRef(new Animated.Value(0.3)).current;
  const entranceScale = useRef(new Animated.Value(0.78)).current;
  const entranceOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Entrance
    Animated.parallel([
      Animated.spring(entranceScale, {
        toValue: 1,
        tension: 40,
        friction: 8,
        useNativeDriver: true,
      }),
      Animated.timing(entranceOpacity, {
        toValue: 1,
        duration: 700,
        useNativeDriver: true,
      }),
    ]).start();

    // Clockwise ring rotation
    Animated.loop(
      Animated.timing(rotateAnim, {
        toValue: 1,
        duration: 8000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    ).start();

    // Counter-clockwise inner ring
    Animated.loop(
      Animated.timing(rotateRevAnim, {
        toValue: 1,
        duration: 5000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    ).start();

    // Logo pulse — use Easing.inOut(Easing.quad) which is always available
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.05,
          duration: 1600,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 0.97,
          duration: 1600,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Glow breathe
    Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, {
          toValue: 0.85,
          duration: 2000,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(glowAnim, {
          toValue: 0.3,
          duration: 2000,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  const rotate = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });
  const rotateRev = rotateRevAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['360deg', '0deg'],
  });

  const ringSize = size + 44;
  const innerRingSize = size + 20;
  const outerSize = size + 72;

  return (
    <Animated.View
      style={{
        width: outerSize,
        height: outerSize,
        alignItems: 'center',
        justifyContent: 'center',
        opacity: entranceOpacity,
        transform: [{ scale: entranceScale }],
      }}
    >
      {/* Ambient glow behind the logo */}
      <Animated.View
        style={[
          styles.glow,
          {
            width: outerSize,
            height: outerSize,
            borderRadius: outerSize / 2,
            backgroundColor: glowColor,
            opacity: glowAnim,
          },
        ]}
      />

      {/* Outer rotating ring — gap at top-left (two visible borders) */}
      <Animated.View
        style={[
          styles.ringOuter,
          {
            width: ringSize,
            height: ringSize,
            borderRadius: ringSize / 2,
            borderColor: glowColor + '55',
            transform: [{ rotate }],
            position: 'absolute',
          },
        ]}
      />

      {/* Inner counter-rotating ring */}
      <Animated.View
        style={[
          styles.ringInner,
          {
            width: innerRingSize,
            height: innerRingSize,
            borderRadius: innerRingSize / 2,
            borderColor: '#00D4FF45',
            transform: [{ rotate: rotateRev }],
            position: 'absolute',
          },
        ]}
      />

      {/* Logo image with pulse */}
      <Animated.View
        style={{
          width: size,
          height: size,
          alignItems: 'center',
          justifyContent: 'center',
          transform: [{ scale: pulseAnim }],
        }}
      >
        <Image
          source={EVA_LOGO}
          style={{ width: size, height: size }}
          resizeMode="contain"
        />
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  glow: {
    position: 'absolute',
    ...(Platform.OS === 'web' ? { filter: 'blur(36px)' } : {}),
  } as any,
  ringOuter: {
    borderWidth: 1.5,
    borderTopColor: 'transparent',
    borderLeftColor: 'transparent',
  },
  ringInner: {
    borderWidth: 1,
    borderBottomColor: 'transparent',
    borderRightColor: 'transparent',
  },
});
