import React, { useRef, useEffect } from 'react';
import {
  View, Image, StyleSheet, TouchableOpacity, Text,
  Animated, Platform, PanResponder, Dimensions, Easing,
} from 'react-native';
import { useDrawer } from '@/context/DrawerContext';
import { useLanguage } from '@/context/LanguageContext';
import { colors, spacing } from '@/constants/theme';

const EVA_LOGO = require('../assets/images/eva-logo.png');
const { width: WIN_W } = Dimensions.get('window');

type Props = {
  title?: string;
  rightContent?: React.ReactNode;
};

export function AppHeader({ title, rightContent }: Props) {
  const { openDrawer } = useDrawer();
  const { t } = useLanguage();
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const slideHint = useRef(new Animated.Value(0)).current;
  const hintOpacity = useRef(new Animated.Value(0.6)).current;
  const menuTextOpacity = useRef(new Animated.Value(0)).current;

  // Entrance animation for menu text
  useEffect(() => {
    Animated.sequence([
      Animated.delay(400),
      Animated.timing(menuTextOpacity, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),
    ]).start();

    // Sliding hint animation to indicate drawer can be opened
    const hintAnim = Animated.loop(
      Animated.sequence([
        Animated.parallel([
          Animated.timing(slideHint, {
            toValue: 1,
            duration: 1500,
            easing: Easing.out(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(hintOpacity, {
            toValue: 0,
            duration: 1500,
            useNativeDriver: true,
          }),
        ]),
        Animated.delay(3000),
        Animated.parallel([
          Animated.timing(slideHint, {
            toValue: 0,
            duration: 0,
            useNativeDriver: true,
          }),
          Animated.timing(hintOpacity, {
            toValue: 0.7,
            duration: 0,
            useNativeDriver: true,
          }),
        ]),
      ])
    );
    hintAnim.start();

    return () => hintAnim.stop();
  }, []);

  // Touch the whole header area to open drawer
  function handlePressIn() {
    Animated.spring(pulseAnim, { toValue: 0.92, tension: 120, friction: 8, useNativeDriver: true }).start();
  }
  function handlePressOut() {
    Animated.spring(pulseAnim, { toValue: 1, tension: 120, friction: 8, useNativeDriver: true }).start();
    openDrawer();
  }

  // Edge swipe to open drawer (more sensitive now)
  const panRef = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => g.dx > 8 && Math.abs(g.dy) < 80,
      onPanResponderRelease: (_, g) => { if (g.dx > 30) openDrawer(); },
    })
  ).current;

  const hintTranslateX = slideHint.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 40],
  });

  return (
    <View style={styles.header} {...panRef.panHandlers}>
      {/* Slide hint indicator - shows user can swipe from left */}
      <Animated.View
        style={[
          styles.slideHint,
          {
            opacity: hintOpacity,
            transform: [{ translateX: hintTranslateX }],
          },
        ]}
        pointerEvents="none"
      >
        <View style={styles.hintArrow}>
          <View style={[styles.hintLine, { backgroundColor: colors.primary }]} />
          <View style={styles.hintDot} />
        </View>
      </Animated.View>

      {/* Menu button area - entire top left */}
      <TouchableOpacity
        style={styles.menuBtn}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        activeOpacity={1}
      >
        <Animated.View style={[styles.menuBtnInner, { opacity: menuTextOpacity }]}>
          <Animated.Image
            source={EVA_LOGO}
            style={[styles.logo, { transform: [{ scale: pulseAnim }] }]}
            resizeMode="contain"
          />
          <View style={styles.menuTextWrap}>
            <Text style={styles.menuLabel}>{t('menu') || 'Menu'}</Text>
            <View style={styles.menuDots}>
              <View style={styles.menuDot} />
              <View style={styles.menuDot} />
              <View style={styles.menuDot} />
            </View>
          </View>
        </Animated.View>
      </TouchableOpacity>

      {title ? <Text style={styles.title}>{title}</Text> : <View style={{ flex: 1 }} />}

      {rightContent && <View style={styles.right}>{rightContent}</View>}
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 52 : 40,
    paddingHorizontal: spacing.xl,
    paddingBottom: spacing.md,
    gap: 10,
  },
  slideHint: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 58 : 46,
    left: -10,
    zIndex: -1,
  },
  hintArrow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  hintLine: {
    width: 30,
    height: 2,
    borderRadius: 1,
  },
  hintDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.secondary,
  },
  menuBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.sm,
    marginLeft: -spacing.sm,
    borderRadius: 16,
  },
  menuBtnInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  logo: { width: 36, height: 36 },
  menuTextWrap: {
    alignItems: 'flex-start',
    gap: 3,
  },
  menuLabel: {
    color: colors.text,
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  menuDots: {
    flexDirection: 'row',
    gap: 3,
  },
  menuDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.primary,
  },
  title: { flex: 1, color: colors.text, fontSize: 22, fontWeight: '700' },
  right: {},
});
