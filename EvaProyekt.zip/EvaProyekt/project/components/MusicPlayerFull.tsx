import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Platform,
  Dimensions,
  Animated,
  Easing,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  X, Play, Pause, SkipBack, SkipForward, Volume2, VolumeX,
  Shuffle, Repeat, Repeat1, Music, ListMusic, ChevronRight,
} from 'lucide-react-native';
import { FileRecord, formatDuration, formatBytes } from '@/lib/files';
import { useLanguage } from '@/context/LanguageContext';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { PlayerWindow, WindowMode } from './PlayerWindow';

const { width } = Dimensions.get('window');

type Props = {
  files: FileRecord[];
  onBack: () => void;
};

type RepeatMode = 'off' | 'all' | 'one';

export function MusicPlayerFull({ files, onBack }: Props) {
  const { t } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [shuffle, setShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('off');
  const [showPlaylist, setShowPlaylist] = useState(false);
  const [shuffleOrder, setShuffleOrder] = useState<number[]>([]);
  const [windowMode, setWindowMode] = useState<WindowMode>('windowed');

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const spinAnim = useRef(new Animated.Value(0)).current;
  const spinLoop = useRef<Animated.CompositeAnimation | null>(null);

  const currentFile = files[currentIndex];

  useEffect(() => {
    if (Platform.OS !== 'web' || !audioRef.current) return;
    const audio = audioRef.current;
    const onTimeUpdate = () => setCurrentTime(audio.currentTime);
    const onLoadedMetadata = () => { setDuration(audio.duration || 0); setLoading(false); };
    const onEnded = () => handleEnded();
    const onVolumeChange = () => { setMuted(audio.muted); setVolume(audio.volume); };
    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('volumechange', onVolumeChange);
    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('ended', onEnded);
      audio.removeEventListener('volumechange', onVolumeChange);
    };
  }, [currentIndex]);

  useEffect(() => {
    if (playing) {
      spinLoop.current = Animated.loop(
        Animated.timing(spinAnim, { toValue: 1, duration: 8000, easing: Easing.linear, useNativeDriver: true })
      );
      spinLoop.current.start();
    } else {
      spinLoop.current?.stop();
    }
    return () => spinLoop.current?.stop();
  }, [playing]);

  const spin = spinAnim.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });

  function togglePlay() {
    if (!audioRef.current) return;
    if (playing) { audioRef.current.pause(); } else { audioRef.current.play(); }
    setPlaying(!playing);
  }

  function seek(time: number) {
    if (!audioRef.current) return;
    audioRef.current.currentTime = time;
    setCurrentTime(time);
  }

  function skip(seconds: number) {
    if (!audioRef.current) return;
    const newTime = Math.max(0, Math.min(duration, currentTime + seconds));
    audioRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  }

  function toggleMute() {
    if (!audioRef.current) return;
    audioRef.current.muted = !audioRef.current.muted;
  }

  function handleEnded() {
    if (repeatMode === 'one') {
      if (audioRef.current) { audioRef.current.currentTime = 0; audioRef.current.play(); }
      return;
    }
    playNext();
  }

  function playNext() {
    if (files.length === 0) return;
    if (shuffle && shuffleOrder.length > 0) {
      const currentPos = shuffleOrder.indexOf(currentIndex);
      if (currentPos < shuffleOrder.length - 1) selectTrack(shuffleOrder[currentPos + 1]);
      else if (repeatMode === 'all') selectTrack(shuffleOrder[0]);
      else setPlaying(false);
    } else {
      if (currentIndex < files.length - 1) selectTrack(currentIndex + 1);
      else if (repeatMode === 'all') selectTrack(0);
      else setPlaying(false);
    }
  }

  function playPrev() {
    if (files.length === 0) return;
    if (shuffle && shuffleOrder.length > 0) {
      const currentPos = shuffleOrder.indexOf(currentIndex);
      if (currentPos > 0) selectTrack(shuffleOrder[currentPos - 1]);
      else selectTrack(shuffleOrder[shuffleOrder.length - 1]);
    } else {
      if (currentIndex > 0) selectTrack(currentIndex - 1);
      else selectTrack(files.length - 1);
    }
  }

  function selectTrack(index: number) {
    setCurrentIndex(index);
    setPlaying(false);
    setCurrentTime(0);
    setLoading(true);
    setTimeout(() => {
      if (audioRef.current) { audioRef.current.play(); setPlaying(true); }
    }, 200);
  }

  function toggleShuffle() {
    if (!shuffle) {
      const order = files.map((_, i) => i).sort(() => Math.random() - 0.5);
      setShuffleOrder(order);
    }
    setShuffle(!shuffle);
  }

  function cycleRepeat() {
    setRepeatMode(prev => prev === 'off' ? 'all' : prev === 'all' ? 'one' : 'off');
  }

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  if (!currentFile) {
    return (
      <View style={styles.emptyContainer}>
        <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />
        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={onBack}>
            <X size={22} color={colors.text} strokeWidth={2} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>{t('music_player')}</Text>
        </View>
        <View style={styles.emptyWrap}>
          <Music size={56} color={colors.textTertiary} strokeWidth={1.5} />
          <Text style={styles.emptyTitle}>{t('no_music_files')}</Text>
          <Text style={styles.emptySub}>{t('players_empty_sub')}</Text>
        </View>
      </View>
    );
  }

  return (
    <PlayerWindow
      title={currentFile.name}
      subtitle={`${currentFile.mime_type.split('/')[1]?.toUpperCase() || 'Audio'} · ${formatBytes(currentFile.size)} · ${currentIndex + 1}/${files.length}`}
      mode={windowMode}
      onModeChange={setWindowMode}
      onClose={onBack}
      onBack={onBack}
      accentColor="#34C759"
      minimizedContent={<Music size={18} color="#34C759" strokeWidth={1.8} />}
    >
      <View style={styles.container}>
        <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />

        <View style={styles.header}>
          <View style={{ width: 40 }} />
          <Text style={styles.headerTitle}>{t('music_player')}</Text>
          <TouchableOpacity style={styles.backBtn} onPress={() => setShowPlaylist(!showPlaylist)}>
            <ListMusic size={20} color={colors.text} strokeWidth={1.8} />
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <View style={styles.artworkContainer}>
            <Animated.View style={[styles.artwork, { transform: [{ rotate: spin }] }]}>
              <LinearGradient colors={['#1E6FFF', '#00D4FF']} style={StyleSheet.absoluteFill} />
              <Music size={64} color="rgba(255,255,255,0.9)" strokeWidth={1.5} />
            </Animated.View>
            <View style={styles.artworkGlow} />
          </View>

          <View style={styles.trackInfo}>
            <Text style={styles.nowPlaying}>{t('now_playing')}</Text>
            <Text style={styles.trackName} numberOfLines={2}>{currentFile.name}</Text>
            <Text style={styles.trackMeta}>
              {currentFile.mime_type.split('/')[1]?.toUpperCase() || 'Audio'}
              {` · ${formatBytes(currentFile.size)}`}
              {` · ${currentIndex + 1}/${files.length}`}
            </Text>
          </View>

          {loading ? (
            <ActivityIndicator color={colors.primary} style={{ marginVertical: 24 }} />
          ) : (
            <View style={styles.progressSection}>
              <TouchableOpacity
                style={styles.progressBar}
                onPress={(e) => {
                  // @ts-ignore
                  const rect = e.currentTarget.getBoundingClientRect();
                  // @ts-ignore
                  const x = e.nativeEvent.clientX - rect.left;
                  const percent = x / rect.width;
                  seek(percent * duration);
                }}
              >
                <View style={styles.progressTrack}>
                  <View style={[styles.progressFill, { width: `${progress}%` as any }]} />
                  <View style={[styles.progressThumb, { left: `${progress}%` as any }]} />
                </View>
              </TouchableOpacity>
              <View style={styles.timeRow}>
                <Text style={styles.timeText}>{formatDuration(currentTime)}</Text>
                <Text style={styles.timeText}>{formatDuration(duration)}</Text>
              </View>
            </View>
          )}

          <View style={styles.mainControls}>
            <TouchableOpacity style={[styles.controlIcon, shuffle && styles.controlIconActive]} onPress={toggleShuffle}>
              <Shuffle size={20} color={shuffle ? colors.primary : colors.textSecondary} strokeWidth={1.8} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.skipControl} onPress={playPrev}>
              <SkipBack size={28} color={colors.text} strokeWidth={1.8} fill={colors.text} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.playBtn} onPress={togglePlay}>
              {playing ? <Pause size={32} color="#fff" strokeWidth={2} /> : <Play size={32} color="#fff" strokeWidth={2} fill="#fff" />}
            </TouchableOpacity>
            <TouchableOpacity style={styles.skipControl} onPress={playNext}>
              <SkipForward size={28} color={colors.text} strokeWidth={1.8} fill={colors.text} />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.controlIcon, repeatMode !== 'off' && styles.controlIconActive]} onPress={cycleRepeat}>
              {repeatMode === 'one' ? (
                <Repeat1 size={20} color={colors.primary} strokeWidth={1.8} />
              ) : (
                <Repeat size={20} color={repeatMode === 'all' ? colors.primary : colors.textSecondary} strokeWidth={1.8} />
              )}
            </TouchableOpacity>
          </View>

          <View style={styles.secondaryControls}>
            <TouchableOpacity style={styles.volBtn} onPress={toggleMute}>
              {muted || volume === 0 ? <VolumeX size={18} color={colors.textSecondary} strokeWidth={1.8} /> : <Volume2 size={18} color={colors.textSecondary} strokeWidth={1.8} />}
            </TouchableOpacity>
            <View style={styles.volumeBar}>
              <View style={styles.volumeTrack}>
                <View style={[styles.volumeFill, { width: `${(muted ? 0 : volume) * 100}%` as any }]} />
              </View>
            </View>
          </View>

          <View style={styles.skipRow}>
            <TouchableOpacity style={styles.skipBtn} onPress={() => skip(-10)}>
              <SkipBack size={16} color={colors.textSecondary} strokeWidth={1.8} />
              <Text style={styles.skipBtnText}>-10s</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.skipBtn} onPress={() => skip(10)}>
              <SkipForward size={16} color={colors.textSecondary} strokeWidth={1.8} />
              <Text style={styles.skipBtnText}>+10s</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>

        {showPlaylist && (
          <View style={styles.playlistOverlay}>
            <TouchableOpacity style={styles.playlistBackdrop} onPress={() => setShowPlaylist(false)} />
            <View style={styles.playlistPanel}>
              <LinearGradient colors={['#030C1A', '#000814']} style={StyleSheet.absoluteFill} />
              <View style={styles.playlistHeader}>
                <Text style={styles.playlistTitle}>{t('playlist')}</Text>
                <Text style={styles.playlistCount}>{files.length} {t('files')}</Text>
              </View>
              <ScrollView style={styles.playlistScroll} showsVerticalScrollIndicator={false}>
                {files.map((file, i) => (
                  <TouchableOpacity
                    key={file.id}
                    style={[styles.playlistItem, i === currentIndex && styles.playlistItemActive]}
                    onPress={() => { selectTrack(i); setShowPlaylist(false); }}
                  >
                    <View style={[styles.playlistIcon, i === currentIndex && styles.playlistIconActive]}>
                      {i === currentIndex && playing ? (
                        <View style={styles.playingBars}>
                          <View style={[styles.playingBar, styles.playingBar1]} />
                          <View style={[styles.playingBar, styles.playingBar2]} />
                          <View style={[styles.playingBar, styles.playingBar3]} />
                        </View>
                      ) : (
                        <Music size={18} color={i === currentIndex ? colors.primary : colors.textTertiary} strokeWidth={1.5} />
                      )}
                    </View>
                    <View style={styles.playlistInfo}>
                      <Text style={[styles.playlistName, i === currentIndex && styles.playlistNameActive]} numberOfLines={1}>{file.name}</Text>
                      <Text style={styles.playlistMeta}>
                        {formatBytes(file.size)}
                        {file.duration_seconds ? ` · ${formatDuration(file.duration_seconds)}` : ''}
                      </Text>
                    </View>
                    {i === currentIndex && <View style={styles.activeDot} />}
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
          </View>
        )}

        {Platform.OS === 'web' && currentFile.storage_url && (
          <audio ref={audioRef} src={currentFile.storage_url} preload="metadata" style={{ display: 'none' }} />
        )}
      </View>
    </PlayerWindow>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.xl, paddingBottom: spacing.md,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { color: colors.text, fontSize: 20, fontWeight: '700' },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: spacing.xl, paddingBottom: 100 },
  artworkContainer: { alignItems: 'center', marginVertical: spacing.xl },
  artwork: {
    width: 220, height: 220, borderRadius: 110,
    alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
    shadowColor: colors.primary, shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.4, shadowRadius: 32, elevation: 20,
  },
  artworkGlow: {
    position: 'absolute', bottom: -10, width: 180, height: 30,
    backgroundColor: colors.primary, opacity: 0.15, borderRadius: 15,
    transform: [{ scaleX: 2 }],
  },
  trackInfo: { alignItems: 'center', marginBottom: spacing.xl },
  nowPlaying: { color: colors.textTertiary, fontSize: 12, fontWeight: '500', letterSpacing: 1, textTransform: 'uppercase' as any },
  trackName: { color: colors.text, fontSize: 22, fontWeight: '700', textAlign: 'center', marginTop: 6, lineHeight: 28 },
  trackMeta: { color: colors.textSecondary, fontSize: 13, marginTop: 6 },
  progressSection: { marginBottom: spacing.xl },
  progressBar: { height: 28, justifyContent: 'center' },
  progressTrack: {
    height: 5, backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 3, overflow: 'visible', position: 'relative',
  },
  progressFill: { height: '100%', backgroundColor: colors.primary, borderRadius: 3 },
  progressThumb: {
    position: 'absolute', top: -6, width: 16, height: 16, borderRadius: 8,
    backgroundColor: '#fff', marginLeft: -8,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.3, shadowRadius: 4,
  },
  timeRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 },
  timeText: { color: colors.textTertiary, fontSize: 12, fontWeight: '500' },
  mainControls: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.lg, marginBottom: spacing.xl,
  },
  controlIcon: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  controlIconActive: { backgroundColor: colors.primary + '20' },
  skipControl: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center', justifyContent: 'center',
  },
  playBtn: {
    width: 72, height: 72, borderRadius: 36, backgroundColor: colors.primary,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: colors.primary, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.4, shadowRadius: 16,
    elevation: 10,
  },
  secondaryControls: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    paddingHorizontal: spacing.lg, marginBottom: spacing.lg,
  },
  volBtn: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  volumeBar: { flex: 1, height: 24, justifyContent: 'center' },
  volumeTrack: { height: 3, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 2, overflow: 'hidden' },
  volumeFill: { height: '100%', backgroundColor: colors.textSecondary, borderRadius: 2 },
  skipRow: { flexDirection: 'row', justifyContent: 'center', gap: spacing.xl, marginBottom: spacing.xl },
  skipBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: radius.full,
  },
  skipBtnText: { color: colors.textSecondary, fontSize: 12, fontWeight: '500' },
  playlistOverlay: { ...StyleSheet.absoluteFillObject, zIndex: 50, flexDirection: 'row' },
  playlistBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)' },
  playlistPanel: {
    width: width * 0.8, maxWidth: 380,
    overflow: 'hidden', borderLeftWidth: 1, borderLeftColor: 'rgba(30,111,255,0.2)',
  },
  playlistHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingBottom: spacing.md,
  },
  playlistTitle: { color: colors.text, fontSize: 18, fontWeight: '700' },
  playlistCount: { color: colors.textTertiary, fontSize: 13 },
  playlistScroll: { flex: 1, paddingHorizontal: spacing.md },
  playlistItem: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    padding: spacing.sm, borderRadius: radius.md, marginBottom: 4,
  },
  playlistItemActive: { backgroundColor: 'rgba(30,111,255,0.15)' },
  playlistIcon: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center', justifyContent: 'center',
  },
  playlistIconActive: { backgroundColor: colors.primary + '20' },
  playingBars: { flexDirection: 'row', gap: 2, alignItems: 'flex-end', height: 18 },
  playingBar: { width: 3, backgroundColor: colors.primary, borderRadius: 1 },
  playingBar1: { height: 8 },
  playingBar2: { height: 14 },
  playingBar3: { height: 10 },
  playlistInfo: { flex: 1 },
  playlistName: { color: colors.text, fontSize: 13, fontWeight: '500' },
  playlistNameActive: { color: colors.primary, fontWeight: '600' },
  playlistMeta: { color: colors.textTertiary, fontSize: 11, marginTop: 2 },
  activeDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary },
  emptyContainer: { flex: 1, backgroundColor: colors.background },
  emptyWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.sm },
  emptyTitle: { color: colors.text, fontSize: 18, fontWeight: '600' },
  emptySub: { color: colors.textSecondary, fontSize: 13, textAlign: 'center' },
});
