import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  ActivityIndicator,
  Platform,
  Share,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  X, FileText, ChevronRight, Download, Share2,
  File, FileType, FileType2, Sheet, Presentation, Code,
  Search, Calendar, HardDrive,
} from 'lucide-react-native';
import { FileRecord, formatBytes } from '@/lib/files';
import { downloadFileModern } from '@/lib/download';
import { useLanguage } from '@/context/LanguageContext';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { PlayerWindow, WindowMode } from './PlayerWindow';

const { width, height } = Dimensions.get('window');

type Props = {
  files: FileRecord[];
  onBack: () => void;
};

function getDocIcon(mimeType: string): typeof FileText {
  if (mimeType.includes('pdf')) return FileText;
  if (mimeType.includes('word') || mimeType.includes('document')) return FileType;
  if (mimeType.includes('sheet') || mimeType.includes('excel') || mimeType.includes('spreadsheet')) return Sheet;
  if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) return Presentation;
  if (mimeType.includes('text/') || mimeType.includes('json') || mimeType.includes('xml') || mimeType.includes('code')) return Code;
  return File;
}

function getDocColor(mimeType: string): string {
  if (mimeType.includes('pdf')) return '#FF3B30';
  if (mimeType.includes('word') || mimeType.includes('document')) return colors.primary;
  if (mimeType.includes('sheet') || mimeType.includes('excel')) return '#34C759';
  if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) return '#FF9F0A';
  if (mimeType.includes('text/')) return colors.secondary;
  return '#6B7280';
}

export function DocumentViewerFull({ files, onBack }: Props) {
  const { t } = useLanguage();
  const [selected, setSelected] = useState<FileRecord | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [downloading, setDownloading] = useState(false);
  const [downloadToast, setDownloadToast] = useState<string | null>(null);
  const [windowMode, setWindowMode] = useState<WindowMode>('windowed');

  const filtered = searchQuery
    ? files.filter(f => f.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : files;

  async function handleDownload(file: FileRecord) {
    setDownloading(true);
    const result = await downloadFileModern(file);
    setDownloading(false);
    if (result.success) setDownloadToast(`✓ ${file.name} endirildi`);
    else setDownloadToast(`✕ ${result.error ?? 'Xəta'}`);
    setTimeout(() => setDownloadToast(null), 3000);
  }

  async function handleShare(file: FileRecord) {
    if (!file.storage_url) return;
    try {
      if (Platform.OS === 'web') {
        if (navigator.share) await navigator.share({ title: file.name, url: file.storage_url });
        else { await navigator.clipboard.writeText(file.storage_url); Alert.alert('Link Copied', 'Document link copied to clipboard.'); }
      } else {
        await Share.share({ message: `${file.name}\n${file.storage_url}`, url: file.storage_url });
      }
    } catch {}
  }

  if (selected) {
    return (
      <PlayerWindow
        title={selected.name}
        subtitle={`${formatBytes(selected.size)} · ${selected.mime_type}`}
        mode={windowMode}
        onModeChange={setWindowMode}
        onClose={() => setSelected(null)}
        onBack={() => setSelected(null)}
        accentColor={getDocColor(selected.mime_type)}
        minimizedContent={(() => {
          const Icon = getDocIcon(selected.mime_type);
          return <Icon size={18} color={getDocColor(selected.mime_type)} strokeWidth={1.8} />;
        })()}
      >
        <View style={styles.viewerContainer}>
          <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />

          <View style={styles.viewerActions}>
            <TouchableOpacity style={styles.actionBtn2} onPress={() => handleShare(selected)}>
              <Share2 size={18} color={colors.text} strokeWidth={1.8} />
              <Text style={styles.actionBtnText}>{t('share') || 'Share'}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionBtn2} onPress={() => handleDownload(selected)} disabled={downloading}>
              {downloading ? <ActivityIndicator size="small" color={colors.text} /> : <Download size={18} color={colors.text} strokeWidth={1.8} />}
              <Text style={styles.actionBtnText}>{t('download') || 'Download'}</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.docContent}>
            {Platform.OS === 'web' && selected.storage_url ? (
              selected.mime_type === 'application/pdf' ? (
                <iframe src={selected.storage_url} style={{ width: '100%', height: '100%', border: 'none' }} title={selected.name} />
              ) : selected.mime_type.startsWith('text/') ? (
                <TextFileViewer url={selected.storage_url} />
              ) : (
                <iframe src={`https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(selected.storage_url)}`} style={{ width: '100%', height: '100%', border: 'none' }} title={selected.name} />
              )
            ) : (
              <View style={styles.noPreview}>
                <FileText size={56} color={colors.textTertiary} strokeWidth={1.5} />
                <Text style={styles.noPreviewName}>{selected.name}</Text>
                <Text style={styles.noPreviewMeta}>{formatBytes(selected.size)}</Text>
                <TouchableOpacity style={styles.downloadBtn} onPress={() => handleDownload(selected)}>
                  <Download size={18} color="#fff" strokeWidth={2} />
                  <Text style={styles.downloadBtnText}>{t('download') || 'Download'}</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>

          {downloadToast && (
            <View style={styles.toastWrap}>
              <View style={styles.toastCard}>
                <Text style={styles.toastText}>{downloadToast}</Text>
              </View>
            </View>
          )}
        </View>
      </PlayerWindow>
    );
  }

  return (
    <PlayerWindow
      title={t('document_viewer')}
      subtitle={`${files.length} ${t('files')}`}
      mode={windowMode}
      onModeChange={setWindowMode}
      onClose={onBack}
      onBack={onBack}
      accentColor={colors.primary}
      minimizedContent={<FileText size={18} color={colors.primary} strokeWidth={1.8} />}
    >
      <View style={styles.container}>
        <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />

        <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {files.length === 0 ? (
            <View style={styles.emptyWrap}>
              <FileText size={56} color={colors.textTertiary} strokeWidth={1.5} />
              <Text style={styles.emptyTitle}>{t('no_document_files')}</Text>
              <Text style={styles.emptySub}>{t('players_empty_sub')}</Text>
            </View>
          ) : (
            <View style={styles.fileList}>
              {filtered.map((file) => {
                const Icon = getDocIcon(file.mime_type);
                const color = getDocColor(file.mime_type);
                return (
                  <TouchableOpacity
                    key={file.id}
                    style={styles.fileItem}
                    onPress={() => setSelected(file)}
                    activeOpacity={0.7}
                  >
                    <View style={[styles.fileIcon, { backgroundColor: color + '18' }]}>
                      <Icon size={22} color={color} strokeWidth={1.8} />
                    </View>
                    <View style={styles.fileInfo}>
                      <Text style={styles.fileName} numberOfLines={1}>{file.name}</Text>
                      <View style={styles.fileMetaRow}>
                        <Text style={styles.fileMeta}>{formatBytes(file.size)}</Text>
                        <Text style={styles.fileMetaDot}>·</Text>
                        <Text style={styles.fileMeta}>{file.mime_type.split('/').pop()?.toUpperCase()}</Text>
                        <Text style={styles.fileMetaDot}>·</Text>
                        <Text style={styles.fileMeta}>{new Date(file.created_at).toLocaleDateString()}</Text>
                      </View>
                    </View>
                    <ChevronRight size={18} color={colors.textTertiary} strokeWidth={2} />
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </ScrollView>

        {downloadToast && (
          <View style={styles.toastWrap}>
            <View style={styles.toastCard}>
              <Text style={styles.toastText}>{downloadToast}</Text>
            </View>
          </View>
        )}
      </View>
    </PlayerWindow>
  );
}

function TextFileViewer({ url }: { url: string }) {
  const [content, setContent] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    fetch(url)
      .then(res => res.text())
      .then(text => { setContent(text); setLoading(false); })
      .catch(() => { setError(true); setLoading(false); });
  }, [url]);

  if (loading) {
    return (
      <View style={styles.textLoading}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }
  if (error) {
    return (
      <View style={styles.textLoading}>
        <FileText size={40} color={colors.textTertiary} strokeWidth={1.5} />
        <Text style={styles.textError}>Could not load file</Text>
      </View>
    );
  }
  return (
    <ScrollView style={styles.textScroll} contentContainerStyle={styles.textContent}>
      <Text style={styles.textContent2}>{content}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: spacing.xl, paddingBottom: 100 },
  fileList: { gap: spacing.sm },
  fileItem: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    backgroundColor: colors.surface, borderRadius: radius.lg,
    padding: spacing.md, borderWidth: 1, borderColor: colors.border,
  },
  fileIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  fileInfo: { flex: 1 },
  fileName: { color: colors.text, fontSize: 14, fontWeight: '500' },
  fileMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  fileMeta: { color: colors.textTertiary, fontSize: 11 },
  fileMetaDot: { color: colors.textTertiary, fontSize: 11 },
  emptyWrap: { alignItems: 'center', justifyContent: 'center', paddingVertical: spacing.xxl, gap: spacing.sm },
  emptyTitle: { color: colors.text, fontSize: 18, fontWeight: '600' },
  emptySub: { color: colors.textSecondary, fontSize: 13, textAlign: 'center' },
  viewerContainer: { flex: 1, backgroundColor: colors.background },
  viewerActions: {
    flexDirection: 'row', justifyContent: 'flex-end', gap: spacing.md,
    paddingHorizontal: spacing.lg, paddingBottom: spacing.sm,
  },
  actionBtn2: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: radius.md,
  },
  actionBtnText: { color: colors.text, fontSize: 13, fontWeight: '500' },
  docContent: { flex: 1, backgroundColor: '#fff', borderRadius: radius.lg, overflow: 'hidden', marginHorizontal: spacing.xl, marginBottom: spacing.xl },
  noPreview: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.md, backgroundColor: colors.background },
  noPreviewName: { color: colors.text, fontSize: 16, fontWeight: '600', textAlign: 'center', paddingHorizontal: 32 },
  noPreviewMeta: { color: colors.textSecondary, fontSize: 14 },
  downloadBtn: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    paddingHorizontal: spacing.xl, paddingVertical: spacing.md,
    backgroundColor: colors.primary, borderRadius: radius.full, marginTop: spacing.md,
  },
  downloadBtnText: { color: '#fff', fontSize: 14, fontWeight: '600' },
  textLoading: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.md },
  textError: { color: colors.textSecondary, fontSize: 14 },
  textScroll: { flex: 1, backgroundColor: '#1a1a2e' },
  textContent: { padding: spacing.lg },
  textContent2: { color: '#e0e0e0', fontSize: 13, fontFamily: 'monospace', lineHeight: 20 },
  toastWrap: {
    position: 'absolute', bottom: 100, left: spacing.lg, right: spacing.lg,
    zIndex: 1000, alignItems: 'center',
  },
  toastCard: {
    backgroundColor: 'rgba(10,20,40,0.95)', borderRadius: radius.lg,
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)',
  },
  toastText: { color: colors.text, fontSize: 13, fontWeight: '500' },
});
