import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Animated,
  TextInput, ScrollView, Image, Easing,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Sparkles, Send, ChevronDown, ChevronRight, FileText, Image as ImgIcon, Film, Music, Folder } from 'lucide-react-native';
import { router } from 'expo-router';
import { colors, spacing, radius } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import { listFiles, getFileStats, formatBytes } from '@/lib/files';
import { useLanguage } from '@/context/LanguageContext';
import { useDrawer } from '@/context/DrawerContext';

const EVA_LOGO = require('../assets/images/eva-logo.png');

type Message = {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  action?: { label: string; route: string; category?: string };
};

const QUICK_ACTIONS = [
  { label: 'Hamısı', route: '/(tabs)/storage', category: 'all', Icon: Folder, color: colors.primary },
  { label: 'Şəkillər', route: '/(tabs)/storage', category: 'photos', Icon: ImgIcon, color: '#FF9F0A' },
  { label: 'Videolar', route: '/(tabs)/storage', category: 'videos', Icon: Film, color: '#FF3B30' },
  { label: 'Musiqi', route: '/(tabs)/storage', category: 'music', Icon: Music, color: '#34C759' },
  { label: 'Sənədlər', route: '/(tabs)/storage', category: 'documents', Icon: FileText, color: '#1E6FFF' },
];

async function buildResponse(
  input: string,
  userId: string
): Promise<{ text: string; action?: { label: string; route: string } }> {
  const q = input.toLowerCase().trim();

  if (/home|ana|əsas/.test(q))
    return { text: 'Ana səhifəyə gedirəm.', action: { label: 'Ana Səhifə', route: '/(tabs)/' } };
  if (/storage|yaddaş|fayl|cloud/.test(q))
    return { text: 'Yaddaş bölməsinə gedirəm.', action: { label: 'Yaddaş', route: '/(tabs)/storage' } };
  if (/security|təhlükəsizlik/.test(q))
    return { text: 'Təhlükəsizlik mərkəzinə gedirəm.', action: { label: 'Təhlükəsizlik', route: '/(tabs)/security' } };
  if (/profile|profil/.test(q))
    return { text: 'Profil bölməsinə gedirəm.', action: { label: 'Profil', route: '/(tabs)/profile' } };
  if (/trash|zibil/.test(q))
    return { text: 'Zibil qutusuna gedirəm.', action: { label: 'Zibil', route: '/(tabs)/trash' } };

  if (/şəkil|photo|image|foto/.test(q)) {
    try {
      const files = await listFiles(userId, 'photos');
      if (files.length === 0) return { text: 'Şəkil yoxdur.' };
      return {
        text: `${files.length} şəkil var (${formatBytes(files.reduce((s, f) => s + f.size, 0))})`,
        action: { label: 'Şəkillər', route: '/(tabs)/storage' },
      };
    } catch { return { text: 'Yüklənə bilmədi.' }; }
  }

  if (/video/.test(q)) {
    try {
      const files = await listFiles(userId, 'videos');
      if (files.length === 0) return { text: 'Video yoxdur.' };
      return {
        text: `${files.length} video var`,
        action: { label: 'Videolar', route: '/(tabs)/storage' },
      };
    } catch { return { text: 'Yüklənə bilmədi.' }; }
  }

  if (/stat|neçə|nə qədər|how many/.test(q)) {
    try {
      const stats = await getFileStats(userId);
      return {
        text: `${stats.total_count} fayl, ${formatBytes(stats.total_size)}`,
        action: { label: 'Bax', route: '/(tabs)/storage' },
      };
    } catch { return { text: 'Statistika yoxdur.' }; }
  }

  if (/help|kömək|necə/.test(q))
    return { text: 'EVA Cloud X bulud yaddaş tətbiqidir. Fayl yükləyin, sili̇n, bölüşün. Soruşun!' };

  const defaults = [
    'Sualınız var? Fayllar, yaddaş, təhlükəsizlik haqqında soruşun.',
    'Necə kömək edə bilərəm?',
  ];
  return { text: defaults[Math.floor(Math.random() * defaults.length)] };
}

export function EvaDrawerSection() {
  const [expanded, setExpanded] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [typing, setTyping] = useState(false);
  const expandAnim = useRef(new Animated.Value(0)).current;
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const scrollRef = useRef<ScrollView>(null);
  const { user } = useAuth();
  const { closeDrawer } = useDrawer();
  const { t } = useLanguage();

  useEffect(() => {
    Animated.parallel([
      Animated.timing(expandAnim, {
        toValue: expanded ? 1 : 0,
        duration: 300,
        easing: Easing.out(Easing.quad),
        useNativeDriver: false,
      }),
      Animated.timing(rotateAnim, {
        toValue: expanded ? 1 : 0,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start();
  }, [expanded]);

  const rotate = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '180deg'],
  });

  const height = expandAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 320],
  });

  async function send(text?: string) {
    const msg = (text ?? input).trim();
    if (!msg || !user) return;
    setInput('');

    const userMsg: Message = { id: Date.now().toString(), role: 'user', text: msg };
    setMessages(prev => [...prev, userMsg]);
    setTyping(true);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 50);

    await new Promise(r => setTimeout(r, 500 + Math.random() * 400));
    const resp = await buildResponse(msg, user.id);
    setTyping(false);

    const assistantMsg: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      text: resp.text,
      action: resp.action,
    };
    setMessages(prev => [...prev, assistantMsg]);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80);
  }

  function navigate(route: string, category?: string) {
    closeDrawer();
    if (category) {
      // Store the category so storage screen can pick it up
      // @ts-ignore
      if (typeof globalThis !== 'undefined') {
        // @ts-ignore
        globalThis.__pendingCategory = category;
      }
    }
    setTimeout(() => router.push(route as any), 200);
  }

  return (
    <View style={styles.container}>
      {/* Header - clickable to expand/collapse */}
      <TouchableOpacity
        style={styles.header}
        onPress={() => setExpanded(e => !e)}
        activeOpacity={0.8}
      >
        <LinearGradient colors={['rgba(30,111,255,0.12)', 'rgba(0,212,255,0.05)']} style={StyleSheet.absoluteFill} />
        <Image source={EVA_LOGO} style={styles.logo} resizeMode="contain" />
        <View style={styles.headerText}>
          <Text style={styles.title}>EVA AI</Text>
          <View style={styles.badge}>
            <Sparkles size={10} color={colors.primary} strokeWidth={2} />
            <Text style={styles.badgeText}>{t('eva_assistant') || 'Assistant'}</Text>
          </View>
        </View>
        <Animated.View style={{ transform: [{ rotate }] }}>
          <ChevronDown size={20} color={colors.textSecondary} strokeWidth={2} />
        </Animated.View>
      </TouchableOpacity>

      {/* Expanded content */}
      <Animated.View style={[styles.content, { height }]}>
        <ScrollView
          ref={scrollRef}
          style={styles.messagesScroll}
          contentContainerStyle={styles.messagesContent}
          showsVerticalScrollIndicator={false}
        >
          {/* Quick action buttons */}
          {messages.length === 0 && (
            <View style={styles.quickActions}>
              {QUICK_ACTIONS.map(qa => (
                <TouchableOpacity
                  key={qa.label}
                  style={styles.quickBtn}
                  onPress={() => navigate(qa.route, qa.category)}
                >
                  <View style={[styles.quickIcon, { backgroundColor: qa.color + '20' }]}>
                    <qa.Icon size={12} color={qa.color} strokeWidth={1.8} />
                  </View>
                  <Text style={styles.quickText}>{qa.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Messages */}
          {messages.map(msg => (
            <View key={msg.id} style={[styles.msgBubble, msg.role === 'user' && styles.userBubble]}>
              {msg.role === 'assistant' && (
                <Image source={EVA_LOGO} style={styles.msgLogo} resizeMode="contain" />
              )}
              <View style={[styles.msgTextWrap, msg.role === 'user' && styles.userMsgWrap]}>
                <Text style={styles.msgText}>{msg.text}</Text>
                {msg.action && (
                  <TouchableOpacity style={styles.actionBtn} onPress={() => navigate(msg.action!.route)}>
                    <Text style={styles.actionBtnText}>{msg.action.label}</Text>
                    <ChevronRight size={12} color={colors.primary} strokeWidth={2} />
                  </TouchableOpacity>
                )}
              </View>
            </View>
          ))}
          {typing && (
            <View style={styles.msgBubble}>
              <Image source={EVA_LOGO} style={styles.msgLogo} resizeMode="contain" />
              <View style={styles.typingDots}>
                {[0, 1, 2].map(i => <View key={i} style={styles.typingDot} />)}
              </View>
            </View>
          )}
        </ScrollView>

        {/* Input */}
        <View style={styles.inputRow}>
          <TextInput
            style={styles.input}
            value={input}
            onChangeText={setInput}
            placeholder={t('ask_eva') || 'Soruşun...'}
            placeholderTextColor={colors.textTertiary}
            multiline
            maxLength={200}
            returnKeyType="send"
            onSubmitEditing={() => send()}
          />
          <TouchableOpacity
            style={[styles.sendBtn, !input.trim() && styles.sendBtnDisabled]}
            onPress={() => send()}
            disabled={!input.trim()}
          >
            <LinearGradient
              colors={input.trim() ? ['#1E6FFF', '#00D4FF'] : ['#333', '#333']}
              style={StyleSheet.absoluteFill}
            />
            <Send size={14} color="#fff" strokeWidth={2} />
          </TouchableOpacity>
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: spacing.xl,
    marginBottom: spacing.md,
    borderRadius: radius.lg,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(30,111,255,0.15)',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
    gap: spacing.md,
  },
  logo: { width: 28, height: 28 },
  headerText: { flex: 1 },
  title: { color: colors.text, fontSize: 14, fontWeight: '700' },
  badge: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 },
  badgeText: { color: colors.primary, fontSize: 10, fontWeight: '500' },
  content: {
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  messagesScroll: { flex: 1 },
  messagesContent: { padding: spacing.md, gap: spacing.sm },
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    marginBottom: spacing.sm,
  },
  quickBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,255,255,0.06)',
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: radius.md,
  },
  quickIcon: { width: 18, height: 18, borderRadius: 6, alignItems: 'center', justifyContent: 'center' },
  quickText: { color: colors.textSecondary, fontSize: 11, fontWeight: '500' },
  msgBubble: { flexDirection: 'row', gap: 6, alignItems: 'flex-end' },
  userBubble: { justifyContent: 'flex-end' },
  msgLogo: { width: 18, height: 18, borderRadius: 9 },
  msgTextWrap: {
    maxWidth: '85%',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: radius.md,
    padding: 8,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
  },
  userMsgWrap: {
    backgroundColor: colors.primary + '22',
    borderColor: colors.primary + '30',
  },
  msgText: { color: colors.text, fontSize: 12, lineHeight: 16 },
  actionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 6,
    paddingTop: 6,
    borderTopWidth: 1,
    borderTopColor: 'rgba(30,111,255,0.2)',
  },
  actionBtnText: { color: colors.primary, fontSize: 11, fontWeight: '600' },
  typingDots: { flexDirection: 'row', gap: 3, padding: 8 },
  typingDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: colors.textSecondary },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: spacing.sm,
    gap: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.06)',
  },
  input: {
    flex: 1,
    color: colors.text,
    fontSize: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: radius.md,
    paddingHorizontal: 10,
    paddingVertical: 6,
    maxHeight: 60,
  },
  sendBtn: {
    width: 30, height: 30, borderRadius: 15,
    overflow: 'hidden', alignItems: 'center', justifyContent: 'center',
  },
  sendBtnDisabled: { opacity: 0.4 },
});
