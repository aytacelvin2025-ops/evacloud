import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Platform,
} from 'react-native';
import { Play, Pause, Volume2, SkipBack, SkipForward } from 'lucide-react-native';
import { colors, spacing, radius } from '@/constants/theme';
import { formatDuration, FileRecord } from '@/lib/files';

type MusicPlayerProps = {
  file: FileRecord;
  url: string;
};

export function MusicPlayer({ file, url }: MusicPlayerProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(file.duration_seconds ?? 0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (Platform.OS === 'web' && audioRef.current) {
      const audio = audioRef.current;
      const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
      const handleLoadedMetadata = () => {
        setDuration(audio.duration);
        setLoading(false);
      };
      const handleEnded = () => setPlaying(false);

      audio.addEventListener('timeupdate', handleTimeUpdate);
      audio.addEventListener('loadedmetadata', handleLoadedMetadata);
      audio.addEventListener('ended', handleEnded);

      return () => {
        audio.removeEventListener('timeupdate', handleTimeUpdate);
        audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
        audio.removeEventListener('ended', handleEnded);
      };
    }
    return () => {};
  }, []);

  function togglePlay() {
    if (!audioRef.current) return;
    if (playing) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setPlaying(!playing);
  }

  function seek(time: number) {
    if (!audioRef.current) return;
    audioRef.current.currentTime = time;
    setCurrentTime(time);
  }

  function skip(seconds: number) {
    if (!audioRef.current) return;
    const newTime = Math.max(0, Math.min(duration, currentTime + seconds));
    audioRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  }

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <View style={styles.container}>
      <View style={styles.artworkContainer}>
        <View style={styles.artwork}>
          <Volume2 size={48} color={colors.primary} strokeWidth={1.5} />
        </View>
      </View>
      <Text style={styles.title} numberOfLines={1}>{file.name}</Text>
      <Text style={styles.artist}>{file.mime_type.split('/')[1]?.toUpperCase() || 'Audio'}</Text>
      {loading ? (
        <ActivityIndicator color={colors.primary} style={{ marginVertical: 20 }} />
      ) : (
        <>
          <View style={styles.progressContainer}>
            <Text style={styles.time}>{formatDuration(currentTime)}</Text>
            <TouchableOpacity style={styles.progressBar} onPress={(e) => {
              // @ts-ignore
              const rect = e.currentTarget.getBoundingClientRect();
              // @ts-ignore
              const x = e.nativeEvent.clientX - rect.left;
              const percent = x / rect.width;
              seek(percent * duration);
            }}>
              <View style={styles.progressTrack}>
                <View style={[styles.progressFill, { width: `${progress}%` as any }]} />
              </View>
            </TouchableOpacity>
            <Text style={styles.time}>{formatDuration(duration)}</Text>
          </View>
          <View style={styles.controls}>
            <TouchableOpacity style={styles.skipBtn} onPress={() => skip(-10)}>
              <SkipBack size={24} color={colors.text} strokeWidth={1.8} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.playBtn} onPress={togglePlay}>
              {playing ? (
                <Pause size={32} color="#fff" strokeWidth={2} />
              ) : (
                <Play size={32} color="#fff" strokeWidth={2} />
              )}
            </TouchableOpacity>
            <TouchableOpacity style={styles.skipBtn} onPress={() => skip(10)}>
              <SkipForward size={24} color={colors.text} strokeWidth={1.8} />
            </TouchableOpacity>
          </View>
        </>
      )}
      {Platform.OS === 'web' && (
        <audio
          ref={audioRef}
          src={url}
          preload="metadata"
          style={{ display: 'none' }}
        />
      )}
    </View>
  );
}

type PdfViewerProps = {
  url: string;
  name: string;
};

export function PdfViewer({ url, name }: PdfViewerProps) {
  if (Platform.OS === 'web') {
    return (
      <iframe
        src={url}
        style={{ width: '100%', height: '100%', border: 'none' }}
        title={name}
      />
    );
  }
  return (
    <View style={styles.fallback}>
      <Text style={styles.fallbackText}>PDF viewing requires web browser</Text>
    </View>
  );
}

type DocumentViewerProps = {
  url: string;
  name: string;
  mimeType: string;
};

export function DocumentViewer({ url, name, mimeType }: DocumentViewerProps) {
  // For web, we can use Google Docs Viewer or similar
  if (Platform.OS === 'web') {
    // Check if it's a viewable type
    const isImageViewable = mimeType.startsWith('image/');
    const isPdfViewable = mimeType === 'application/pdf';
    const isTextViewable = mimeType.startsWith('text/');

    if (isPdfViewable) {
      return <PdfViewer url={url} name={name} />;
    }

    if (isImageViewable) {
      return (
        <View style={styles.fallback}>
          <Text style={styles.fallbackText}>Image should open in image viewer</Text>
        </View>
      );
    }

    // For docs, use Google Docs viewer or Office Online
    const googleViewerUrl = `https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(url)}`;
    return (
      <iframe
        src={googleViewerUrl}
        style={{ width: '100%', height: '100%', border: 'none' }}
        title={name}
      />
    );
  }

  return (
    <View style={styles.fallback}>
      <Text style={styles.fallbackText}>Document viewing requires web browser</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
    gap: spacing.md,
  },
  artworkContainer: {
    marginBottom: spacing.lg,
  },
  artwork: {
    width: 200,
    height: 200,
    borderRadius: 24,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 24,
    elevation: 12,
  },
  title: {
    color: colors.text,
    fontSize: 18,
    fontWeight: '700',
    textAlign: 'center',
  },
  artist: {
    color: colors.textSecondary,
    fontSize: 14,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.md,
    width: '100%',
  },
  time: {
    color: colors.textTertiary,
    fontSize: 12,
    minWidth: 40,
  },
  progressBar: {
    flex: 1,
    height: 24,
    justifyContent: 'center',
  },
  progressTrack: {
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 2,
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xl,
  },
  playBtn: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  skipBtn: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  fallback: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  fallbackText: {
    color: colors.textSecondary,
    fontSize: 14,
    textAlign: 'center',
  },
});
