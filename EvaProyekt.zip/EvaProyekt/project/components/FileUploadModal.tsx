import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, Modal, TouchableOpacity, ActivityIndicator, Platform, Animated,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { LinearGradient } from 'expo-linear-gradient';
import { X, Image as ImageIcon, FileText, Upload, Minus, Trash2, Check } from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { uploadFile } from '@/lib/files';
import { colors, spacing, radius, typography } from '@/constants/theme';

type PickType = 'media' | 'document' | 'any';

type UploadItem = {
  uri: string;
  name: string;
  mimeType: string;
  size: number;
};

type UploadTask = {
  item: UploadItem;
  status: 'pending' | 'uploading' | 'success' | 'error';
  progress: number;
  error?: string;
};

type Props = {
  visible: boolean;
  onClose: () => void;
  onUploaded: () => void;
};

const PICK_OPTIONS = [
  { label: ' Photos & Videos', labelAz: 'Şəkil və Video', icon: ImageIcon, color: '#FF9F0A', type: 'media' as PickType },
  { label: 'Documents', labelAz: 'Sənədlər', icon: FileText, color: colors.primary, type: 'document' as PickType },
  { label: 'Any File', labelAz: 'Hər Hansı Fayl', icon: Upload, color: '#A066FF', type: 'any' as PickType },
];

export function FileUploadModal({ visible, onClose, onUploaded }: Props) {
  const { user } = useAuth();
  const [phase, setPhase] = useState<'options' | 'uploading'>('options');
  const [tasks, setTasks] = useState<UploadTask[]>([]);
  const [error, setError] = useState('');
  const [minimized, setMinimized] = useState(false);
  const abortRef = useRef(false);
  const mounted = useRef(true);
  const progressAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => { return () => { mounted.current = false; }; }, []);

  useEffect(() => {
    if (visible) {
      setPhase('options');
      setTasks([]);
      setError('');
      setMinimized(false);
      abortRef.current = false;
    }
  }, [visible]);

  async function getPlatformItems(type: PickType): Promise<UploadItem[]> {
    if (Platform.OS === 'web') {
      return pickFromWebInput(type === 'media' ? 'image/*,video/*,audio/*' : '*/*');
    }

    if (type === 'media') {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        setError('Qalereya icazəsi yoxdur.');
        return [];
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.All,
        allowsMultipleSelection: true,
        quality: 1,
      });
      if (result.canceled || !result.assets?.length) return [];
      return result.assets.map(a => ({
        uri: a.uri,
        name: a.fileName ?? `file_${Date.now()}`,
        mimeType: a.mimeType ?? 'application/octet-stream',
        size: a.fileSize ?? 0,
      }));
    }

    const result = await DocumentPicker.getDocumentAsync({
      type: '*/*',
      multiple: true,
      copyToCacheDirectory: true,
    });
    if (result.canceled || !result.assets?.length) return [];
    return result.assets.map(a => ({
      uri: a.uri,
      name: a.name,
      mimeType: a.mimeType ?? 'application/octet-stream',
      size: a.size ?? 0,
    }));
  }

  function pickFromWebInput(accept: string): Promise<UploadItem[]> {
    return new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = accept;
      input.multiple = true;
      input.onchange = () => {
        const files = Array.from(input.files ?? []);
        resolve(files.map(f => ({
          uri: URL.createObjectURL(f),
          name: f.name,
          mimeType: f.type || 'application/octet-stream',
          size: f.size,
        })));
      };
      input.oncancel = () => resolve([]);
      input.click();
    });
  }

  async function startUpload(type: PickType) {
    if (!user || !mounted.current) return;

    const items = await getPlatformItems(type);
    if (!items.length) return;

    const newTasks: UploadTask[] = items.map(item => ({
      item,
      status: 'pending',
      progress: 0,
    }));
    setTasks(newTasks);
    setPhase('uploading');
    setError('');

    let successCount = 0;
    for (let i = 0; i < newTasks.length; i++) {
      if (abortRef.current || !mounted.current) break;

      setTasks(prev => prev.map((t, idx) =>
        idx === i ? { ...t, status: 'uploading' } : t
      ));

      const result = await uploadFile({
        uri: newTasks[i].item.uri,
        name: newTasks[i].item.name,
        mimeType: newTasks[i].item.mimeType,
        size: newTasks[i].item.size,
        userId: user.id,
      });

      if (!mounted.current) break;

      if (result.success) {
        successCount++;
        setTasks(prev => prev.map((t, idx) =>
          idx === i ? { ...t, status: 'success', progress: 100 } : t
        ));
      } else {
        setTasks(prev => prev.map((t, idx) =>
          idx === i ? { ...t, status: 'error', error: result.error } : t
        ));
      }

      Animated.timing(progressAnim, {
        toValue: ((i + 1) / newTasks.length) * 100,
        duration: 300,
        useNativeDriver: false,
      }).start();
    }

    if (mounted.current && !abortRef.current && successCount > 0) {
      setTimeout(() => {
        onUploaded();
      }, 500);
    }
  }

  function handleAbort() {
    abortRef.current = true;
    setTasks(prev => prev.map(t =>
      t.status === 'pending' || t.status === 'uploading'
        ? { ...t, status: 'error', error: 'Ləğv edildi' }
        : t
    ));
  }

  function handleClose() {
    abortRef.current = true;
    onClose();
  }

  const overallProgress = tasks.length > 0
    ? tasks.filter(t => t.status === 'success').length / tasks.length * 100
    : 0;

  const allDone = tasks.length > 0 && tasks.every(t => t.status === 'success' || t.status === 'error');
  const hasSuccess = tasks.some(t => t.status === 'success');

  if (minimized && phase === 'uploading') {
    return (
      <TouchableOpacity
        style={styles.minimizedBar}
        onPress={() => setMinimized(false)}
        activeOpacity={0.8}
      >
        <LinearGradient colors={colors.gradientPrimary} style={StyleSheet.absoluteFill} />
        <ActivityIndicator size="small" color="#fff" />
        <Text style={styles.minimizedText}>
          {tasks.filter(t => t.status === 'success').length}/{tasks.length} fayl yüklənir...
        </Text>
        <TouchableOpacity style={styles.minimizedOpenBtn} onPress={() => setMinimized(false)}>
          <Text style={styles.minimizedOpenText}>Aç</Text>
        </TouchableOpacity>
      </TouchableOpacity>
    );
  }

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={handleClose}>
      <View style={styles.overlay}>
        <TouchableOpacity style={styles.backdrop} onPress={phase === 'uploading' ? undefined : handleClose} />
        <View style={styles.centeredBox}>
          <LinearGradient colors={['#0D1526EE', '#060E1AEE']} style={StyleSheet.absoluteFill} />

          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.title}>
              {phase === 'uploading' ? 'Fayl Yüklənir...' : 'Fayl Yüklə'}
            </Text>
            <View style={styles.headerActions}>
              {phase === 'uploading' && (
                <TouchableOpacity
                  style={styles.headerBtn}
                  onPress={() => setMinimized(true)}
                  hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                >
                  <Minus size={18} color={colors.textSecondary} strokeWidth={2} />
                </TouchableOpacity>
              )}
              <TouchableOpacity
                style={styles.headerBtn}
                onPress={phase === 'uploading' ? handleAbort : handleClose}
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              >
                <X size={18} color={phase === 'uploading' ? colors.error : colors.textSecondary} strokeWidth={2} />
              </TouchableOpacity>
            </View>
          </View>

          {phase === 'uploading' ? (
            <>
              {/* Overall progress */}
              <View style={styles.progressSection}>
                <View style={styles.progressRow}>
                  <Text style={styles.progressLabel}>
                    {tasks.filter(t => t.status === 'success').length} / {tasks.length} fayl
                  </Text>
                  <Text style={styles.progressPercent}>{Math.round(overallProgress)}%</Text>
                </View>
                <View style={styles.progressBarBg}>
                  <Animated.View
                    style={[
                      styles.progressBarFill,
                      { width: progressAnim.interpolate({
                        inputRange: [0, 100],
                        outputRange: ['0%', '100%'],
                      }) as any }
                    ]}
                  >
                    <LinearGradient
                      colors={colors.gradientPrimary}
                      start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                      style={StyleSheet.absoluteFill}
                    />
                  </Animated.View>
                </View>
              </View>

              {/* Task list */}
              <View style={styles.taskList}>
                {tasks.map((task, idx) => (
                  <View key={idx} style={styles.taskItem}>
                    <View style={[
                      styles.taskStatusIcon,
                      task.status === 'success' && { backgroundColor: colors.success + '20' },
                      task.status === 'error' && { backgroundColor: colors.error + '20' },
                      task.status === 'uploading' && { backgroundColor: colors.primary + '20' },
                    ]}>
                      {task.status === 'success' && <Check size={14} color={colors.success} strokeWidth={2.5} />}
                      {task.status === 'error' && <X size={14} color={colors.error} strokeWidth={2} />}
                      {task.status === 'uploading' && <ActivityIndicator size="small" color={colors.primary} />}
                      {task.status === 'pending' && <View style={styles.pendingDot} />}
                    </View>
                    <View style={styles.taskInfo}>
                      <Text style={styles.taskName} numberOfLines={1}>{task.item.name}</Text>
                      <Text style={styles.taskMeta}>
                        {task.status === 'success' ? 'Yükləndi' :
                         task.status === 'error' ? task.error ?? 'Xəta' :
                         task.status === 'uploading' ? 'Yüklənir...' : 'Gözləyir'}
                      </Text>
                    </View>
                    <Text style={styles.taskSize}>
                      {(task.item.size / 1024 / 1024).toFixed(1)} MB
                    </Text>
                  </View>
                ))}
              </View>

              {/* Actions */}
              <View style={styles.actionRow}>
                {allDone ? (
                  <TouchableOpacity style={styles.doneBtn} onPress={handleClose}>
                    <LinearGradient colors={colors.gradientPrimary} style={StyleSheet.absoluteFill} />
                    <Text style={styles.doneBtnText}>
                      {hasSuccess ? 'Bitdi' : 'Bağla'}
                    </Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity style={styles.abortBtn} onPress={handleAbort}>
                    <Trash2 size={16} color={colors.error} strokeWidth={1.8} />
                    <Text style={styles.abortBtnText}>Ləğv Et</Text>
                  </TouchableOpacity>
                )}
              </View>
            </>
          ) : (
            <>
              {!!error && (
                <View style={styles.errorBox}>
                  <Text style={styles.errorText}>{error}</Text>
                </View>
              )}

              <Text style={styles.chooseLabel}>Nə yükləmək istəyirsiniz?</Text>

              <View style={styles.optionGrid}>
                {PICK_OPTIONS.map((opt) => {
                  const Icon = opt.icon;
                  return (
                    <TouchableOpacity
                      key={opt.type}
                      style={styles.optionBtn}
                      onPress={() => startUpload(opt.type)}
                      activeOpacity={0.75}
                    >
                      <LinearGradient
                        colors={[opt.color + '20', opt.color + '05']}
                        style={StyleSheet.absoluteFill}
                      />
                      <View style={[styles.optionIcon, { backgroundColor: opt.color + '30' }]}>
                        <Icon size={28} color={opt.color} strokeWidth={1.8} />
                      </View>
                      <Text style={styles.optionLabel}>{opt.labelAz}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <Text style={styles.hint}>
                Fayllar AES-256 şifrələnmə ilə təhlükəsiz saxlanılır.
              </Text>
            </>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.75)' },
  centeredBox: {
    width: '90%',
    maxWidth: 400,
    borderRadius: radius.xl,
    padding: spacing.xl,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    overflow: 'hidden',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  title: { ...typography.h2, color: colors.text, fontSize: 20 },
  headerActions: { flexDirection: 'row', gap: spacing.sm },
  headerBtn: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center', justifyContent: 'center',
  },
  progressSection: { marginBottom: spacing.lg },
  progressRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    marginBottom: spacing.sm,
  },
  progressLabel: { color: colors.textSecondary, fontSize: 12 },
  progressPercent: { color: colors.primary, fontSize: 12, fontWeight: '700' },
  progressBarBg: {
    height: 6, backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 3, overflow: 'hidden',
  },
  progressBarFill: { height: '100%', borderRadius: 3 },
  taskList: { maxHeight: 240, gap: spacing.sm },
  taskItem: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: radius.md, padding: spacing.md,
    gap: spacing.md,
  },
  taskStatusIcon: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center', justifyContent: 'center',
  },
  pendingDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.textTertiary },
  taskInfo: { flex: 1 },
  taskName: { color: colors.text, fontSize: 13, fontWeight: '500' },
  taskMeta: { color: colors.textSecondary, fontSize: 11, marginTop: 2 },
  taskSize: { color: colors.textTertiary, fontSize: 11 },
  actionRow: {
    flexDirection: 'row', justifyContent: 'center',
    marginTop: spacing.lg, gap: spacing.md,
  },
  abortBtn: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    backgroundColor: 'rgba(255,59,48,0.12)',
    borderRadius: radius.lg,
  },
  abortBtnText: { color: colors.error, fontSize: 14, fontWeight: '600' },
  doneBtn: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    paddingVertical: spacing.md, borderRadius: radius.lg,
    overflow: 'hidden',
  },
  doneBtnText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  errorBox: {
    backgroundColor: 'rgba(255,59,48,0.12)',
    borderWidth: 1, borderColor: 'rgba(255,59,48,0.3)',
    borderRadius: radius.md, padding: spacing.md,
    marginBottom: spacing.lg,
  },
  errorText: { color: colors.error, fontSize: 13 },
  chooseLabel: { color: colors.textSecondary, fontSize: 14, textAlign: 'center', marginBottom: spacing.lg },
  optionGrid: { flexDirection: 'row', gap: spacing.md, marginBottom: spacing.xl },
  optionBtn: {
    flex: 1, alignItems: 'center', borderRadius: radius.lg,
    paddingVertical: spacing.xl, gap: spacing.md,
    borderWidth: 1, borderColor: colors.border,
    overflow: 'hidden',
  },
  optionIcon: {
    width: 56, height: 56, borderRadius: 16,
    alignItems: 'center', justifyContent: 'center',
  },
  optionLabel: { color: colors.text, fontSize: 12, fontWeight: '500' },
  hint: { color: colors.textTertiary, fontSize: 11, textAlign: 'center', lineHeight: 16 },
  minimizedBar: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    height: 48,
    borderRadius: radius.full,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    overflow: 'hidden',
    zIndex: 999,
  },
  minimizedText: { color: '#fff', fontSize: 13, fontWeight: '500', flex: 1 },
  minimizedOpenBtn: {
    paddingHorizontal: spacing.md, paddingVertical: spacing.xs,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: radius.sm,
  },
  minimizedOpenText: { color: '#fff', fontSize: 12, fontWeight: '600' },
});
