import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  ScrollView,
  Platform,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  X, Play, Pause, SkipBack, SkipForward, Volume2, VolumeX,
  Maximize, Minimize, Settings, Clock, Film, ChevronRight,
} from 'lucide-react-native';
import { FileRecord, formatDuration, formatBytes } from '@/lib/files';
import { useLanguage } from '@/context/LanguageContext';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { PlayerWindow, WindowMode } from './PlayerWindow';

const { width, height } = Dimensions.get('window');

type Props = {
  files: FileRecord[];
  onBack: () => void;
};

const SPEED_OPTIONS = [0.5, 0.75, 1, 1.25, 1.5, 2];

export function VideoPlayer({ files, onBack }: Props) {
  const { t } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffering, setBuffering] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [speed, setSpeed] = useState(1);
  const [windowMode, setWindowMode] = useState<WindowMode>('windowed');
  const [showControls, setShowControls] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [showPlaylist, setShowPlaylist] = useState(false);
  const [thumbnails, setThumbnails] = useState<Record<string, string>>({});

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const controlsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const currentFile = files[currentIndex];

  // Generate thumbnails for playlist
  useEffect(() => {
    if (Platform.OS !== 'web') return;
    files.forEach(file => {
      if (thumbnails[file.id] || !file.storage_url) return;
      const video = document.createElement('video');
      video.crossOrigin = 'anonymous';
      video.muted = true;
      video.preload = 'metadata';
      video.playsInline = true;
      video.src = file.storage_url;
      video.onloadeddata = () => {
        video.currentTime = Math.min(2, video.duration / 2);
      };
      video.onseeked = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = 160;
          canvas.height = 90;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(video, 0, 0, 160, 90);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.6);
            setThumbnails(prev => ({ ...prev, [file.id]: dataUrl }));
          }
        } catch {}
      };
    });
  }, [files]);

  // Video event listeners
  useEffect(() => {
    if (Platform.OS !== 'web' || !videoRef.current) return;
    const video = videoRef.current;

    const onTimeUpdate = () => setCurrentTime(video.currentTime);
    const onDurationChange = () => setDuration(video.duration);
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onWaiting = () => setBuffering(true);
    const onPlaying = () => setBuffering(false);
    const onVolumeChange = () => {
      setMuted(video.muted);
      setVolume(video.volume);
    };

    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('durationchange', onDurationChange);
    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('waiting', onWaiting);
    video.addEventListener('playing', onPlaying);
    video.addEventListener('volumechange', onVolumeChange);

    return () => {
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('durationchange', onDurationChange);
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('waiting', onWaiting);
      video.removeEventListener('playing', onPlaying);
      video.removeEventListener('volumechange', onVolumeChange);
    };
  }, [currentIndex]);

  // Auto-hide controls
  const resetControlsTimer = useCallback(() => {
    if (controlsTimer.current) clearTimeout(controlsTimer.current);
    setShowControls(true);
    if (playing) {
      controlsTimer.current = setTimeout(() => setShowControls(false), 4000);
    }
  }, [playing]);

  useEffect(() => {
    resetControlsTimer();
    return () => {
      if (controlsTimer.current) clearTimeout(controlsTimer.current);
    };
  }, [playing, resetControlsTimer]);

  function togglePlay() {
    if (!videoRef.current) return;
    if (playing) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    resetControlsTimer();
  }

  function seek(time: number) {
    if (!videoRef.current) return;
    videoRef.current.currentTime = time;
    setCurrentTime(time);
  }

  function skip(seconds: number) {
    if (!videoRef.current) return;
    const newTime = Math.max(0, Math.min(duration, currentTime + seconds));
    videoRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  }

  function toggleMute() {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
  }

  function changeSpeed(s: number) {
    if (!videoRef.current) return;
    videoRef.current.playbackRate = s;
    setSpeed(s);
    setShowSettings(false);
  }

  function toggleFullscreen() {
    if (windowMode === 'fullscreen') {
      setWindowMode('windowed');
    } else {
      setWindowMode('fullscreen');
    }
  }

  function selectVideo(index: number) {
    setCurrentIndex(index);
    setPlaying(false);
    setShowPlaylist(false);
    setCurrentTime(0);
  }

  function goPrev() {
    if (currentIndex > 0) selectVideo(currentIndex - 1);
  }

  function goNext() {
    if (currentIndex < files.length - 1) selectVideo(currentIndex + 1);
  }

  // Auto-play next when video ends
  function handleEnded() {
    if (currentIndex < files.length - 1) {
      selectVideo(currentIndex + 1);
    } else {
      setPlaying(false);
    }
  }

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  if (!currentFile) {
    return (
      <View style={styles.emptyContainer}>
        <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />
        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={onBack}>
            <X size={22} color={colors.text} strokeWidth={2} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>{t('video_player')}</Text>
        </View>
        <View style={styles.emptyWrap}>
          <Film size={56} color={colors.textTertiary} strokeWidth={1.5} />
          <Text style={styles.emptyTitle}>{t('no_video_files')}</Text>
          <Text style={styles.emptySub}>{t('players_empty_sub')}</Text>
        </View>
      </View>
    );
  }

  return (
    <PlayerWindow
      title={currentFile.name}
      subtitle={`${formatBytes(currentFile.size)}${currentFile.duration_seconds ? ` · ${formatDuration(currentFile.duration_seconds)}` : ''} · ${currentIndex + 1}/${files.length}`}
      mode={windowMode}
      onModeChange={setWindowMode}
      onClose={onBack}
      onBack={onBack}
      accentColor="#FF3B30"
      minimizedContent={<Film size={18} color="#FF3B30" strokeWidth={1.8} />}
    >
      <View
        style={styles.videoArea}
        onTouchStart={resetControlsTimer}
      >
        {Platform.OS === 'web' && currentFile.storage_url ? (
          <video
            ref={videoRef}
            src={currentFile.storage_url}
            style={{ width: '100%', height: '100%', objectFit: 'contain', background: '#000' }}
            onClick={togglePlay}
            onEnded={handleEnded}
            playsInline
          />
        ) : (
          <View style={styles.noVideoWeb}>
            <Film size={56} color={colors.textTertiary} strokeWidth={1.5} />
            <Text style={styles.noVideoText}>{currentFile.name}</Text>
          </View>
        )}

        {buffering && (
          <View style={styles.bufferOverlay}>
            <ActivityIndicator size="large" color={colors.primary} />
          </View>
        )}

        {/* Top controls bar - playlist toggle only (window controls in title bar) */}
        {showControls && (
          <View style={styles.topBar}>
            <LinearGradient colors={['rgba(0,0,0,0.7)', 'transparent']} style={StyleSheet.absoluteFill} />
            <View style={styles.topInfo}>
              <Text style={styles.topTitle} numberOfLines={1}>{currentFile.name}</Text>
              <Text style={styles.topMeta}>
                {formatBytes(currentFile.size)}
                {currentFile.duration_seconds ? ` · ${formatDuration(currentFile.duration_seconds)}` : ''}
                {` · ${currentIndex + 1}/${files.length}`}
              </Text>
            </View>
            <TouchableOpacity style={styles.iconBtn} onPress={() => setShowPlaylist(!showPlaylist)}>
              <View style={[styles.playlistIcon, showPlaylist && styles.playlistIconActive]}>
                <View style={styles.playlistLine} />
                <View style={styles.playlistLine} />
                <View style={styles.playlistLine} />
              </View>
            </TouchableOpacity>
          </View>
        )}

        {/* Center play/pause button */}
        {showControls && !buffering && (
          <View style={styles.centerControls}>
            <TouchableOpacity style={styles.skipBtn} onPress={() => skip(-10)}>
              <SkipBack size={28} color="#fff" strokeWidth={2} />
              <Text style={styles.skipLabel}>10</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.playBtn} onPress={togglePlay}>
              {playing ? <Pause size={36} color="#fff" strokeWidth={2} /> : <Play size={36} color="#fff" strokeWidth={2} fill="#fff" />}
            </TouchableOpacity>
            <TouchableOpacity style={styles.skipBtn} onPress={() => skip(10)}>
              <SkipForward size={28} color="#fff" strokeWidth={2} />
              <Text style={styles.skipLabel}>10</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Bottom controls bar */}
        {showControls && (
          <View style={styles.bottomBar}>
            <LinearGradient colors={['transparent', 'rgba(0,0,0,0.8)']} style={StyleSheet.absoluteFill} />

            {/* Progress bar */}
            <View style={styles.progressRow}>
              <Text style={styles.timeText}>{formatDuration(currentTime)}</Text>
              <TouchableOpacity
                style={styles.progressBar}
                onPress={(e) => {
                  // @ts-ignore
                  const rect = e.currentTarget.getBoundingClientRect();
                  // @ts-ignore
                  const x = e.nativeEvent.clientX - rect.left;
                  const percent = x / rect.width;
                  seek(percent * duration);
                }}
              >
                <View style={styles.progressTrack}>
                  <View style={[styles.progressFill, { width: `${progress}%` as any }]} />
                  <View style={[styles.progressThumb, { left: `${progress}%` as any }]} />
                </View>
              </TouchableOpacity>
              <Text style={styles.timeText}>{formatDuration(duration)}</Text>
            </View>

            {/* Control buttons */}
            <View style={styles.controlRow}>
              <TouchableOpacity style={styles.controlBtn} onPress={() => skip(-10)}>
                <SkipBack size={20} color="#fff" strokeWidth={1.8} />
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlBtn} onPress={togglePlay}>
                {playing ? <Pause size={24} color="#fff" strokeWidth={2} /> : <Play size={24} color="#fff" strokeWidth={2} fill="#fff" />}
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlBtn} onPress={() => skip(10)}>
                <SkipForward size={20} color="#fff" strokeWidth={1.8} />
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlBtn} onPress={toggleMute}>
                {muted || volume === 0 ? <VolumeX size={20} color="#fff" strokeWidth={1.8} /> : <Volume2 size={20} color="#fff" strokeWidth={1.8} />}
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlBtn} onPress={() => setShowSettings(!showSettings)}>
                <Settings size={20} color={showSettings ? colors.primary : '#fff'} strokeWidth={1.8} />
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlBtn} onPress={toggleFullscreen}>
                {windowMode === 'fullscreen' ? <Minimize size={20} color="#fff" strokeWidth={1.8} /> : <Maximize size={20} color="#fff" strokeWidth={1.8} />}
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Settings panel */}
        {showSettings && (
          <View style={styles.settingsPanel}>
            <Text style={styles.settingsTitle}>{t('speed')}</Text>
            <View style={styles.speedRow}>
              {SPEED_OPTIONS.map(s => (
                <TouchableOpacity
                  key={s}
                  style={[styles.speedBtn, speed === s && styles.speedBtnActive]}
                  onPress={() => changeSpeed(s)}
                >
                  <Text style={[styles.speedText, speed === s && styles.speedTextActive]}>{s}x</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}
      </View>

      {/* Playlist sidebar */}
      {showPlaylist && (
        <View style={styles.playlistPanel}>
          <LinearGradient colors={['#030C1A', '#000814']} style={StyleSheet.absoluteFill} />
          <View style={styles.playlistHeader}>
            <Text style={styles.playlistTitle}>{t('playlist')}</Text>
            <Text style={styles.playlistCount}>{files.length} {t('files')}</Text>
          </View>
          <ScrollView style={styles.playlistScroll} showsVerticalScrollIndicator={false}>
            {files.map((file, i) => (
              <TouchableOpacity
                key={file.id}
                style={[styles.playlistItem, i === currentIndex && styles.playlistItemActive]}
                onPress={() => selectVideo(i)}
              >
                <View style={styles.playlistThumb}>
                  {thumbnails[file.id] ? (
                    <Image source={{ uri: thumbnails[file.id] }} style={styles.thumbImg} resizeMode="cover" />
                  ) : (
                    <View style={styles.thumbPlaceholder}>
                      <Film size={20} color={colors.textTertiary} strokeWidth={1.5} />
                    </View>
                  )}
                  {i === currentIndex && playing && (
                    <View style={styles.playingOverlay}>
                      <View style={styles.playingBar1} />
                      <View style={styles.playingBar2} />
                      <View style={styles.playingBar3} />
                    </View>
                  )}
                </View>
                <View style={styles.playlistInfo}>
                  <Text style={styles.playlistName} numberOfLines={2}>{file.name}</Text>
                  <Text style={styles.playlistMeta}>
                    {formatBytes(file.size)}
                    {file.duration_seconds ? ` · ${formatDuration(file.duration_seconds)}` : ''}
                  </Text>
                </View>
                {i === currentIndex && <View style={styles.activeDot} />}
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}
    </PlayerWindow>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  videoArea: { flex: 1, position: 'relative' },
  bufferOverlay: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  topBar: {
    position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10,
    flexDirection: 'row', alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 52 : 40,
    paddingHorizontal: spacing.lg, paddingBottom: spacing.lg, gap: spacing.md,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  topInfo: { flex: 1 },
  topTitle: { color: '#fff', fontSize: 15, fontWeight: '600' },
  topMeta: { color: 'rgba(255,255,255,0.6)', fontSize: 12, marginTop: 2 },
  iconBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  playlistIcon: { gap: 3, alignItems: 'flex-end' },
  playlistIconActive: { alignItems: 'flex-start' },
  playlistLine: { width: 18, height: 2, backgroundColor: '#fff', borderRadius: 1 },
  centerControls: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.xxl, zIndex: 5,
  },
  skipBtn: { alignItems: 'center', gap: 2 },
  skipLabel: { color: '#fff', fontSize: 10, fontWeight: '600' },
  playBtn: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: 'rgba(30,111,255,0.9)',
    alignItems: 'center', justifyContent: 'center',
  },
  bottomBar: {
    position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 10,
    paddingHorizontal: spacing.lg,
    paddingBottom: Platform.OS === 'ios' ? 36 : 24,
    paddingTop: spacing.xl,
  },
  progressRow: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.md,
  },
  timeText: { color: '#fff', fontSize: 12, minWidth: 38, fontWeight: '500' },
  progressBar: { flex: 1, height: 24, justifyContent: 'center' },
  progressTrack: {
    height: 4, backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 2, overflow: 'visible', position: 'relative',
  },
  progressFill: {
    height: '100%', backgroundColor: colors.primary, borderRadius: 2,
  },
  progressThumb: {
    position: 'absolute', top: -6, width: 16, height: 16, borderRadius: 8,
    backgroundColor: '#fff', marginLeft: -8,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.3, shadowRadius: 4,
  },
  controlRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.lg,
  },
  controlBtn: {
    width: 40, height: 40, borderRadius: 20,
    alignItems: 'center', justifyContent: 'center',
  },
  settingsPanel: {
    position: 'absolute', bottom: 100, right: spacing.lg, zIndex: 20,
    backgroundColor: 'rgba(10,20,40,0.95)',
    borderRadius: radius.lg, padding: spacing.lg,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)',
    minWidth: 200,
  },
  settingsTitle: { color: colors.text, fontSize: 14, fontWeight: '600', marginBottom: spacing.sm },
  speedRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  speedBtn: {
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: radius.sm,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  speedBtnActive: { backgroundColor: colors.primary },
  speedText: { color: colors.textSecondary, fontSize: 13, fontWeight: '500' },
  speedTextActive: { color: '#fff', fontWeight: '700' },
  playlistPanel: {
    position: 'absolute', top: 0, right: 0, bottom: 0,
    width: width * 0.75, maxWidth: 360, zIndex: 30,
    borderLeftWidth: 1, borderLeftColor: 'rgba(30,111,255,0.2)',
    overflow: 'hidden',
  },
  playlistHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 52 : 40,
    paddingHorizontal: spacing.lg, paddingBottom: spacing.md,
  },
  playlistTitle: { color: colors.text, fontSize: 18, fontWeight: '700' },
  playlistCount: { color: colors.textTertiary, fontSize: 13 },
  playlistScroll: { flex: 1, paddingHorizontal: spacing.md },
  playlistItem: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    padding: spacing.sm, borderRadius: radius.md, marginBottom: 4,
  },
  playlistItemActive: { backgroundColor: 'rgba(30,111,255,0.15)' },
  playlistThumb: {
    width: 64, height: 40, borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.05)', overflow: 'hidden',
    alignItems: 'center', justifyContent: 'center',
  },
  thumbImg: { width: 64, height: 40 },
  thumbPlaceholder: { alignItems: 'center', justifyContent: 'center' },
  playingOverlay: {
    position: 'absolute', bottom: 4, left: 4,
    flexDirection: 'row', gap: 2, alignItems: 'flex-end',
  },
  playingBar1: { width: 2, height: 8, backgroundColor: colors.primary, borderRadius: 1 },
  playingBar2: { width: 2, height: 12, backgroundColor: colors.primary, borderRadius: 1 },
  playingBar3: { width: 2, height: 6, backgroundColor: colors.primary, borderRadius: 1 },
  playlistInfo: { flex: 1 },
  playlistName: { color: colors.text, fontSize: 13, fontWeight: '500' },
  playlistMeta: { color: colors.textTertiary, fontSize: 11, marginTop: 2 },
  activeDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary },
  noVideoWeb: { alignItems: 'center', justifyContent: 'center', flex: 1, gap: spacing.md },
  noVideoText: { color: colors.textSecondary, fontSize: 14 },
  emptyContainer: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    paddingTop: Platform.OS === 'ios' ? 52 : 40,
    paddingHorizontal: spacing.xl, paddingBottom: spacing.md,
  },
  headerTitle: { color: colors.text, fontSize: 20, fontWeight: '700' },
  emptyWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.sm },
  emptyTitle: { color: colors.text, fontSize: 18, fontWeight: '600' },
  emptySub: { color: colors.textSecondary, fontSize: 13, textAlign: 'center' },
});
