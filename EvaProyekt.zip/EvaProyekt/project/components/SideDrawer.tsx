import React, { useRef, useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Animated,
  Image, Dimensions, PanResponder, Platform, Easing,
  ScrollView,
} from 'react-native';
import { router, usePathname } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Home, HardDrive, Shield, User, X, Cloud, ChevronRight, Trash2, Sparkles, Play } from 'lucide-react-native';
import { useDrawer, DRAWER_WIDTH } from '@/context/DrawerContext';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import { colors, spacing, radius } from '@/constants/theme';
import { formatBytes, getFileStats, FileStats } from '@/lib/files';
import { EvaDrawerSection } from './EvaDrawerSection';

const EVA_LOGO = require('../assets/images/eva-logo.png');
const WIN_H = Dimensions.get('window').height;

const NAV_ITEMS = [
  { route: '/(tabs)/', key: 'home', Icon: Home, color: colors.primary },
  { route: '/(tabs)/storage', key: 'storage', Icon: HardDrive, color: '#00D4FF' },
  { route: '/(tabs)/players', key: 'players', Icon: Play, color: '#FF2D55' },
  { route: '/(tabs)/security', key: 'security', Icon: Shield, color: '#34C759' },
  { route: '/(tabs)/profile', key: 'profile', Icon: User, color: '#FF9F0A' },
  { route: '/(tabs)/trash', key: 'trash', Icon: Trash2, color: '#FF3B30' },
  { route: '/updates', key: 'updates', Icon: Sparkles, color: '#A066FF' },
] as const;

export function SideDrawer() {
  const { isOpen, closeDrawer, slideAnim } = useDrawer();
  const { user, profile, signOut } = useAuth();
  const { t } = useLanguage();
  const pathname = usePathname();
  const [storageStats, setStorageStats] = useState<FileStats | null>(null);

  // Animation refs for nav items
  const navAnims = useRef(NAV_ITEMS.map(() => ({
    scale: new Animated.Value(0.85),
    opacity: new Animated.Value(0),
    translateX: new Animated.Value(-30),
  }))).current;

  const headerAnim = useRef({
    opacity: new Animated.Value(0),
    translateY: new Animated.Value(-20),
  }).current;

  const userCardAnim = useRef({
    scale: new Animated.Value(0.9),
    opacity: new Animated.Value(0),
  }).current;

  const storageAnim = useRef({
    opacity: new Animated.Value(0),
  }).current;

  // Run entrance animations when drawer opens
  useEffect(() => {
    if (isOpen) {
      // Header animation
      Animated.parallel([
        Animated.timing(headerAnim.opacity, { toValue: 1, duration: 250, useNativeDriver: true }),
        Animated.timing(headerAnim.translateY, { toValue: 0, duration: 300, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      ]).start();

      // User card animation
      Animated.sequence([
        Animated.delay(100),
        Animated.parallel([
          Animated.spring(userCardAnim.scale, { toValue: 1, tension: 80, friction: 8, useNativeDriver: true }),
          Animated.timing(userCardAnim.opacity, { toValue: 1, duration: 200, useNativeDriver: true }),
        ]),
      ]).start();

      // Storage bar animation
      Animated.sequence([
        Animated.delay(200),
        Animated.timing(storageAnim.opacity, { toValue: 1, duration: 200, useNativeDriver: true }),
      ]).start();

      // Nav items staggered animation
      navAnims.forEach((anim, i) => {
        Animated.sequence([
          Animated.delay(250 + i * 60),
          Animated.parallel([
            Animated.spring(anim.scale, { toValue: 1, tension: 80, friction: 7, useNativeDriver: true }),
            Animated.timing(anim.opacity, { toValue: 1, duration: 200, useNativeDriver: true }),
            Animated.timing(anim.translateX, { toValue: 0, duration: 250, easing: Easing.out(Easing.quad), useNativeDriver: true }),
          ]),
        ]).start();
      });
    } else {
      // Reset animations when drawer closes
      headerAnim.opacity.setValue(0);
      headerAnim.translateY.setValue(-20);
      userCardAnim.scale.setValue(0.9);
      userCardAnim.opacity.setValue(0);
      storageAnim.opacity.setValue(0);
      navAnims.forEach(anim => {
        anim.scale.setValue(0.85);
        anim.opacity.setValue(0);
        anim.translateX.setValue(-30);
      });
    }
  }, [isOpen]);

  const panResponder = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => g.dx < -10 && Math.abs(g.dy) < 50,
      onPanResponderMove: () => {},
      onPanResponderRelease: (_, g) => { if (g.dx < -40) closeDrawer(); },
    })
  ).current;

  // Fetch storage stats when drawer opens
  useEffect(() => {
    if (isOpen && user) {
      getFileStats(user.id).then(setStorageStats);
    }
  }, [isOpen, user]);

  if (!isOpen) return null;

  // Use stats.total_size (accurate from files table) when available, fallback to profile.storage_used
  const storageUsed = storageStats?.total_size ?? profile?.storage_used ?? 0;
  const storageLimit = profile?.storage_limit ?? 16_492_674_416_640;
  const usedPct = Math.min((storageUsed / storageLimit) * 100, 100);
  const displayName = profile?.first_name
    ? `${profile.first_name} ${profile.last_name ?? ''}`.trim()
    : user?.email?.split('@')[0] ?? 'User';
  const initials = displayName.charAt(0).toUpperCase();

  function navigate(route: string) {
    closeDrawer();
    setTimeout(() => router.push(route as any), 180);
  }

  function isActive(key: string) {
    if (key === 'home') return pathname === '/' || pathname === '/(tabs)' || pathname === '/(tabs)/index';
    return pathname.includes(key);
  }

  return (
    <View style={styles.overlay} pointerEvents="box-none">
      {/* Backdrop */}
      <TouchableOpacity style={styles.backdrop} activeOpacity={1} onPress={closeDrawer} />

      {/* Drawer panel */}
      <Animated.View
        style={[styles.drawer, { transform: [{ translateX: slideAnim }] }]}
        {...panResponder.panHandlers}
      >
        <LinearGradient colors={['#030C1A', '#000814']} style={StyleSheet.absoluteFill} />

        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <Animated.View style={[styles.drawerHeader, { opacity: headerAnim.opacity, transform: [{ translateY: headerAnim.translateY }] }]}>
            <Image source={EVA_LOGO} style={styles.drawerLogo} resizeMode="contain" />
            <View style={styles.drawerBrand}>
              <Text style={styles.brandName}>EVA Cloud X</Text>
              <Text style={styles.brandSub}>v2.1.0</Text>
            </View>
            <TouchableOpacity style={styles.closeBtn} onPress={closeDrawer}>
              <X size={20} color={colors.textSecondary} strokeWidth={2} />
            </TouchableOpacity>
          </Animated.View>

          {/* User card */}
          <Animated.View style={{ opacity: userCardAnim.opacity, transform: [{ scale: userCardAnim.scale }] }}>
            <TouchableOpacity
              style={styles.userCard}
              onPress={() => navigate('/(tabs)/profile')}
              activeOpacity={0.8}
            >
              <LinearGradient colors={['rgba(30,111,255,0.15)', 'rgba(0,212,255,0.05)']} style={StyleSheet.absoluteFill} />
              <View style={styles.avatar}>
                <LinearGradient colors={['#1E6FFF', '#00D4FF']} style={StyleSheet.absoluteFill} />
                <Text style={styles.avatarText}>{initials}</Text>
              </View>
              <View style={styles.userInfo}>
                <Text style={styles.userName} numberOfLines={1}>{displayName}</Text>
                <Text style={styles.userEmail} numberOfLines={1}>{user?.email ?? ''}</Text>
              </View>
              <ChevronRight size={18} color={colors.textTertiary} strokeWidth={2} />
            </TouchableOpacity>
          </Animated.View>

        {/* Storage mini bar */}
        <Animated.View style={[styles.storageBar, { opacity: storageAnim.opacity }]}>
          <Cloud size={14} color={colors.primary} strokeWidth={1.8} />
          <Text style={styles.storageText}>{formatBytes(storageUsed)} / {formatBytes(storageLimit)}</Text>
          <View style={styles.storagePill}>
            <View style={[styles.storageFill, { width: `${usedPct}%` as any }]} />
          </View>
        </Animated.View>

        {/* EVA AI Assistant - expandable */}
        <EvaDrawerSection />

        {/* Divider */}
        <View style={styles.divider} />

        {/* Navigation */}
        <View style={styles.nav}>
          {NAV_ITEMS.map(({ route, key, Icon, color }, i) => {
            const active = isActive(key);
            const anim = navAnims[i];
            return (
              <Animated.View
                key={key}
                style={{
                  opacity: anim.opacity,
                  transform: [{ scale: anim.scale }, { translateX: anim.translateX }],
                }}
              >
                <TouchableOpacity
                  style={[styles.navItem, active && styles.navItemActive]}
                  onPress={() => navigate(route)}
                  activeOpacity={0.7}
                >
                  {active && (
                    <LinearGradient
                      colors={[color + '22', 'transparent']}
                      start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }}
                      style={StyleSheet.absoluteFill}
                    />
                  )}
                  {active && <View style={[styles.activeBar, { backgroundColor: color }]} />}
                  <View style={[styles.navIcon, { backgroundColor: active ? color + '20' : 'rgba(255,255,255,0.06)' }]}>
                    <Icon size={20} color={active ? color : colors.textSecondary} strokeWidth={1.8} />
                  </View>
                  <Text style={[styles.navLabel, active && { color, fontWeight: '700' }]}>
                    {t(key)}
                  </Text>
                  {active && <ChevronRight size={16} color={color} strokeWidth={2} />}
                </TouchableOpacity>
              </Animated.View>
            );
          })}
        </View>

        <View style={styles.divider} />

        {/* Sign out */}
        <TouchableOpacity style={styles.signOutBtn} onPress={() => { closeDrawer(); setTimeout(signOut, 300); }}>
          <Text style={styles.signOutText}>{t('sign_out')}</Text>
        </TouchableOpacity>
        </ScrollView>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 1000,
    flexDirection: 'row',
  },
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
  },
  drawer: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: DRAWER_WIDTH,
    height: WIN_H,
    overflow: 'hidden',
    borderRightWidth: 1,
    borderRightColor: 'rgba(30,111,255,0.2)',
  },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 100 },
  drawerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 56 : 44,
    paddingHorizontal: spacing.xl,
    paddingBottom: spacing.lg,
    gap: spacing.md,
  },
  drawerLogo: { width: 36, height: 36 },
  drawerBrand: { flex: 1 },
  brandName: { color: colors.text, fontSize: 16, fontWeight: '700', letterSpacing: 0.5 },
  brandSub: { color: colors.textTertiary, fontSize: 11 },
  closeBtn: {
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center', justifyContent: 'center',
  },
  userCard: {
    marginHorizontal: spacing.xl,
    borderRadius: radius.lg,
    padding: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(30,111,255,0.2)',
    marginBottom: spacing.md,
  },
  avatar: {
    width: 44, height: 44, borderRadius: 22,
    overflow: 'hidden', alignItems: 'center', justifyContent: 'center',
  },
  avatarText: { color: '#fff', fontSize: 18, fontWeight: '700' },
  userInfo: { flex: 1 },
  userName: { color: colors.text, fontSize: 14, fontWeight: '600' },
  userEmail: { color: colors.textSecondary, fontSize: 11, marginTop: 1 },
  storageBar: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: spacing.xl, gap: spacing.sm, marginBottom: spacing.md,
  },
  storageText: { flex: 1, color: colors.textTertiary, fontSize: 11 },
  storagePill: {
    width: 60, height: 4, backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 2, overflow: 'hidden',
  },
  storageFill: { height: '100%', backgroundColor: colors.primary, borderRadius: 2 },
  divider: { height: 1, backgroundColor: 'rgba(255,255,255,0.07)', marginVertical: spacing.sm },
  nav: { paddingHorizontal: spacing.md, gap: 4 },
  navItem: {
    flexDirection: 'row', alignItems: 'center',
    gap: spacing.md, paddingHorizontal: spacing.md,
    paddingVertical: 13, borderRadius: radius.lg, overflow: 'hidden',
    position: 'relative',
  },
  navItemActive: {},
  activeBar: { position: 'absolute', left: 0, top: 10, bottom: 10, width: 3, borderRadius: 2 },
  navIcon: { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  navLabel: { color: colors.textSecondary, fontSize: 15, fontWeight: '500' },
  signOutBtn: {
    marginHorizontal: spacing.xl, marginTop: spacing.sm,
    paddingVertical: spacing.md, alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(255,59,48,0.3)',
    borderRadius: radius.lg,
  },
  signOutText: { color: colors.error, fontSize: 14, fontWeight: '600' },
});
