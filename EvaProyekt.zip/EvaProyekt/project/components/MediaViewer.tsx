import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Image,
  TouchableOpacity,
  Dimensions,
  Share,
  Platform,
  ActivityIndicator,
  Alert,
  ScrollView,
} from 'react-native';
import { X, Trash2, Download, Share2, ChevronLeft, ChevronRight, FileText, Film, Music, Folder, Play, Pause, Info } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { FileRecord, formatBytes, deleteFile, formatDuration } from '@/lib/files';
import { downloadFileModern } from '@/lib/download';
import { colors, spacing, radius } from '@/constants/theme';
import { MusicPlayer, PdfViewer, DocumentViewer } from './FileViewers';
import { useLanguage } from '@/context/LanguageContext';

const { width, height } = Dimensions.get('window');

type Props = {
  files: FileRecord[];
  initialIndex: number;
  visible: boolean;
  onClose: () => void;
  onDeleted: (file: FileRecord) => void;
};

const ICON_MAP: Record<string, typeof FileText> = {
  videos: Film,
  documents: FileText,
  music: Music,
  other: Folder,
};
const COLOR_MAP: Record<string, string> = {
  photos: '#FF9F0A',
  videos: '#FF3B30',
  documents: colors.primary,
  music: '#34C759',
  other: '#6B7280',
};

export function MediaViewer({ files, initialIndex, visible, onClose, onDeleted }: Props) {
  const { t } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [imageLoading, setImageLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [showInfo, setShowInfo] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadToast, setDownloadToast] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const file = files[currentIndex] ?? files[0];
  if (!file) return null;

  const isImage = file.mime_type.startsWith('image/');
  const isVideo = file.mime_type.startsWith('video/');
  const isAudio = file.mime_type.startsWith('audio/');
  const isPdf = file.mime_type === 'application/pdf';
  const isDocument = file.category === 'documents' && !isPdf;
  const Icon = ICON_MAP[file.category] ?? Folder;
  const iconColor = COLOR_MAP[file.category] ?? '#6B7280';

  // Reset state when changing files
  useEffect(() => {
    setIsPlaying(false);
    setImageLoading(true);
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  }, [currentIndex]);

  function goPrev() {
    if (currentIndex > 0) { setCurrentIndex(i => i - 1); setImageLoading(true); }
  }
  function goNext() {
    if (currentIndex < files.length - 1) { setCurrentIndex(i => i + 1); setImageLoading(true); }
  }

  function toggleVideoPlay() {
    if (Platform.OS !== 'web' || !videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setIsPlaying(!isPlaying);
  }

  async function handleShare() {
    if (!file.storage_url) return;
    try {
      if (Platform.OS === 'web') {
        if (typeof navigator !== 'undefined' && navigator.share) {
          await navigator.share({ title: file.name, url: file.storage_url });
        } else {
          await navigator.clipboard.writeText(file.storage_url);
          Alert.alert('Link Copied', 'File link copied to clipboard.');
        }
      } else {
        await Share.share({
          message: `${file.name}\n${file.storage_url}`,
          url: file.storage_url,
          title: file.name,
        });
      }
    } catch {}
  }

  async function handleDownload() {
    if (!file.storage_url) return;
    setDownloading(true);
    const result = await downloadFileModern(file, (p) => {
      setDownloadProgress(Math.round(p.percent));
    });
    setDownloading(false);
    setDownloadProgress(0);
    if (result.success) {
      setDownloadToast(`✓ ${file.name} endirildi`);
    } else {
      setDownloadToast(`✕ ${result.error ?? 'Endirmə xətası'}`);
    }
    setTimeout(() => setDownloadToast(null), 3000);
  }

  function confirmDelete() {
    setShowDeleteConfirm(true);
  }

  async function executeDelete() {
    setShowDeleteConfirm(false);
    setDeleting(true);
    const result = await deleteFile(file);
    if (result.success) {
      onDeleted(file);
      if (files.length <= 1) onClose();
      else if (currentIndex >= files.length - 1) setCurrentIndex(files.length - 2);
    } else {
      if (Platform.OS === 'web') {
        alert(result.error ?? 'Could not delete file');
      } else {
        Alert.alert(t('error') || 'Error', result.error ?? 'Could not delete file');
      }
    }
    setDeleting(false);
  }

  return (
    <Modal visible={visible} transparent={false} animationType="fade" onRequestClose={onClose}>
      <View style={styles.container}>
        <LinearGradient colors={['rgba(0,0,0,0.85)', 'transparent']} style={styles.topGrad} />
        <LinearGradient colors={['transparent', 'rgba(0,0,0,0.92)']} style={styles.bottomGrad} />

        <View style={styles.header}>
          <TouchableOpacity style={styles.iconBtn} onPress={onClose}>
            <X size={22} color="#fff" strokeWidth={2} />
          </TouchableOpacity>
          <View style={styles.headerInfo}>
            <Text style={styles.headerName} numberOfLines={1}>{file.name}</Text>
            <Text style={styles.headerMeta}>{formatBytes(file.size)} · {currentIndex + 1}/{files.length}</Text>
          </View>
          <TouchableOpacity style={styles.iconBtn} onPress={handleShare}>
            <Share2 size={20} color="#fff" strokeWidth={1.8} />
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.content} activeOpacity={1} onPress={() => setShowControls(v => !v)}>
          {isImage && file.storage_url ? (
            <ScrollView
              style={{ width, flex: 1 }}
              contentContainerStyle={styles.zoomContent}
              maximumZoomScale={6}
              minimumZoomScale={1}
              showsHorizontalScrollIndicator={false}
              showsVerticalScrollIndicator={false}
              centerContent
            >
              {imageLoading && <ActivityIndicator size="large" color={colors.primary} style={styles.loader} />}
              <Image
                source={{ uri: file.storage_url }}
                style={styles.fullImage}
                resizeMode="contain"
                onLoad={() => setImageLoading(false)}
                onError={() => setImageLoading(false)}
              />
            </ScrollView>
          ) : isVideo && file.storage_url ? (
            Platform.OS === 'web' ? (
              <View style={styles.videoContainer}>
                {imageLoading && <ActivityIndicator size="large" color={colors.primary} style={styles.loader} />}
                <video
                  ref={videoRef}
                  src={file.storage_url}
                  style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                  controls
                  onLoadedData={() => setImageLoading(false)}
                  onError={() => setImageLoading(false)}
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                />
              </View>
            ) : (
              <View style={styles.noPreview}>
                <View style={[styles.noPreviewIcon, { backgroundColor: iconColor + '20' }]}>
                  <Film size={72} color={iconColor} strokeWidth={1.5} />
                </View>
                <Text style={styles.noPreviewName}>{file.name}</Text>
                <Text style={styles.noPreviewMeta}>{formatBytes(file.size)}</Text>
                <TouchableOpacity style={styles.openVideoBtn} onPress={handleDownload}>
                  <Text style={styles.openVideoText}>Open Video</Text>
                </TouchableOpacity>
              </View>
            )
          ) : isAudio && file.storage_url ? (
            <MusicPlayer file={file} url={file.storage_url} />
          ) : isPdf && file.storage_url ? (
            <View style={styles.docContainer}>
              <PdfViewer url={file.storage_url} name={file.name} />
            </View>
          ) : isDocument && file.storage_url ? (
            <View style={styles.docContainer}>
              <DocumentViewer url={file.storage_url} name={file.name} mimeType={file.mime_type} />
            </View>
          ) : (
            <View style={styles.noPreview}>
              <View style={[styles.noPreviewIcon, { backgroundColor: iconColor + '20' }]}>
                <Icon size={72} color={iconColor} strokeWidth={1.5} />
              </View>
              <Text style={styles.noPreviewName}>{file.name}</Text>
              <Text style={styles.noPreviewMeta}>{formatBytes(file.size)}</Text>
              <Text style={styles.noPreviewType}>{file.mime_type}</Text>
              <TouchableOpacity style={styles.openVideoBtn} onPress={handleDownload}>
                <Text style={styles.openVideoText}>Download</Text>
              </TouchableOpacity>
            </View>
          )}

          {currentIndex > 0 && showControls && !isAudio && !isPdf && !isDocument && (
            <TouchableOpacity style={styles.navLeft} onPress={goPrev}>
              <ChevronLeft size={28} color="#fff" strokeWidth={2} />
            </TouchableOpacity>
          )}
          {currentIndex < files.length - 1 && showControls && !isAudio && !isPdf && !isDocument && (
            <TouchableOpacity style={styles.navRight} onPress={goNext}>
              <ChevronRight size={28} color="#fff" strokeWidth={2} />
            </TouchableOpacity>
          )}
        </TouchableOpacity>

        {/* File info panel */}
        {showInfo && (
          <View style={styles.infoPanel}>
            <View style={styles.infoContent}>
              <Text style={styles.infoTitle}>{t('info_title') || 'File Info'}</Text>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>{t('info_name') || 'Name:'}</Text>
                <Text style={styles.infoValue}>{file.name}</Text>
              </View>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>{t('info_size') || 'Size:'}</Text>
                <Text style={styles.infoValue}>{formatBytes(file.size)}</Text>
              </View>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>{t('info_type') || 'Type:'}</Text>
                <Text style={styles.infoValue}>{file.mime_type}</Text>
              </View>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>{t('info_uploaded') || 'Uploaded:'}</Text>
                <Text style={styles.infoValue}>{new Date(file.created_at).toLocaleString()}</Text>
              </View>
              {file.uploaded_from_device && (
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>{t('info_device') || 'Device:'}</Text>
                  <Text style={styles.infoValue}>{file.uploaded_from_device}</Text>
                </View>
              )}
              {file.last_accessed_at && (
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>{t('info_last_view') || 'Last viewed:'}</Text>
                  <Text style={styles.infoValue}>{new Date(file.last_accessed_at).toLocaleString()}</Text>
                </View>
              )}
              {file.duration_seconds && (
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>{t('info_duration') || 'Duration:'}</Text>
                  <Text style={styles.infoValue}>{formatDuration(file.duration_seconds)}</Text>
                </View>
              )}
              {(file.width || file.height) && (
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>{t('info_dimensions') || 'Dimensions:'}</Text>
                  <Text style={styles.infoValue}>{file.width}×{file.height}</Text>
                </View>
              )}
              {file.access_count !== undefined && (
                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>{t('info_views') || 'Views:'}</Text>
                  <Text style={styles.infoValue}>{file.access_count}</Text>
                </View>
              )}
            </View>
            <TouchableOpacity style={styles.infoCloseBtn} onPress={() => setShowInfo(false)}>
              <Text style={styles.infoCloseText}>{t('close') || 'Close'}</Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.actions}>
          <TouchableOpacity style={styles.actionBtn} onPress={() => setShowInfo(!showInfo)}>
            <Info size={22} color={showInfo ? colors.primary : '#fff'} strokeWidth={1.8} />
            <Text style={[styles.actionLabel, showInfo && { color: colors.primary }]}>Info</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn} onPress={handleDownload}>
            <Download size={22} color="#fff" strokeWidth={1.8} />
            <Text style={styles.actionLabel}>{t('download') || 'Download'}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn} onPress={confirmDelete} disabled={deleting}>
            {deleting ? <ActivityIndicator size="small" color={colors.error} /> : <Trash2 size={22} color={colors.error} strokeWidth={1.8} />}
            <Text style={[styles.actionLabel, { color: colors.error }]}>{t('delete') || 'Delete'}</Text>
          </TouchableOpacity>
        </View>

        {/* Delete Confirmation Modal */}
        <Modal visible={showDeleteConfirm} transparent animationType="fade" onRequestClose={() => setShowDeleteConfirm(false)}>
          <View style={styles.deleteModalOverlay}>
            <View style={styles.deleteModalContent}>
              <View style={styles.deleteIconWrap}>
                <Trash2 size={32} color={colors.error} strokeWidth={1.8} />
              </View>
              <Text style={styles.deleteModalTitle}>{t('move_to_trash') || 'Move to Trash'}</Text>
              <Text style={styles.deleteModalDesc}>
                {`"${file.name}" ${t('to_trash') || 'to trash'}?`}
              </Text>
              <Text style={styles.deleteModalNote}>{t('restore_note') || 'You can restore it from trash later.'}</Text>
              <View style={styles.deleteModalActions}>
                <TouchableOpacity
                  style={styles.deleteCancelBtn}
                  onPress={() => setShowDeleteConfirm(false)}
                >
                  <Text style={styles.deleteCancelText}>{t('cancel') || 'Cancel'}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.deleteConfirmBtn} onPress={executeDelete}>
                  <Trash2 size={16} color="#fff" strokeWidth={2} />
                  <Text style={styles.deleteConfirmText}>{t('move_to_trash') || 'Move to Trash'}</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>

        {files.length > 1 && files.length <= 30 && (
          <View style={styles.dots}>
            {files.map((_, i) => (
              <TouchableOpacity key={i} onPress={() => { setCurrentIndex(i); setImageLoading(true); }}>
                <View style={[styles.dot, i === currentIndex && styles.dotActive]} />
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Download Progress */}
        {downloading && (
          <View style={styles.downloadProgressWrap}>
            <View style={styles.downloadProgressCard}>
              <Text style={styles.downloadProgressText} numberOfLines={1}>Endirilir... {downloadProgress}%</Text>
              <View style={styles.downloadProgressBar}>
                <View style={[styles.downloadProgressFill, { width: `${Math.max(5, downloadProgress)}%` as any }]} />
              </View>
            </View>
          </View>
        )}

        {/* Download Toast */}
        {downloadToast && (
          <View style={styles.toastWrap}>
            <View style={styles.toastCard}>
              <Text style={styles.toastText}>{downloadToast}</Text>
            </View>
          </View>
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  topGrad: { position: 'absolute', top: 0, left: 0, right: 0, height: 130, zIndex: 1 },
  bottomGrad: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 220, zIndex: 1 },
  header: {
    position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10,
    flexDirection: 'row', alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 52 : 40,
    paddingHorizontal: spacing.xl, paddingBottom: spacing.lg, gap: spacing.md,
  },
  iconBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center',
  },
  headerInfo: { flex: 1 },
  headerName: { color: '#fff', fontSize: 15, fontWeight: '600' },
  headerMeta: { color: 'rgba(255,255,255,0.55)', fontSize: 12, marginTop: 2 },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  zoomContent: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loader: { position: 'absolute', zIndex: 2 },
  fullImage: { width, height },
  videoContainer: { width, height, position: 'relative' },
  playOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, justifyContent: 'center', alignItems: 'center' },
  playBtn: { width: 72, height: 72, borderRadius: 36, backgroundColor: 'rgba(255,255,255,0.25)', alignItems: 'center', justifyContent: 'center' },
  noPreview: { alignItems: 'center', gap: spacing.md },
  noPreviewIcon: { width: 120, height: 120, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
  noPreviewName: { color: '#fff', fontSize: 16, fontWeight: '600', textAlign: 'center', paddingHorizontal: 32 },
  noPreviewMeta: { color: 'rgba(255,255,255,0.6)', fontSize: 14 },
  noPreviewType: { color: 'rgba(255,255,255,0.4)', fontSize: 12 },
  openVideoBtn: { marginTop: spacing.md, paddingHorizontal: spacing.xl, paddingVertical: spacing.md, backgroundColor: colors.primary, borderRadius: radius.full },
  openVideoText: { color: '#fff', fontSize: 14, fontWeight: '600' },
  navLeft: {
    position: 'absolute', left: spacing.md, zIndex: 2,
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center',
  },
  navRight: {
    position: 'absolute', right: spacing.md, zIndex: 2,
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center',
  },
  actions: {
    position: 'absolute', bottom: Platform.OS === 'ios' ? 52 : 36, left: 0, right: 0, zIndex: 10,
    flexDirection: 'row', justifyContent: 'center', gap: 32,
  },
  actionBtn: { alignItems: 'center', gap: 6 },
  actionLabel: { color: '#fff', fontSize: 12, fontWeight: '500' },
  dots: {
    position: 'absolute', bottom: Platform.OS === 'ios' ? 118 : 100,
    left: 0, right: 0, zIndex: 10,
    flexDirection: 'row', justifyContent: 'center', flexWrap: 'wrap', gap: 5,
    paddingHorizontal: spacing.xl,
  },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.3)' },
  dotActive: { backgroundColor: '#fff', width: 18 },
  docContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
  },
  infoPanel: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 140 : 120,
    left: spacing.md,
    right: spacing.md,
    backgroundColor: 'rgba(0,0,0,0.9)',
    borderRadius: radius.lg,
    padding: spacing.lg,
    zIndex: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  infoContent: { gap: spacing.sm },
  infoTitle: { color: colors.text, fontSize: 16, fontWeight: '700', marginBottom: spacing.sm },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between' },
  infoLabel: { color: colors.textTertiary, fontSize: 12 },
  infoValue: { color: colors.text, fontSize: 12, fontWeight: '500', maxWidth: '60%', textAlign: 'right' },
  infoCloseBtn: {
    marginTop: spacing.md,
    paddingVertical: spacing.sm,
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: radius.md,
  },
  infoCloseText: { color: colors.text, fontSize: 13, fontWeight: '600' },
  deleteModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.85)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  deleteModalContent: {
    backgroundColor: colors.surface,
    borderRadius: radius.xl,
    padding: spacing.xl,
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  deleteIconWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(255,59,48,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
  },
  deleteModalTitle: { color: colors.text, fontSize: 18, fontWeight: '700', marginBottom: spacing.sm },
  deleteModalDesc: { color: colors.textSecondary, fontSize: 14, textAlign: 'center', marginBottom: spacing.sm },
  deleteModalNote: { color: colors.textTertiary, fontSize: 12, textAlign: 'center', marginBottom: spacing.lg },
  deleteModalActions: { flexDirection: 'row', gap: spacing.md, width: '100%' },
  deleteCancelBtn: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
  },
  deleteCancelText: { color: colors.text, fontSize: 14, fontWeight: '600' },
  deleteConfirmBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: colors.error,
  },
  deleteConfirmText: { color: '#fff', fontSize: 14, fontWeight: '600' },
  downloadProgressWrap: {
    position: 'absolute', bottom: 100, left: spacing.lg, right: spacing.lg,
    zIndex: 1000,
  },
  downloadProgressCard: {
    backgroundColor: 'rgba(10,20,40,0.95)',
    borderRadius: radius.lg,
    padding: spacing.lg,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)',
  },
  downloadProgressText: { color: colors.text, fontSize: 13, fontWeight: '600', marginBottom: spacing.sm },
  downloadProgressBar: {
    height: 6, backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 3, overflow: 'hidden',
  },
  downloadProgressFill: {
    height: '100%', backgroundColor: colors.primary, borderRadius: 3,
  },
  toastWrap: {
    position: 'absolute', bottom: 100, left: spacing.lg, right: spacing.lg,
    zIndex: 1000, alignItems: 'center',
  },
  toastCard: {
    backgroundColor: 'rgba(10,20,40,0.95)',
    borderRadius: radius.lg,
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)',
  },
  toastText: { color: colors.text, fontSize: 13, fontWeight: '500' },
});
