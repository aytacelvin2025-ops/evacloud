import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Animated,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  ArrowLeft,
  Chrome,
  Apple,
  Facebook,
  Monitor,
  Github,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { colors, spacing, radius, typography } from '@/constants/theme';

const SOCIALS = [
  { label: 'Google', icon: Chrome, color: '#EA4335', provider: 'google' as const },
  { label: 'Apple', icon: Apple, color: '#FFFFFF', provider: 'apple' as const },
  { label: 'Facebook', icon: Facebook, color: '#1877F2', provider: 'facebook' as const },
  { label: 'Microsoft', icon: Monitor, color: '#00A4EF', provider: 'azure' as const },
  { label: 'GitHub', icon: Github, color: '#FFFFFF', provider: 'github' as const },
];

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [oauthLoading, setOauthLoading] = useState<string | null>(null);
  const [error, setError] = useState('');

  const fadeIn = useRef(new Animated.Value(0)).current;
  const slideUp = useRef(new Animated.Value(28)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeIn, { toValue: 1, duration: 500, useNativeDriver: true }),
      Animated.spring(slideUp, { toValue: 0, tension: 60, friction: 10, useNativeDriver: true }),
    ]).start();
  }, []);

  async function handleLogin() {
    const trimmedEmail = email.trim();
    if (!trimmedEmail) { setError('Please enter your email.'); return; }
    if (!password) { setError('Please enter your password.'); return; }
    setError('');
    setLoading(true);
    try {
      const { error: err } = await supabase.auth.signInWithPassword({
        email: trimmedEmail,
        password,
      });
      if (err) {
        if (err.message.toLowerCase().includes('invalid login credentials')) {
          setError('Incorrect email or password. Please try again.');
        } else if (err.message.toLowerCase().includes('email not confirmed')) {
          setError('Please verify your email address before signing in.');
        } else if (err.message.toLowerCase().includes('too many requests')) {
          setError('Too many attempts. Please wait a moment and try again.');
        } else {
          setError(err.message);
        }
      } else {
        router.replace('/(tabs)');
      }
    } catch {
      setError('Network error. Please check your connection and try again.');
    } finally {
      setLoading(false);
    }
  }

  async function handleOAuth(provider: 'google' | 'apple' | 'facebook' | 'azure' | 'github') {
    setOauthLoading(provider);
    setError('');
    try {
      const redirectTo = Platform.OS === 'web' && typeof window !== 'undefined'
        ? `${window.location.origin}/`
        : 'myapp:///';
      const { error: err } = await supabase.auth.signInWithOAuth({
        provider,
        options: { redirectTo },
      });
      if (err) {
        setError(`Sign-in with ${provider} failed: ${err.message}`);
      }
      // On success, browser redirects to OAuth provider — no further action needed here
    } catch {
      setError('OAuth sign-in failed. Please check your connection.');
    } finally {
      setOauthLoading(null);
    }
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#020A16', '#000000']} style={StyleSheet.absoluteFill} />

      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <ArrowLeft size={22} color={colors.text} strokeWidth={2} />
          </TouchableOpacity>
        </View>

        <Animated.View style={{ opacity: fadeIn, transform: [{ translateY: slideUp }] }}>
          <Text style={styles.title}>Welcome Back</Text>
          <Text style={styles.subtitle}>Sign in to your EVA Cloud X account</Text>

          {!!error && (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          {/* Email */}
          <View style={styles.field}>
            <Text style={styles.label}>Email</Text>
            <View style={styles.inputWrapper}>
              <Mail size={18} color={colors.textSecondary} strokeWidth={1.8} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                value={email}
                onChangeText={v => { setEmail(v); setError(''); }}
                placeholder="your@email.com"
                placeholderTextColor={colors.textTertiary}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
                autoComplete="email"
              />
            </View>
          </View>

          {/* Password */}
          <View style={styles.field}>
            <Text style={styles.label}>Password</Text>
            <View style={styles.inputWrapper}>
              <Lock size={18} color={colors.textSecondary} strokeWidth={1.8} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                value={password}
                onChangeText={v => { setPassword(v); setError(''); }}
                placeholder="••••••••"
                placeholderTextColor={colors.textTertiary}
                secureTextEntry={!showPass}
                autoCapitalize="none"
                autoComplete="password"
              />
              <TouchableOpacity onPress={() => setShowPass(!showPass)} style={styles.eyeBtn}>
                {showPass
                  ? <EyeOff size={18} color={colors.textSecondary} strokeWidth={1.8} />
                  : <Eye size={18} color={colors.textSecondary} strokeWidth={1.8} />
                }
              </TouchableOpacity>
            </View>
          </View>

          {/* Remember me + Forgot */}
          <View style={styles.row}>
            <TouchableOpacity style={styles.checkRow} onPress={() => setRememberMe(!rememberMe)} activeOpacity={0.8}>
              <View style={[styles.checkbox, rememberMe && styles.checkboxActive]}>
                {rememberMe && <Text style={styles.checkmark}>✓</Text>}
              </View>
              <Text style={styles.checkLabel}>Keep me signed in</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => router.push('/(auth)/forgot-password')}>
              <Text style={styles.forgotText}>Forgot Password?</Text>
            </TouchableOpacity>
          </View>

          {/* Login button */}
          <TouchableOpacity onPress={handleLogin} disabled={loading} activeOpacity={0.85}>
            <LinearGradient
              colors={colors.gradientPrimary}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.loginBtn}
            >
              {loading
                ? <ActivityIndicator color={colors.text} />
                : <Text style={styles.loginBtnText}>Sign In</Text>
              }
            </LinearGradient>
          </TouchableOpacity>

          {/* Divider */}
          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or sign in with</Text>
            <View style={styles.dividerLine} />
          </View>

          {/* Social logins — full width */}
          <View style={styles.socialList}>
            {SOCIALS.map((s) => {
              const Icon = s.icon;
              const isLoading = oauthLoading === s.provider;
              return (
                <TouchableOpacity
                  key={s.provider}
                  style={styles.socialBtn}
                  onPress={() => handleOAuth(s.provider)}
                  disabled={!!oauthLoading}
                  activeOpacity={0.75}
                >
                  <View style={styles.socialIconWrap}>
                    {isLoading
                      ? <ActivityIndicator size="small" color={s.color} />
                      : <Icon size={20} color={s.color} strokeWidth={1.8} />
                    }
                  </View>
                  <Text style={styles.socialLabel}>Continue with {s.label}</Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Register link */}
          <TouchableOpacity
            style={styles.registerRow}
            onPress={() => router.push('/(auth)/register')}
          >
            <Text style={styles.registerPrompt}>Don't have an account? </Text>
            <Text style={styles.registerLink}>Create Account</Text>
          </TouchableOpacity>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingHorizontal: spacing.xl, paddingTop: 56, paddingBottom: 48 },
  header: { marginBottom: spacing.xl },
  backBtn: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { ...typography.h1, color: colors.text, marginBottom: spacing.sm },
  subtitle: { ...typography.body, color: colors.textSecondary, marginBottom: spacing.xl },
  errorBox: {
    backgroundColor: 'rgba(255,59,48,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(255,59,48,0.3)',
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  errorText: { color: colors.error, fontSize: 14, lineHeight: 20 },
  field: { marginBottom: spacing.md },
  label: { color: colors.textSecondary, fontSize: 13, fontWeight: '500', marginBottom: spacing.sm },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    height: 52,
  },
  inputIcon: { marginRight: spacing.sm },
  input: {
    flex: 1,
    color: colors.text,
    fontSize: 16,
    height: '100%',
    ...(Platform.OS === 'web' ? { outlineStyle: 'none' } : {}),
  } as any,
  eyeBtn: { padding: spacing.xs },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.xl,
    marginTop: spacing.sm,
  },
  checkRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 5,
    borderWidth: 1.5,
    borderColor: colors.borderHigh,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  checkmark: { color: '#fff', fontSize: 12, fontWeight: '700' },
  checkLabel: { color: colors.textSecondary, fontSize: 14 },
  forgotText: { color: colors.primary, fontSize: 14, fontWeight: '500' },
  loginBtn: {
    height: 52,
    borderRadius: radius.full,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xl,
  },
  loginBtnText: { ...typography.button, color: colors.text },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.lg,
  },
  dividerLine: { flex: 1, height: 1, backgroundColor: colors.border },
  dividerText: { color: colors.textSecondary, fontSize: 13 },
  socialList: { gap: spacing.sm, marginBottom: spacing.xl },
  socialBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingVertical: 13,
    paddingHorizontal: spacing.md,
  },
  socialIconWrap: { width: 32, alignItems: 'center' },
  socialLabel: { flex: 1, color: colors.text, fontSize: 14, fontWeight: '500', marginLeft: spacing.sm },
  registerRow: { flexDirection: 'row', justifyContent: 'center', marginTop: spacing.sm },
  registerPrompt: { color: colors.textSecondary, fontSize: 14 },
  registerLink: { color: colors.primary, fontSize: 14, fontWeight: '600' },
});
