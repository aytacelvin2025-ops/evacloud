import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Dimensions,
  Platform,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '@/context/AuthContext';
import { AnimatedLogo } from '@/components/AnimatedLogo';
import { colors, spacing } from '@/constants/theme';

const { width, height } = Dimensions.get('window');

const SECURITY_BADGES = [
  'AES-256 Protected',
  'AI Security Enabled',
  'Zero Knowledge Encryption',
  'Preparing Secure Environment...',
];

const PROGRESS_STEPS = [0, 35, 70, 100];

function hasCompletedOnboarding(): boolean {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('eva_onboarding_done') === 'true';
  }
  return false;
}

export default function SplashScreen() {
  const { session, loading } = useAuth();
  const [progress, setProgress] = useState(0);
  const [badgeIndex, setBadgeIndex] = useState(0);
  const [splashDone, setSplashDone] = useState(false);

  const progressAnim = useRef(new Animated.Value(0)).current;
  const badgeOpacity = useRef(new Animated.Value(0)).current;
  const containerOpacity = useRef(new Animated.Value(1)).current;
  const titleOpacity = useRef(new Animated.Value(0)).current;
  const titleSlide = useRef(new Animated.Value(16)).current;

  useEffect(() => {
    // Title entrance after 300ms
    const titleTimer = setTimeout(() => {
      Animated.parallel([
        Animated.timing(titleOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.spring(titleSlide, { toValue: 0, tension: 60, friction: 10, useNativeDriver: true }),
      ]).start();
    }, 300);

    // Badge fade in
    Animated.timing(badgeOpacity, { toValue: 1, duration: 500, useNativeDriver: true }).start();

    // Badge cycling
    const badgeInterval = setInterval(() => {
      Animated.sequence([
        Animated.timing(badgeOpacity, { toValue: 0, duration: 180, useNativeDriver: true }),
        Animated.timing(badgeOpacity, { toValue: 1, duration: 280, useNativeDriver: true }),
      ]).start(() => {
        setBadgeIndex(i => (i + 1) % SECURITY_BADGES.length);
      });
    }, 1000);

    // Progress steps
    let stepIdx = 0;
    const progressInterval = setInterval(() => {
      stepIdx++;
      if (stepIdx < PROGRESS_STEPS.length) {
        const p = PROGRESS_STEPS[stepIdx];
        setProgress(p);
        Animated.timing(progressAnim, {
          toValue: p / 100,
          duration: 480,
          useNativeDriver: false,
        }).start();
        if (p === 100) {
          clearInterval(progressInterval);
          // Wait a beat then mark splash done
          setTimeout(() => setSplashDone(true), 400);
        }
      }
    }, 400);

    return () => {
      clearTimeout(titleTimer);
      clearInterval(badgeInterval);
      clearInterval(progressInterval);
    };
  }, []);

  // Navigate once both splash animation done AND auth state resolved
  useEffect(() => {
    if (!splashDone || loading) return;

    Animated.timing(containerOpacity, {
      toValue: 0,
      duration: 400,
      useNativeDriver: true,
    }).start(() => {
      if (session) {
        router.replace('/(tabs)');
      } else if (hasCompletedOnboarding()) {
        router.replace('/welcome');
      } else {
        router.replace('/onboarding');
      }
    });
  }, [splashDone, loading, session]);

  return (
    <Animated.View style={[styles.container, { opacity: containerOpacity }]}>
      <LinearGradient
        colors={['#000000', '#04101F', '#000000']}
        style={StyleSheet.absoluteFill}
      />

      {/* Radial background glow */}
      <View style={styles.bgGlow} />

      {/* Animated EVA logo */}
      <View style={styles.logoArea}>
        <AnimatedLogo size={200} />
      </View>

      {/* App name + tagline */}
      <Animated.View
        style={[
          styles.titleBlock,
          { opacity: titleOpacity, transform: [{ translateY: titleSlide }] },
        ]}
      >
        <Text style={styles.appName}>EVA CLOUD X</Text>
        <Text style={styles.appTagline}>Your Life. Your Cloud. Your Control.</Text>
      </Animated.View>

      {/* Security badge */}
      <Animated.View style={[styles.badgeWrap, { opacity: badgeOpacity }]}>
        <View style={styles.badge}>
          <View style={styles.badgeDot} />
          <Text style={styles.badgeText}>{SECURITY_BADGES[badgeIndex]}</Text>
        </View>
      </Animated.View>

      {/* Progress bar */}
      <View style={styles.progressSection}>
        <View style={styles.progressTrack}>
          <Animated.View
            style={[
              styles.progressFill,
              {
                width: progressAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: ['0%', '100%'],
                }),
              },
            ]}
          >
            <LinearGradient
              colors={['#1E6FFF', '#00D4FF']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={StyleSheet.absoluteFill}
            />
          </Animated.View>
        </View>
        <Text style={styles.progressLabel}>{progress}%</Text>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bgGlow: {
    position: 'absolute',
    width: width * 0.9,
    height: width * 0.9,
    borderRadius: width * 0.45,
    top: height * 0.05,
    alignSelf: 'center',
    backgroundColor: '#1E3A6E',
    opacity: 0.25,
    ...(Platform.OS === 'web' ? { filter: 'blur(100px)' } : {}),
  } as any,
  logoArea: {
    marginBottom: spacing.lg,
  },
  titleBlock: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  appName: {
    fontSize: 26,
    fontWeight: '800',
    color: colors.text,
    letterSpacing: 3,
    marginBottom: 6,
  },
  appTagline: {
    fontSize: 13,
    color: colors.textSecondary,
    letterSpacing: 0.5,
  },
  badgeWrap: {
    marginBottom: spacing.xxl,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(30, 111, 255, 0.12)',
    borderWidth: 1,
    borderColor: 'rgba(30, 111, 255, 0.28)',
    borderRadius: 100,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    gap: spacing.sm,
  },
  badgeDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.secondary,
  },
  badgeText: {
    color: colors.secondary,
    fontSize: 13,
    fontWeight: '500',
    letterSpacing: 0.3,
  },
  progressSection: {
    position: 'absolute',
    bottom: 72,
    width: width * 0.6,
    alignItems: 'center',
    gap: spacing.sm,
  },
  progressTrack: {
    width: '100%',
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressLabel: {
    color: colors.textTertiary,
    fontSize: 11,
    fontWeight: '500',
    letterSpacing: 0.5,
  },
});
