import React, { useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Dimensions,
  TouchableOpacity,
  Platform,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Cloud, Shield, Smartphone } from 'lucide-react-native';
import { colors, spacing, radius, typography } from '@/constants/theme';

const { width, height } = Dimensions.get('window');

const SLIDES = [
  {
    icon: Cloud,
    iconColor: colors.secondary,
    title: 'Welcome to EVA Cloud X',
    subtitle: 'Your private AI cloud with advanced security.',
    gradient: ['#001A40', '#000000'] as [string, string],
  },
  {
    icon: Shield,
    iconColor: '#34C759',
    title: 'AI Powered Security',
    subtitle: 'Every file is protected with AES-256 encryption and intelligent security monitoring.',
    gradient: ['#001A20', '#000000'] as [string, string],
  },
  {
    icon: Smartphone,
    iconColor: colors.primary,
    title: 'Backup Everything Automatically',
    subtitle: 'Photos, videos, documents and memories protected forever.',
    gradient: ['#0A0020', '#000000'] as [string, string],
  },
];

function markOnboardingDone() {
  if (Platform.OS === 'web' && typeof window !== 'undefined') {
    localStorage.setItem('eva_onboarding_done', 'true');
  }
}

export default function OnboardingScreen() {
  const [current, setCurrent] = useState(0);
  const slideX = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const iconScale = useRef(new Animated.Value(1)).current;

  function animateToSlide(next: number) {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 0, duration: 200, useNativeDriver: true }),
      Animated.timing(iconScale, { toValue: 0.7, duration: 200, useNativeDriver: true }),
    ]).start(() => {
      setCurrent(next);
      Animated.parallel([
        Animated.spring(iconScale, { toValue: 1, tension: 60, friction: 8, useNativeDriver: true }),
        Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      ]).start();
    });
  }

  function handleContinue() {
    if (current < SLIDES.length - 1) {
      animateToSlide(current + 1);
    } else {
      markOnboardingDone();
      router.replace('/welcome');
    }
  }

  function handleSkip() {
    markOnboardingDone();
    router.replace('/welcome');
  }

  const slide = SLIDES[current];
  const Icon = slide.icon;
  const isLast = current === SLIDES.length - 1;

  return (
    <View style={styles.container}>
      <LinearGradient colors={slide.gradient} style={StyleSheet.absoluteFill} />

      {/* Background glow */}
      <View style={[styles.glow, { backgroundColor: slide.iconColor }]} />

      {/* Skip button */}
      {!isLast && (
        <TouchableOpacity style={styles.skipBtn} onPress={handleSkip}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
      )}

      {/* Icon area */}
      <Animated.View style={[styles.iconArea, { opacity: fadeAnim, transform: [{ scale: iconScale }] }]}>
        <View style={[styles.iconOuter, { borderColor: slide.iconColor + '30' }]}>
          <View style={[styles.iconInner, { backgroundColor: slide.iconColor + '15' }]}>
            <Icon size={72} color={slide.iconColor} strokeWidth={1.5} />
          </View>
        </View>
      </Animated.View>

      {/* Text content */}
      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        <Text style={styles.title}>{slide.title}</Text>
        <Text style={styles.subtitle}>{slide.subtitle}</Text>
      </Animated.View>

      {/* Dot indicators */}
      <View style={styles.dots}>
        {SLIDES.map((_, i) => (
          <Animated.View
            key={i}
            style={[
              styles.dot,
              i === current && styles.dotActive,
              i === current && { backgroundColor: slide.iconColor },
            ]}
          />
        ))}
      </View>

      {/* CTA button */}
      <TouchableOpacity onPress={handleContinue} activeOpacity={0.85}>
        <LinearGradient
          colors={colors.gradientPrimary}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={styles.ctaButton}
        >
          <Text style={styles.ctaText}>{isLast ? 'Start Now' : 'Continue'}</Text>
        </LinearGradient>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
    paddingBottom: 60,
  },
  glow: {
    position: 'absolute',
    width: width * 0.7,
    height: width * 0.7,
    borderRadius: width * 0.35,
    top: height * 0.05,
    alignSelf: 'center',
    opacity: 0.07,
    filter: Platform.OS === 'web' ? 'blur(100px)' : undefined,
  } as any,
  skipBtn: {
    position: 'absolute',
    top: 56,
    right: spacing.xl,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  skipText: {
    color: colors.textSecondary,
    fontSize: 15,
    fontWeight: '500',
  },
  iconArea: {
    marginBottom: spacing.xxl,
    marginTop: 40,
  },
  iconOuter: {
    width: 200,
    height: 200,
    borderRadius: 100,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconInner: {
    width: 160,
    height: 160,
    borderRadius: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  title: {
    ...typography.h2,
    color: colors.text,
    textAlign: 'center',
    marginBottom: spacing.md,
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 26,
    maxWidth: 300,
  },
  dots: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.xl,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  dotActive: {
    width: 24,
    borderRadius: 4,
  },
  ctaButton: {
    paddingHorizontal: 48,
    paddingVertical: 16,
    borderRadius: radius.full,
    alignItems: 'center',
  },
  ctaText: {
    ...typography.button,
    color: colors.text,
  },
});
