import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { AuthProvider } from '@/context/AuthContext';
import { LanguageProvider } from '@/context/LanguageContext';

export default function RootLayout() {
  useFrameworkReady();

  return (
    <SafeAreaProvider>
      <AuthProvider>
        <LanguageProvider>
          <Stack screenOptions={{ headerShown: false, animation: 'fade' }}>
            <Stack.Screen name="index" />
            <Stack.Screen name="onboarding" options={{ animation: 'fade' }} />
            <Stack.Screen name="welcome" options={{ animation: 'fade' }} />
            <Stack.Screen name="(auth)/login" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="(auth)/register" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="(auth)/forgot-password" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="(tabs)" options={{ animation: 'fade' }} />
            <Stack.Screen name="profile-edit" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="profile-notifications" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="profile-settings" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="profile-appearance" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="help" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="language" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="subscription" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="updates" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="+not-found" />
          </Stack>
          <StatusBar style="light" />
        </LanguageProvider>
      </AuthProvider>
    </SafeAreaProvider>
  );
}
