import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, TouchableOpacity, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowLeft, Bell, Upload, Shield, Mail, Smartphone, Cloud, Check } from 'lucide-react-native';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';

const NOTIFICATION_GROUPS = [
  {
    title: 'Upload & Sync',
    items: [
      { key: 'upload_complete', label: 'Upload Complete', sub: 'When a file upload finishes', icon: Upload, color: colors.primary, dbKey: 'notif_upload_complete' },
      { key: 'auto_backup', label: 'Auto Backup', sub: 'When automatic backup runs', icon: Cloud, color: colors.secondary, dbKey: 'notif_auto_backup' },
    ],
  },
  {
    title: 'Security',
    items: [
      { key: 'new_login', label: 'New Login', sub: 'When your account is accessed from a new device', icon: Smartphone, color: '#F59E0B', dbKey: 'notif_new_login' },
      { key: 'security_alert', label: 'Security Alerts', sub: 'Suspicious activity or login attempts', icon: Shield, color: colors.error, dbKey: 'notif_security_alert' },
    ],
  },
  {
    title: 'Account',
    items: [
      { key: 'storage_full', label: 'Storage Warning', sub: 'When storage is 90% full', icon: Cloud, color: '#FF9F0A', dbKey: 'notif_storage_warning' },
      { key: 'newsletter', label: 'Updates & News', sub: 'Product updates and new features', icon: Mail, color: '#A066FF', dbKey: 'notif_newsletter' },
    ],
  },
];

type DbPrefs = {
  notif_upload_complete: boolean;
  notif_auto_backup: boolean;
  notif_new_login: boolean;
  notif_security_alert: boolean;
  notif_storage_warning: boolean;
  notif_newsletter: boolean;
};

const DEFAULT_PREFS: DbPrefs = {
  notif_upload_complete: true,
  notif_auto_backup: true,
  notif_new_login: true,
  notif_security_alert: true,
  notif_storage_warning: true,
  notif_newsletter: false,
};

export default function NotificationsScreen() {
  const { user } = useAuth();
  const [prefs, setPrefs] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!user) return;
    loadPrefs();
  }, [user]);

  async function loadPrefs() {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        const dbPrefs = data as DbPrefs;
        const mapped: Record<string, boolean> = {};
        NOTIFICATION_GROUPS.forEach(g => g.items.forEach(item => {
          mapped[item.key] = dbPrefs[item.dbKey as keyof DbPrefs] ?? true;
        }));
        setPrefs(mapped);
      } else {
        const defaults: Record<string, boolean> = {};
        NOTIFICATION_GROUPS.forEach(g => g.items.forEach(item => {
          defaults[item.key] = item.dbKey === 'notif_newsletter' ? false : true;
        }));
        setPrefs(defaults);
      }
    } catch {
      const defaults: Record<string, boolean> = {};
      NOTIFICATION_GROUPS.forEach(g => g.items.forEach(item => {
        defaults[item.key] = item.dbKey === 'notif_newsletter' ? false : true;
      }));
      setPrefs(defaults);
    } finally {
      setLoading(false);
    }
  }

  async function savePrefs(newPrefs: Record<string, boolean>) {
    if (!user) return;
    setSaving(true);
    setSaved(false);
    try {
      const dbData: Record<string, boolean> = {};
      NOTIFICATION_GROUPS.forEach(g => g.items.forEach(item => {
        dbData[item.dbKey] = newPrefs[item.key] ?? true;
      }));

      const { error } = await supabase
        .from('user_preferences')
        .upsert({ user_id: user.id, ...dbData, updated_at: new Date().toISOString() });

      if (!error) {
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
      }
    } catch {}
    setSaving(false);
  }

  function toggle(key: string) {
    const newPrefs = { ...prefs, [key]: !prefs[key] };
    setPrefs(newPrefs);
    savePrefs(newPrefs);
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#030810', '#000000']} style={StyleSheet.absoluteFill} />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <ArrowLeft size={22} color={colors.text} strokeWidth={2} />
        </TouchableOpacity>

        <View style={styles.header}>
          <Bell size={28} color={colors.primary} strokeWidth={1.5} />
          <View style={styles.headerText}>
            <Text style={styles.title}>Notifications</Text>
            {(saving || saved) && (
              <View style={styles.saveIndicator}>
                {saving ? (
                  <ActivityIndicator size="small" color={colors.primary} />
                ) : saved ? (
                  <View style={styles.savedBadge}>
                    <Check size={12} color={colors.success} strokeWidth={2.5} />
                    <Text style={styles.savedText}>Saved</Text>
                  </View>
                ) : null}
              </View>
            )}
          </View>
        </View>
        <Text style={styles.subtitle}>Choose what you want to be notified about</Text>

        {loading ? (
          <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 40 }} />
        ) : (
          <>
            {NOTIFICATION_GROUPS.map((group) => (
              <View key={group.title} style={styles.group}>
                <Text style={styles.groupTitle}>{group.title.toUpperCase()}</Text>
                <View style={styles.groupCard}>
                  {group.items.map((item, i) => {
                    const Icon = item.icon;
                    return (
                      <View key={item.key}>
                        {i > 0 && <View style={styles.separator} />}
                        <View style={styles.row}>
                          <View style={[styles.iconWrap, { backgroundColor: item.color + '18' }]}>
                            <Icon size={18} color={item.color} strokeWidth={1.8} />
                          </View>
                          <View style={styles.rowContent}>
                            <Text style={styles.rowLabel}>{item.label}</Text>
                            <Text style={styles.rowSub}>{item.sub}</Text>
                          </View>
                          <Switch
                            value={prefs[item.key] ?? false}
                            onValueChange={() => toggle(item.key)}
                            trackColor={{ false: 'rgba(255,255,255,0.1)', true: item.color + '80' }}
                            thumbColor={prefs[item.key] ? item.color : 'rgba(255,255,255,0.4)'}
                          />
                        </View>
                      </View>
                    );
                  })}
                </View>
              </View>
            ))}
          </>
        )}

        <Text style={styles.note}>
          Push notifications require the native app build. Browser notifications are limited to security alerts.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingHorizontal: spacing.xl, paddingTop: 56, paddingBottom: 48 },
  backBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: colors.border, marginBottom: spacing.xl,
  },
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.sm },
  headerText: { flex: 1 },
  saveIndicator: { position: 'absolute', right: 0, top: 4 },
  savedBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(52,199,89,0.15)', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 12 },
  savedText: { color: colors.success, fontSize: 12, fontWeight: '600' },
  title: { ...typography.h1, color: colors.text },
  subtitle: { color: colors.textSecondary, fontSize: 14, marginBottom: spacing.xl, lineHeight: 22 },
  group: { marginBottom: spacing.xl },
  groupTitle: { color: colors.textTertiary, fontSize: 11, fontWeight: '600', letterSpacing: 1, marginBottom: spacing.md },
  groupCard: {
    backgroundColor: colors.surface, borderRadius: radius.lg,
    borderWidth: 1, borderColor: colors.border, overflow: 'hidden',
  },
  separator: { height: 1, backgroundColor: colors.border },
  row: { flexDirection: 'row', alignItems: 'center', padding: spacing.lg, gap: spacing.md },
  iconWrap: { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  rowContent: { flex: 1 },
  rowLabel: { color: colors.text, fontSize: 14, fontWeight: '500' },
  rowSub: { color: colors.textSecondary, fontSize: 12, marginTop: 2, lineHeight: 16 },
  note: { color: colors.textTertiary, fontSize: 12, textAlign: 'center', lineHeight: 18 },
});
