import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowLeft, Check, Crown, Zap, Infinity } from 'lucide-react-native';
import { colors, spacing, radius, typography } from '@/constants/theme';

const PLANS = [
  {
    id: 'free',
    name: 'Free Plan',
    price: 'Free',
    period: '',
    storage: '15 TB',
    features: ['15 TB cloud storage', 'Auto backup', 'Photo & video upload', 'Document storage', '256-bit encryption'],
    color: colors.textSecondary,
    gradient: ['rgba(128,128,128,0.2)', 'rgba(128,128,128,0.05)'] as const,
  },
  {
    id: 'pro',
    name: 'Pro',
    price: '$9.99',
    period: '/month',
    storage: 'Unlimited',
    features: ['Unlimited storage', 'Priority upload speed', 'Advanced sharing', 'Version history (90 days)', 'Priority support', 'No ads'],
    color: colors.primary,
    gradient: colors.gradientPrimary,
    recommended: true,
  },
];

export default function SubscriptionScreen() {
  const [selected, setSelected] = useState('free');

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#030810', '#000000']} style={StyleSheet.absoluteFill} />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <ArrowLeft size={22} color={colors.text} strokeWidth={2} />
        </TouchableOpacity>

        <View style={styles.header}>
          <Crown size={28} color={colors.primary} strokeWidth={1.5} />
          <Text style={styles.title}>Subscription</Text>
        </View>
        <Text style={styles.subtitle}>Choose the plan that fits your needs</Text>

        {PLANS.map(plan => (
          <TouchableOpacity
            key={plan.id}
            style={[styles.planCard, selected === plan.id && { borderColor: plan.color }]}
            onPress={() => setSelected(plan.id)}
            activeOpacity={0.85}
          >
            <LinearGradient colors={plan.gradient} style={StyleSheet.absoluteFill} />
            {plan.recommended && (
              <View style={styles.recommendedBadge}>
                <Zap size={10} color="#fff" strokeWidth={2.5} />
                <Text style={styles.recommendedText}>RECOMMENDED</Text>
              </View>
            )}
            <View style={styles.planHeader}>
              <View style={styles.planNameRow}>
                {plan.id === 'pro' && <Crown size={16} color={plan.color} strokeWidth={2} />}
                <Text style={[styles.planName, { color: plan.color }]}>{plan.name}</Text>
              </View>
              <View style={styles.priceRow}>
                <Text style={styles.price}>{plan.price}</Text>
                <Text style={styles.period}>{plan.period}</Text>
              </View>
              <View style={styles.storageRow}>
                <Infinity size={14} color={plan.color} strokeWidth={2} />
                <Text style={[styles.storage, { color: plan.color }]}>{plan.storage} storage</Text>
              </View>
            </View>
            <View style={styles.featureList}>
              {plan.features.map((f, i) => (
                <View key={i} style={styles.featureRow}>
                  <Check size={14} color={plan.color} strokeWidth={2.5} />
                  <Text style={styles.featureText}>{f}</Text>
                </View>
              ))}
            </View>
            {selected === plan.id && (
              <View style={styles.selectedIndicator}>
                <Check size={16} color="#fff" strokeWidth={3} />
              </View>
            )}
          </TouchableOpacity>
        ))}

        <TouchableOpacity style={styles.upgradeBtn} activeOpacity={0.85}>
          <LinearGradient
            colors={selected === 'pro' ? colors.gradientPrimary : ['rgba(128,128,128,0.3)', 'rgba(128,128,128,0.2)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.upgradeBtnInner}
          >
            {selected === 'pro' ? (
              <Crown size={18} color="#fff" strokeWidth={2} />
            ) : null}
            <Text style={styles.upgradeBtnText}>
              {selected === 'free' ? 'Current Plan' : 'Upgrade to Pro'}
            </Text>
          </LinearGradient>
        </TouchableOpacity>

        <Text style={styles.terms}>
          Subscriptions will be available after Play Store / App Store deployment.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingHorizontal: spacing.xl, paddingTop: 56, paddingBottom: 48 },
  backBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: colors.border, marginBottom: spacing.xl,
  },
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.sm },
  title: { ...typography.h1, color: colors.text },
  subtitle: { color: colors.textSecondary, fontSize: 14, marginBottom: spacing.xl },
  planCard: {
    borderRadius: radius.xl, borderWidth: 1, borderColor: colors.border,
    padding: spacing.xl, marginBottom: spacing.lg, overflow: 'hidden', position: 'relative',
  },
  recommendedBadge: {
    position: 'absolute', top: spacing.md, right: spacing.md,
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.primary, paddingHorizontal: spacing.sm, paddingVertical: 4, borderRadius: radius.sm,
  },
  recommendedText: { color: '#fff', fontSize: 9, fontWeight: '700', letterSpacing: 0.5 },
  planHeader: { marginBottom: spacing.lg },
  planNameRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.sm },
  planName: { fontSize: 18, fontWeight: '700' },
  priceRow: { flexDirection: 'row', alignItems: 'baseline', gap: 2 },
  price: { color: colors.text, fontSize: 28, fontWeight: '700' },
  period: { color: colors.textSecondary, fontSize: 14 },
  storageRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: spacing.sm },
  storage: { fontSize: 13, fontWeight: '600' },
  featureList: { gap: spacing.sm },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  featureText: { color: colors.textSecondary, fontSize: 13 },
  selectedIndicator: {
    position: 'absolute', bottom: spacing.md, right: spacing.md,
    width: 28, height: 28, borderRadius: 14, backgroundColor: colors.primary,
    alignItems: 'center', justifyContent: 'center',
  },
  upgradeBtn: { marginTop: spacing.md, borderRadius: radius.full, overflow: 'hidden' },
  upgradeBtnInner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    paddingVertical: 16, borderRadius: radius.full,
  },
  upgradeBtnText: { ...typography.button, color: colors.text },
  terms: { color: colors.textTertiary, fontSize: 11, textAlign: 'center', marginTop: spacing.lg, lineHeight: 16 },
});
