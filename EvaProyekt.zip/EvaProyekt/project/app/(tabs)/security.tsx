import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Modal,
  TextInput,
  ActivityIndicator,
  Alert,
  RefreshControl,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Shield,
  Lock,
  Fingerprint,
  Smartphone,
  AlertTriangle,
  Eye,
  EyeOff,
  Key,
  RefreshCw,
  CheckCircle,
  ChevronRight,
  X,
  Monitor,
  Tablet,
  MapPin,
  Clock,
  Ban,
  LogOut,
} from 'lucide-react-native';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { AppHeader } from '@/components/AppHeader';
import { useLanguage } from '@/context/LanguageContext';

type SessionRecord = {
  id: string;
  device_name: string;
  browser: string;
  platform: string;
  ip_address: string;
  country: string | null;
  is_current: boolean;
  signed_in_at: string;
  last_active_at: string;
};

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 2) return 'Just now';
  if (mins < 60) return `${mins} minutes ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hour${hrs > 1 ? 's' : ''} ago`;
  const days = Math.floor(hrs / 24);
  return `${days} day${days > 1 ? 's' : ''} ago`;
}

function SessionIcon({ platform }: { platform: string }) {
  if (platform.includes('iOS') || platform.includes('Android') || platform.includes('iPhone')) {
    return <Smartphone size={18} color={colors.primary} strokeWidth={1.8} />;
  }
  if (platform.includes('Mac') || platform.includes('Windows') || platform.includes('Linux')) {
    return <Monitor size={18} color={colors.primary} strokeWidth={1.8} />;
  }
  return <Tablet size={18} color={colors.primary} strokeWidth={1.8} />;
}

function ChangePasswordModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const [current, setCurrent] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  function reset() {
    setCurrent(''); setNewPwd(''); setConfirm('');
    setError(''); setSuccess(false);
    setShowCurrent(false); setShowNew(false);
  }

  async function handleChange() {
    setError('');
    if (!current || !newPwd || !confirm) { setError('All fields are required.'); return; }
    if (newPwd.length < 6) { setError('New password must be at least 6 characters.'); return; }
    if (newPwd !== confirm) { setError('Passwords do not match.'); return; }
    setLoading(true);
    try {
      // Re-authenticate with current password first
      const { data: userData } = await supabase.auth.getUser();
      const email = userData.user?.email;
      if (!email) { setError('Unable to verify identity.'); setLoading(false); return; }

      const { error: signInErr } = await supabase.auth.signInWithPassword({ email, password: current });
      if (signInErr) { setError('Current password is incorrect.'); setLoading(false); return; }

      const { error: updateErr } = await supabase.auth.updateUser({ password: newPwd });
      if (updateErr) { setError(updateErr.message); setLoading(false); return; }

      setSuccess(true);
      setTimeout(() => { reset(); onClose(); }, 1500);
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={modal.overlay}>
        <View style={modal.sheet}>
          <LinearGradient colors={['#0A1628', '#000']} style={StyleSheet.absoluteFill} />
          <View style={modal.header}>
            <Text style={modal.title}>Change Password</Text>
            <TouchableOpacity onPress={() => { reset(); onClose(); }} style={modal.closeBtn}>
              <X size={20} color={colors.textSecondary} strokeWidth={2} />
            </TouchableOpacity>
          </View>

          {success ? (
            <View style={modal.successBox}>
              <CheckCircle size={40} color={colors.success} strokeWidth={1.5} />
              <Text style={modal.successText}>Password updated successfully!</Text>
            </View>
          ) : (
            <>
              {!!error && (
                <View style={modal.errorBox}>
                  <Text style={modal.errorText}>{error}</Text>
                </View>
              )}

              {[
                { label: 'Current Password', value: current, set: setCurrent, show: showCurrent, toggle: () => setShowCurrent(v => !v) },
                { label: 'New Password', value: newPwd, set: setNewPwd, show: showNew, toggle: () => setShowNew(v => !v) },
                { label: 'Confirm New Password', value: confirm, set: setConfirm, show: showNew, toggle: () => setShowNew(v => !v) },
              ].map(({ label, value, set, show, toggle }) => (
                <View key={label} style={modal.field}>
                  <Text style={modal.label}>{label}</Text>
                  <View style={modal.inputRow}>
                    <TextInput
                      style={modal.input}
                      value={value}
                      onChangeText={set}
                      secureTextEntry={!show}
                      placeholder="••••••••"
                      placeholderTextColor={colors.textTertiary}
                      autoCapitalize="none"
                    />
                    <TouchableOpacity onPress={toggle} style={modal.eyeBtn}>
                      {show
                        ? <EyeOff size={18} color={colors.textSecondary} strokeWidth={1.8} />
                        : <Eye size={18} color={colors.textSecondary} strokeWidth={1.8} />
                      }
                    </TouchableOpacity>
                  </View>
                </View>
              ))}

              <TouchableOpacity
                style={modal.saveBtn}
                onPress={handleChange}
                disabled={loading}
                activeOpacity={0.85}
              >
                <LinearGradient
                  colors={colors.gradientPrimary}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={modal.saveBtnInner}
                >
                  {loading
                    ? <ActivityIndicator color="#fff" />
                    : <Text style={modal.saveBtnText}>Update Password</Text>
                  }
                </LinearGradient>
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
    </Modal>
  );
}

export default function SecurityScreen() {
  const { user, session, signOut } = useAuth();
  const { t } = useLanguage();
  const [twoFA, setTwoFA] = useState(true);
  const [loginAlerts, setLoginAlerts] = useState(true);
  const [biometric, setBiometric] = useState(false);
  const [unknownDevice, setUnknownDevice] = useState(true);
  const [showChangePwd, setShowChangePwd] = useState(false);
  const [sessions, setSessions] = useState<SessionRecord[]>([]);
  const [loadingSessions, setLoadingSessions] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedSession, setSelectedSession] = useState<SessionRecord | null>(null);
  const [showSessionModal, setShowSessionModal] = useState(false);
  const [showSignOutConfirm, setShowSignOutConfirm] = useState(false);

  // Security score: each enabled feature adds points
  const score = 40 + (twoFA ? 20 : 0) + (loginAlerts ? 10 : 0) + (biometric ? 20 : 0) + (unknownDevice ? 10 : 0);
  const scoreLabel = score >= 90 ? 'Excellent' : score >= 70 ? 'Good' : score >= 50 ? 'Fair' : 'Weak';
  const scoreColor = score >= 90 ? '#34C759' : score >= 70 ? '#00D4FF' : score >= 50 ? '#FF9F0A' : colors.error;

  async function loadSessions() {
    if (!user) return;
    const { data } = await supabase
      .from('user_sessions')
      .select('*')
      .eq('user_id', user.id)
      .order('last_active_at', { ascending: false })
      .limit(10);
    if (data) setSessions(data as SessionRecord[]);
    setLoadingSessions(false);
    setRefreshing(false);
  }

  useEffect(() => { loadSessions(); }, [user]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadSessions();
  }, [user]);

  async function handleSignOutSession(sessionId: string) {
    await supabase.from('user_sessions').delete().eq('id', sessionId);
    setSessions(prev => prev.filter(s => s.id !== sessionId));
    setShowSessionModal(false);
    setSelectedSession(null);
  }

  async function handleSignOutAllSessions() {
    if (!user) return;
    const currentSessionId = sessions.find(s => s.is_current)?.id;
    if (currentSessionId) {
      await supabase.from('user_sessions').delete().eq('user_id', user.id).neq('id', currentSessionId);
      setSessions(prev => prev.filter(s => s.is_current));
    }
    setShowSignOutConfirm(false);
  }

  function openSessionDetails(sess: SessionRecord) {
    setSelectedSession(sess);
    setShowSessionModal(true);
  }

  const currentSession = sessions.find(s => s.is_current);
  const otherSessions = sessions.filter(s => !s.is_current);

  const SECURITY_GROUPS = [
    {
      group: 'AUTHENTICATION',
      items: [
        { label: '2-Factor Authentication', sub: 'Add an extra layer of security', icon: Lock, value: twoFA, onChange: setTwoFA, color: colors.primary },
        { label: 'Biometric Login', sub: 'Use fingerprint or Face ID', icon: Fingerprint, value: biometric, onChange: setBiometric, color: '#A066FF' },
      ],
    },
    {
      group: 'ALERTS',
      items: [
        { label: 'Login Alerts', sub: 'Get notified of new sign-ins', icon: AlertTriangle, value: loginAlerts, onChange: setLoginAlerts, color: colors.warning },
        { label: 'Unknown Device Alerts', sub: 'Alert on unrecognized devices', icon: Smartphone, value: unknownDevice, onChange: setUnknownDevice, color: colors.error },
      ],
    },
  ];

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />
      <AppHeader />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
      >
        <Text style={styles.title}>{t('security')}</Text>

        {/* Security score card */}
        <View style={[styles.scoreCard, { borderColor: scoreColor + '30' }]}>
          <LinearGradient
            colors={[scoreColor + '18', 'rgba(0,0,0,0)']}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.scoreTopRow}>
            <View style={styles.scoreLeft}>
              <Text style={styles.scoreLabel}>{t('security_score')}</Text>
              <Text style={[styles.scoreValue, { color: scoreColor }]}>{scoreLabel}</Text>
              <Text style={styles.scoreSub}>
                {biometric ? t('account_protected') : t('enable_biometric')}
              </Text>
            </View>
            <View style={styles.scoreCircle}>
              <Text style={[styles.scoreNum, { color: scoreColor }]}>{score}</Text>
              <Text style={styles.scoreMax}>/100</Text>
            </View>
          </View>
          <View style={styles.scoreBarBg}>
            <View style={[styles.scoreBarFill, { width: `${score}%` }]}>
              <LinearGradient
                colors={[scoreColor, scoreColor + 'AA']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={StyleSheet.absoluteFill}
              />
            </View>
          </View>
        </View>

        {/* Toggle groups */}
        {SECURITY_GROUPS.map(group => (
          <View key={group.group} style={styles.section}>
            <Text style={styles.sectionTitle}>{t('authentication')}</Text>
            <View style={styles.card}>
              {group.items.map((item, i) => {
                const Icon = item.icon;
                return (
                  <View key={item.label}>
                    {i > 0 && <View style={styles.sep} />}
                    <View style={styles.row}>
                      <View style={[styles.iconWrap, { backgroundColor: item.color + '18' }]}>
                        <Icon size={18} color={item.color} strokeWidth={1.8} />
                      </View>
                      <View style={styles.rowInfo}>
                        <Text style={styles.rowLabel}>{t(item.label === '2-Factor Authentication' ? 'two_factor' : item.label === 'Biometric Login' ? 'biometric_login' : item.label === 'Login Alerts' ? 'login_alerts' : 'unknown_device_alerts')}</Text>
                        <Text style={styles.rowSub}>{t(item.label === '2-Factor Authentication' ? 'two_factor_desc' : item.label === 'Biometric Login' ? 'biometric_login_desc' : item.label === 'Login Alerts' ? 'login_alerts_desc' : 'unknown_device_desc')}</Text>
                      </View>
                      <Switch
                        value={item.value}
                        onValueChange={item.onChange}
                        trackColor={{ false: 'rgba(255,255,255,0.1)', true: item.color + '80' }}
                        thumbColor={item.value ? item.color : 'rgba(255,255,255,0.4)'}
                      />
                    </View>
                  </View>
                );
              })}
            </View>
          </View>
        ))}

        {/* Security actions */}
        <Text style={styles.sectionTitle}>{t('security_actions')}</Text>
        <View style={styles.card}>
          <TouchableOpacity style={styles.actionRow} activeOpacity={0.75} onPress={() => setShowChangePwd(true)}>
            <View style={[styles.iconWrap, { backgroundColor: colors.primary + '18' }]}>
              <Key size={18} color={colors.primary} strokeWidth={1.8} />
            </View>
            <Text style={styles.actionLabel}>{t('change_password')}</Text>
            <ChevronRight size={16} color={colors.textTertiary} strokeWidth={2} />
          </TouchableOpacity>
          <View style={styles.sep} />
          <TouchableOpacity style={styles.actionRow} activeOpacity={0.75} onPress={() => Alert.alert(t('recovery_codes'), t('recovery_codes_desc'))}>
            <View style={[styles.iconWrap, { backgroundColor: '#A066FF18' }]}>
              <Eye size={18} color="#A066FF" strokeWidth={1.8} />
            </View>
            <Text style={styles.actionLabel}>{t('view_recovery_codes')}</Text>
            <ChevronRight size={16} color={colors.textTertiary} strokeWidth={2} />
          </TouchableOpacity>
          <View style={styles.sep} />
          <TouchableOpacity
            style={styles.actionRow}
            activeOpacity={0.75}
            onPress={async () => {
              await supabase.auth.refreshSession();
              Alert.alert(t('session_refreshed'), t('session_refreshed_desc'));
            }}
          >
            <View style={[styles.iconWrap, { backgroundColor: colors.secondary + '18' }]}>
              <RefreshCw size={18} color={colors.secondary} strokeWidth={1.8} />
            </View>
            <Text style={styles.actionLabel}>{t('refresh_session')}</Text>
            <ChevronRight size={16} color={colors.textTertiary} strokeWidth={2} />
          </TouchableOpacity>
        </View>

        {/* Active sessions */}
        <Text style={[styles.sectionTitle, { marginTop: spacing.lg }]}>{t('active_sessions')}</Text>

        {/* Current session card */}
        {currentSession && (
          <TouchableOpacity
            style={[styles.currentSessionCard]}
            onPress={() => openSessionDetails(currentSession)}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={['rgba(52,199,89,0.15)', 'rgba(52,199,89,0.05)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.currentSessionHeader}>
              <View style={[styles.iconWrapLarge, { backgroundColor: '#34C75918' }]}>
                <SessionIcon platform={currentSession.platform ?? ''} />
              </View>
              <View style={styles.currentSessionInfo}>
                <View style={styles.currentSessionTitleRow}>
                  <Text style={styles.currentSessionTitle}>{currentSession.device_name}</Text>
                  <View style={styles.currentBadge}>
                    <Text style={styles.currentBadgeText}>{t('now_current')}</Text>
                  </View>
                </View>
                <Text style={styles.currentSessionSub}>{currentSession.browser} · {currentSession.platform}</Text>
                <Text style={styles.currentSessionTime}>
                  <Clock size={10} color={colors.textTertiary} /> {t('signed_in')}: {new Date(currentSession.signed_in_at).toLocaleString()}
                </Text>
              </View>
              <ChevronRight size={16} color={colors.textTertiary} strokeWidth={2} />
            </View>
          </TouchableOpacity>
        )}

        {/* Other sessions */}
        {otherSessions.length > 0 && (
          <>
            <View style={styles.otherSessionsHeader}>
              <Text style={styles.otherSessionsTitle}>{t('other_sessions')}</Text>
              <TouchableOpacity style={styles.signOutAllBtn} onPress={() => setShowSignOutConfirm(true)}>
                <LogOut size={12} color={colors.error} strokeWidth={1.8} />
                <Text style={styles.signOutAllText}>{t('sign_out_all')}</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.card}>
              {otherSessions.map((sess, i) => (
                <View key={sess.id}>
                  {i > 0 && <View style={styles.sep} />}
                  <TouchableOpacity
                    style={styles.sessionRow}
                    onPress={() => openSessionDetails(sess)}
                    activeOpacity={0.8}
                  >
                    <View style={[styles.iconWrap, { backgroundColor: colors.surface }]}>
                      <SessionIcon platform={sess.platform ?? ''} />
                    </View>
                    <View style={styles.rowInfo}>
                      <Text style={styles.rowLabel}>{sess.device_name}</Text>
                      <Text style={styles.rowSub}>{sess.browser}</Text>
                      <Text style={styles.sessionTime}>
                        <MapPin size={10} color={colors.textTertiary} /> {sess.ip_address} · {sess.country || 'Unknown'}
                      </Text>
                      <Text style={styles.sessionTime}>
                        <Clock size={10} color={colors.textTertiary} /> {timeAgo(sess.last_active_at)}
                      </Text>
                    </View>
                    <ChevronRight size={16} color={colors.textTertiary} strokeWidth={2} />
                  </TouchableOpacity>
                </View>
              ))}
            </View>
          </>
        )}

        {loadingSessions && sessions.length === 0 && (
          <ActivityIndicator color={colors.primary} style={{ padding: spacing.xl }} />
        )}

        {sessions.length === 0 && !loadingSessions && (
          <View style={styles.emptySession}>
            <Text style={styles.emptySessionText}>{t('no_sessions')}</Text>
            <Text style={styles.emptySessionSub}>{t('sessions_appear')}</Text>
          </View>
        )}

        <Text style={styles.lastSignIn}>
          {user?.last_sign_in_at
            ? `${t('last_sign_in')} ${new Date(user.last_sign_in_at).toLocaleString()}`
            : ''}
        </Text>
      </ScrollView>

      {/* Session detail modal */}
      <Modal visible={showSessionModal} transparent animationType="slide" onRequestClose={() => setShowSessionModal(false)}>
        <View style={modal.overlay}>
          <View style={modal.sheet}>
            <LinearGradient colors={['#0A1628', '#000']} style={StyleSheet.absoluteFill} />
            <View style={modal.header}>
              <Text style={modal.title}>{t('session_info')}</Text>
              <TouchableOpacity onPress={() => setShowSessionModal(false)} style={modal.closeBtn}>
                <X size={20} color={colors.textSecondary} strokeWidth={2} />
              </TouchableOpacity>
            </View>

            {selectedSession && (
              <>
                <View style={modal.sessionIconWrap}>
                  <SessionIcon platform={selectedSession.platform ?? ''} />
                </View>
                <Text style={modal.sessionName}>{selectedSession.device_name}</Text>
                <View style={[modal.statusBadge, selectedSession.is_current && modal.statusBadgeCurrent]}>
                  <Text style={[modal.statusBadgeText, selectedSession.is_current && modal.statusBadgeTextCurrent]}>
                    {selectedSession.is_current ? t('current_session') : 'Other device'}
                  </Text>
                </View>

                <View style={modal.infoGrid}>
                  <View style={modal.infoRow}>
                    <Smartphone size={16} color={colors.textTertiary} strokeWidth={1.8} />
                    <Text style={modal.infoLabel}>{t('device')}:</Text>
                    <Text style={modal.infoValue}>{selectedSession.platform}</Text>
                  </View>
                  <View style={modal.infoRow}>
                    <Monitor size={16} color={colors.textTertiary} strokeWidth={1.8} />
                    <Text style={modal.infoLabel}>{t('browser')}:</Text>
                    <Text style={modal.infoValue}>{selectedSession.browser}</Text>
                  </View>
                  <View style={modal.infoRow}>
                    <MapPin size={16} color={colors.textTertiary} strokeWidth={1.8} />
                    <Text style={modal.infoLabel}>{t('location')}:</Text>
                    <Text style={modal.infoValue}>{selectedSession.ip_address} · {selectedSession.country || 'Unknown'}</Text>
                  </View>
                  <View style={modal.infoRow}>
                    <Clock size={16} color={colors.textTertiary} strokeWidth={1.8} />
                    <Text style={modal.infoLabel}>{t('signed_in')}:</Text>
                    <Text style={modal.infoValue}>{new Date(selectedSession.signed_in_at).toLocaleString()}</Text>
                  </View>
                  <View style={modal.infoRow}>
                    <RefreshCw size={16} color={colors.textTertiary} strokeWidth={1.8} />
                    <Text style={modal.infoLabel}>{t('last_active')}:</Text>
                    <Text style={modal.infoValue}>{new Date(selectedSession.last_active_at).toLocaleString()}</Text>
                  </View>
                </View>

                {!selectedSession.is_current && (
                  <TouchableOpacity
                    style={modal.signOutSessionBtn}
                    onPress={() => handleSignOutSession(selectedSession.id)}
                  >
                    <LogOut size={16} color={colors.error} strokeWidth={1.8} />
                    <Text style={modal.signOutSessionText}>{t('sign_out')}</Text>
                  </TouchableOpacity>
                )}
              </>
            )}
          </View>
        </View>
      </Modal>

      {/* Sign out all confirm modal */}
      <Modal visible={showSignOutConfirm} transparent animationType="fade" onRequestClose={() => setShowSignOutConfirm(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.confirmModalContent}>
            <View style={styles.confirmIconWrap}>
              <LogOut size={32} color={colors.warning} strokeWidth={1.8} />
            </View>
            <Text style={styles.confirmTitle}>{t('sign_out_all')}</Text>
            <Text style={styles.confirmDesc}>{t('sign_out_all_desc') || 'This will sign out all other devices. You will remain signed in on this device.'}</Text>
            <View style={styles.confirmActions}>
              <TouchableOpacity style={styles.confirmCancelBtn} onPress={() => setShowSignOutConfirm(false)}>
                <Text style={styles.confirmCancelText}>{t('cancel')}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.confirmSignOutBtn} onPress={handleSignOutAllSessions}>
                <LogOut size={16} color="#fff" strokeWidth={2} />
                <Text style={styles.confirmSignOutText}>{t('sign_out_all')}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <ChangePasswordModal visible={showChangePwd} onClose={() => setShowChangePwd(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: 100 },
  title: { ...typography.h1, color: colors.text, marginBottom: spacing.xl },

  scoreCard: {
    borderRadius: radius.xl,
    padding: spacing.xl,
    borderWidth: 1,
    overflow: 'hidden',
    marginBottom: spacing.xl,
  },
  scoreTopRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: spacing.md },
  scoreLeft: { flex: 1, paddingRight: spacing.md },
  scoreLabel: { color: colors.textSecondary, fontSize: 13, marginBottom: 4 },
  scoreValue: { fontSize: 24, fontWeight: '700', marginBottom: 4 },
  scoreSub: { color: colors.textSecondary, fontSize: 12, lineHeight: 18 },
  scoreCircle: { flexDirection: 'row', alignItems: 'baseline', gap: 2 },
  scoreNum: { fontSize: 48, fontWeight: '800', lineHeight: 56 },
  scoreMax: { fontSize: 16, color: colors.textSecondary },
  scoreBarBg: { height: 6, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 3, overflow: 'hidden' },
  scoreBarFill: { height: '100%', borderRadius: 3, overflow: 'hidden' },

  section: { marginBottom: spacing.lg },
  sectionTitle: {
    color: colors.textTertiary, fontSize: 11, fontWeight: '600',
    letterSpacing: 1, marginBottom: spacing.sm, marginTop: spacing.sm,
  },
  card: {
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.lg, overflow: 'hidden', marginBottom: spacing.sm,
  },
  sep: { height: 1, backgroundColor: colors.border, marginLeft: 62 },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, padding: spacing.md },
  actionRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, padding: spacing.md },
  sessionRow: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.md, padding: spacing.md },
  iconWrap: { width: 38, height: 38, borderRadius: radius.sm, alignItems: 'center', justifyContent: 'center' },
  iconWrapLarge: { width: 48, height: 48, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
  rowInfo: { flex: 1 },
  rowLabel: { color: colors.text, fontSize: 14, fontWeight: '500' },
  rowSub: { color: colors.textSecondary, fontSize: 12, marginTop: 2 },
  actionLabel: { flex: 1, color: colors.text, fontSize: 14, fontWeight: '500' },
  sessionTime: { color: colors.textTertiary, fontSize: 11, marginTop: 2, flexDirection: 'row', alignItems: 'center', gap: 4 },
  signOutBtn: { color: colors.error, fontSize: 13, fontWeight: '500' },
  emptySession: { padding: spacing.xl, alignItems: 'center', gap: spacing.sm },
  emptySessionText: { color: colors.textSecondary, fontSize: 14, fontWeight: '500' },
  emptySessionSub: { color: colors.textTertiary, fontSize: 12, textAlign: 'center' },
  lastSignIn: { color: colors.textTertiary, fontSize: 11, textAlign: 'center', marginTop: spacing.lg },

  // Current session card
  currentSessionCard: {
    borderRadius: radius.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(52,199,89,0.3)',
    overflow: 'hidden',
    padding: spacing.lg,
  },
  currentSessionHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  currentSessionInfo: { flex: 1 },
  currentSessionTitleRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: 2 },
  currentSessionTitle: { color: colors.text, fontSize: 15, fontWeight: '600' },
  currentBadge: { backgroundColor: 'rgba(52,199,89,0.2)', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4 },
  currentBadgeText: { color: colors.success, fontSize: 10, fontWeight: '600' },
  currentSessionSub: { color: colors.textSecondary, fontSize: 12, marginBottom: 4 },
  currentSessionTime: { color: colors.textTertiary, fontSize: 11 },

  // Other sessions
  otherSessionsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  otherSessionsTitle: { color: colors.textTertiary, fontSize: 11, fontWeight: '600', letterSpacing: 1 },
  signOutAllBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: spacing.sm, paddingVertical: 4, backgroundColor: 'rgba(255,59,48,0.1)', borderRadius: radius.sm },
  signOutAllText: { color: colors.error, fontSize: 11, fontWeight: '500' },

  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.75)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  confirmModalContent: {
    backgroundColor: colors.surface,
    borderRadius: radius.xl,
    padding: spacing.xl,
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  confirmIconWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(255,159,10,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
  },
  confirmTitle: { color: colors.text, fontSize: 18, fontWeight: '700', marginBottom: spacing.sm },
  confirmDesc: { color: colors.textSecondary, fontSize: 14, textAlign: 'center', marginBottom: spacing.lg },
  confirmActions: { flexDirection: 'row', gap: spacing.md, width: '100%' },
  confirmCancelBtn: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
  },
  confirmCancelText: { color: colors.text, fontSize: 14, fontWeight: '600' },
  confirmSignOutBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: colors.warning,
  },
  confirmSignOutText: { color: '#fff', fontSize: 14, fontWeight: '600' },
});

const modal = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.6)' },
  sheet: {
    borderTopLeftRadius: radius.xl, borderTopRightRadius: radius.xl,
    padding: spacing.xl, paddingBottom: 40, overflow: 'hidden',
    borderWidth: 1, borderColor: colors.border, borderBottomWidth: 0,
  },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: spacing.xl },
  title: { ...typography.h3, color: colors.text },
  closeBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
  },
  field: { marginBottom: spacing.md },
  label: { color: colors.textSecondary, fontSize: 12, fontWeight: '600', letterSpacing: 0.5, textTransform: 'uppercase', marginBottom: spacing.sm },
  inputRow: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.md, paddingHorizontal: spacing.md,
  },
  input: { flex: 1, color: colors.text, fontSize: 15, paddingVertical: 14 },
  eyeBtn: { padding: spacing.sm },
  errorBox: {
    backgroundColor: 'rgba(255,59,48,0.12)', borderWidth: 1, borderColor: 'rgba(255,59,48,0.3)',
    borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md,
  },
  errorText: { color: colors.error, fontSize: 13 },
  successBox: { alignItems: 'center', gap: spacing.lg, paddingVertical: spacing.xxl },
  successText: { color: colors.success, fontSize: 16, fontWeight: '600' },
  saveBtn: { marginTop: spacing.md, borderRadius: radius.full, overflow: 'hidden' },
  saveBtnInner: { paddingVertical: 16, alignItems: 'center', borderRadius: radius.full },
  saveBtnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  // Session detail modal
  sessionIconWrap: {
    width: 64, height: 64, borderRadius: 32,
    backgroundColor: colors.primary + '18',
    alignItems: 'center', justifyContent: 'center',
    alignSelf: 'center', marginBottom: spacing.md,
  },
  sessionName: { ...typography.h2, color: colors.text, textAlign: 'center', marginBottom: spacing.md },
  statusBadge: {
    alignSelf: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: spacing.md,
    paddingVertical: 4,
    borderRadius: radius.full,
    marginBottom: spacing.lg,
  },
  statusBadgeCurrent: { backgroundColor: 'rgba(52,199,89,0.2)' },
  statusBadgeText: { color: colors.textSecondary, fontSize: 12, fontWeight: '500' },
  statusBadgeTextCurrent: { color: colors.success },
  infoGrid: { gap: spacing.sm, marginBottom: spacing.xl },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingHorizontal: spacing.md },
  infoLabel: { color: colors.textTertiary, fontSize: 13, width: 80 },
  infoValue: { flex: 1, color: colors.text, fontSize: 13 },
  signOutSessionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    backgroundColor: 'rgba(255,59,48,0.15)',
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
  },
  signOutSessionText: { color: colors.error, fontSize: 14, fontWeight: '600' },
});
