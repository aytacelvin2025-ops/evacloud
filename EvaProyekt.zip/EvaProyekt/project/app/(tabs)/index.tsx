import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  Dimensions,
  RefreshControl,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Upload,
  Image as ImageIcon,
  FileText,
  Film,
  Music,
  Shield,
} from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { listFiles, getFileStats, formatBytes, FileRecord, FileStats } from '@/lib/files';
import { FileUploadModal } from '@/components/FileUploadModal';
import { AppHeader } from '@/components/AppHeader';
import { useLanguage } from '@/context/LanguageContext';
import { colors, spacing, radius, typography } from '@/constants/theme';

const { width } = Dimensions.get('window');

const FILE_CATEGORIES = [
  { labelKey: 'photos', icon: ImageIcon, color: '#FF9F0A', key: 'photos' },
  { labelKey: 'videos', icon: Film, color: '#FF3B30', key: 'videos' },
  { labelKey: 'documents', icon: FileText, color: colors.primary, key: 'documents' },
  { labelKey: 'music', icon: Music, color: '#34C759', key: 'music' },
];

export default function DashboardScreen() {
  const { profile, user, refreshProfile } = useAuth();
  const { t } = useLanguage();
  const [stats, setStats] = useState<FileStats | null>(null);
  const [recentFiles, setRecentFiles] = useState<FileRecord[]>([]);
  const [showUpload, setShowUpload] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const fadeIn = useRef(new Animated.Value(0)).current;
  const slideUp = useRef(new Animated.Value(20)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;

  // Use stats.total_size (accurate from files table) when available, fallback to profile.storage_used
  const storageUsed = stats?.total_size ?? profile?.storage_used ?? 0;
  const storageLimit = profile?.storage_limit ?? 16_492_674_416_640;
  const usedPercent = Math.min((storageUsed / storageLimit) * 100, 100);

  const displayName = profile?.first_name
    || user?.user_metadata?.first_name
    || user?.email?.split('@')[0]
    || 'User';

  async function loadData() {
    if (!user) return;
    const [fileStats, recent] = await Promise.all([
      getFileStats(user.id),
      listFiles(user.id, undefined, 5),
    ]);
    setStats(fileStats);
    setRecentFiles(recent);
    setRefreshing(false);
  }

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeIn, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideUp, { toValue: 0, tension: 50, friction: 10, useNativeDriver: true }),
    ]).start();
    loadData();
  }, [user]);

  useEffect(() => {
    Animated.timing(progressAnim, {
      toValue: usedPercent / 100,
      duration: 1000,
      useNativeDriver: false,
    }).start();
  }, [storageUsed]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    refreshProfile();
    loadData();
  }, [user]);

  function handleUploaded() {
    refreshProfile();
    loadData();
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />
      <AppHeader />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
        }
      >
        <Animated.View style={{ opacity: fadeIn, transform: [{ translateY: slideUp }] }}>
          <View style={styles.greeting}>
            <Text style={styles.greetingText}>{t(new Date().getHours() < 12 ? 'good_morning' : new Date().getHours() < 17 ? 'good_afternoon' : 'good_evening')},</Text>
            <Text style={styles.userName}>{displayName} 👋</Text>
          </View>

          {/* Storage card */}
          <TouchableOpacity
            style={styles.storageCard}
            activeOpacity={0.9}
            onPress={() => setShowUpload(true)}
          >
            <LinearGradient
              colors={['rgba(30,111,255,0.15)', 'rgba(0,212,255,0.08)']}
              style={StyleSheet.absoluteFill}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            />
            <View style={styles.storageHeader}>
              <Text style={styles.storageTitle}>{t('cloud_storage') || 'Cloud Storage'}</Text>
              <View style={styles.aiStatus}>
                <View style={styles.aiDot} />
                <Text style={styles.aiStatusText}>{t('ai_protected') || 'AI Protected'}</Text>
              </View>
            </View>
            <View style={styles.storageNumbers}>
              <Text style={styles.storageUsed}>{formatBytes(storageUsed)}</Text>
              <Text style={styles.storageOf}> {t('of')} </Text>
              <Text style={styles.storageLimit}>{formatBytes(storageLimit)}</Text>
            </View>
            <View style={styles.progressTrack}>
              <Animated.View
                style={[
                  styles.progressFill,
                  {
                    width: progressAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: ['0%', '100%'],
                    }),
                  },
                ]}
              >
                <LinearGradient
                  colors={colors.gradientPrimary}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={StyleSheet.absoluteFill}
                />
              </Animated.View>
            </View>
            <View style={styles.storageMeta}>
              <Text style={styles.storageFree}>{formatBytes(storageLimit - storageUsed)} {t('available') || 'available'}</Text>
              <Text style={styles.tapUpload}>{t('tap_upload') || 'Tap to upload'}</Text>
            </View>

            {/* Category breakdown grid */}
            {stats && (
              <View style={styles.categoryGrid}>
                {FILE_CATEGORIES.map(cat => {
                  const catStats = stats.by_category[cat.key] ?? { count: 0, size: 0 };
                  const Icon = cat.icon;
                  return (
                    <View key={cat.key} style={styles.categoryCell}>
                      <Icon size={16} color={cat.color} strokeWidth={1.8} />
                      <Text style={styles.cellCount}>{catStats.count}</Text>
                      <Text style={styles.cellLabel}>{t(cat.labelKey)}</Text>
                      <Text style={[styles.cellSize, { color: cat.color }]}>{formatBytes(catStats.size)}</Text>
                    </View>
                  );
                })}
              </View>
            )}
          </TouchableOpacity>

          {/* Upload CTA */}
          <TouchableOpacity
            style={styles.uploadCta}
            onPress={() => setShowUpload(true)}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={colors.gradientPrimary}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.uploadCtaInner}
            >
              <Upload size={18} color={colors.text} strokeWidth={2} />
              <Text style={styles.uploadCtaText}>Upload from Gallery or Device</Text>
            </LinearGradient>
          </TouchableOpacity>

          <Text style={styles.sectionTitle}>{t('storage')}</Text>
          <View style={styles.categories}>
            {FILE_CATEGORIES.map((ft) => {
              const Icon = ft.icon;
              const catStats = stats?.by_category[ft.key] ?? { count: 0, size: 0 };
              return (
                <View key={ft.key} style={styles.categoryCard}>
                  <View style={[styles.categoryIcon, { backgroundColor: ft.color + '18' }]}>
                    <Icon size={22} color={ft.color} strokeWidth={1.8} />
                  </View>
                  <View style={styles.categoryInfo}>
                    <Text style={styles.catLabel}>{t(ft.labelKey)}</Text>
                    <Text style={styles.catCount}>{catStats.count} {t(catStats.count !== 1 ? 'files' : 'file')}</Text>
                  </View>
                  <Text style={styles.catSize}>{formatBytes(catStats.size)}</Text>
                </View>
              );
            })}
          </View>

          {/* Recent files */}
          {recentFiles.length > 0 && (
            <>
              <Text style={styles.sectionTitle}>{t('recent_uploads')}</Text>
              <View style={styles.recentList}>
                {recentFiles.map(file => {
                  const isImg = file.mime_type.startsWith('image/');
                  return (
                    <View key={file.id} style={styles.recentItem}>
                      <View style={[styles.recentThumb, { backgroundColor: '#1E6FFF18' }]}>
                        {isImg && file.storage_url ? (
                          <Image
                            source={{ uri: file.storage_url }}
                            style={styles.recentImg}
                            resizeMode="cover"
                          />
                        ) : (
                          <FileText size={18} color={colors.primary} strokeWidth={1.8} />
                        )}
                      </View>
                      <View style={styles.recentInfo}>
                        <Text style={styles.recentName} numberOfLines={1}>{file.name}</Text>
                        <Text style={styles.recentMeta}>{formatBytes(file.size)} · {new Date(file.created_at).toLocaleDateString()}</Text>
                      </View>
                    </View>
                  );
                })}
              </View>
            </>
          )}

          {/* Security */}
          <View style={styles.securityBanner}>
            <LinearGradient
              colors={['rgba(52,199,89,0.15)', 'rgba(52,199,89,0.05)']}
              style={StyleSheet.absoluteFill}
            />
            <Shield size={20} color={colors.success} strokeWidth={1.5} />
            <View style={styles.secText}>
              <Text style={styles.secTitle}>All Files Encrypted</Text>
              <Text style={styles.secSub}>AES-256 · Zero-knowledge architecture</Text>
            </View>
            <View style={styles.secBadge}>
              <Text style={styles.secBadgeText}>AES-256</Text>
            </View>
          </View>

          {/* Total count */}
          {stats && stats.total_count > 0 && (
            <View style={styles.totalRow}>
              <Text style={styles.totalText}>
                {stats.total_count} total file{stats.total_count !== 1 ? 's' : ''} stored securely
              </Text>
            </View>
          )}
        </Animated.View>
      </ScrollView>

      <FileUploadModal
        visible={showUpload}
        onClose={() => setShowUpload(false)}
        onUploaded={handleUploaded}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: 100 },
  greeting: { marginBottom: spacing.xl },
  greetingText: { color: colors.textSecondary, fontSize: 14 },
  userName: { ...typography.h1, color: colors.text },
  storageCard: {
    borderRadius: radius.xl,
    padding: spacing.xl,
    borderWidth: 1,
    borderColor: 'rgba(30,111,255,0.25)',
    overflow: 'hidden',
    marginBottom: spacing.md,
  },
  storageHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: spacing.sm },
  storageTitle: { color: colors.textSecondary, fontSize: 14, fontWeight: '500' },
  aiStatus: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  aiDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.success },
  aiStatusText: { color: colors.success, fontSize: 11, fontWeight: '600' },
  storageNumbers: { flexDirection: 'row', alignItems: 'baseline', marginBottom: spacing.md },
  storageUsed: { color: colors.text, fontSize: 32, fontWeight: '700' },
  storageOf: { color: colors.textSecondary, fontSize: 16 },
  storageLimit: { color: colors.textSecondary, fontSize: 16 },
  progressTrack: {
    height: 6,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: spacing.sm,
  },
  progressFill: { height: '100%', borderRadius: 3, overflow: 'hidden' },
  storageMeta: { flexDirection: 'row', justifyContent: 'space-between' },
  storageFree: { color: colors.textTertiary, fontSize: 12 },
  tapUpload: { color: colors.secondary, fontSize: 12, fontWeight: '500' },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.lg },
  categoryCell: {
    flex: 1, minWidth: '22%', backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: radius.md, padding: spacing.sm, alignItems: 'center', gap: 2,
  },
  cellCount: { color: colors.text, fontSize: 14, fontWeight: '700' },
  cellLabel: { color: colors.textTertiary, fontSize: 10 },
  cellSize: { fontSize: 10, fontWeight: '500' },
  uploadCta: { borderRadius: radius.full, overflow: 'hidden', marginBottom: spacing.xl },
  uploadCtaInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: 14,
    borderRadius: radius.full,
  },
  uploadCtaText: { ...typography.button, color: colors.text, fontSize: 14 },
  sectionTitle: { color: colors.text, fontSize: 16, fontWeight: '600', marginBottom: spacing.md },
  categories: { gap: spacing.sm, marginBottom: spacing.xl },
  categoryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  categoryIcon: { width: 42, height: 42, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
  categoryInfo: { flex: 1 },
  catLabel: { color: colors.text, fontSize: 14, fontWeight: '500' },
  catCount: { color: colors.textSecondary, fontSize: 12, marginTop: 2 },
  catSize: { color: colors.textTertiary, fontSize: 13, fontWeight: '500' },
  recentList: { gap: spacing.sm, marginBottom: spacing.xl },
  recentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  recentThumb: { width: 40, height: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  recentImg: { width: 40, height: 40 },
  recentInfo: { flex: 1 },
  recentName: { color: colors.text, fontSize: 13, fontWeight: '500' },
  recentMeta: { color: colors.textSecondary, fontSize: 11, marginTop: 2 },
  securityBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.lg,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: 'rgba(52,199,89,0.2)',
    overflow: 'hidden',
    marginBottom: spacing.lg,
  },
  secText: { flex: 1 },
  secTitle: { color: colors.text, fontSize: 13, fontWeight: '600' },
  secSub: { color: colors.textSecondary, fontSize: 11, marginTop: 2 },
  secBadge: {
    backgroundColor: 'rgba(52,199,89,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  secBadgeText: { color: colors.success, fontSize: 10, fontWeight: '700' },
  totalRow: { alignItems: 'center' },
  totalText: { color: colors.textTertiary, fontSize: 12 },
});
