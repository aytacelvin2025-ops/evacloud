import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  Dimensions,
  RefreshControl,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Film,
  Music,
  Image as ImageIcon,
  FileText,
  Play,
  ChevronRight,
  Clock,
  HardDrive,
} from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import { listFiles, formatBytes, formatDuration, FileRecord } from '@/lib/files';
import { AppHeader } from '@/components/AppHeader';
import { VideoPlayer } from '@/components/VideoPlayer';
import { MusicPlayerFull } from '@/components/MusicPlayerFull';
import { GalleryViewer } from '@/components/GalleryViewer';
import { DocumentViewerFull } from '@/components/DocumentViewerFull';
import { colors, spacing, radius, typography } from '@/constants/theme';

const { width } = Dimensions.get('window');

type SubSection = 'video' | 'music' | 'gallery' | 'documents' | null;

const SECTIONS = [
  { key: 'video', labelKey: 'video_player', subKey: 'video_player_sub', icon: Film, color: '#FF3B30', category: 'videos' },
  { key: 'music', labelKey: 'music_player', subKey: 'music_player_sub', icon: Music, color: '#34C759', category: 'music' },
  { key: 'gallery', labelKey: 'gallery', subKey: 'gallery_sub', icon: ImageIcon, color: '#FF9F0A', category: 'photos' },
  { key: 'documents', labelKey: 'document_viewer', subKey: 'document_viewer_sub', icon: FileText, color: colors.primary, category: 'documents' },
] as const;

export default function PlayersScreen() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [activeSection, setActiveSection] = useState<SubSection>(null);
  const [files, setFiles] = useState<FileRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fadeIn = useRef(new Animated.Value(0)).current;
  const slideUp = useRef(new Animated.Value(20)).current;

  async function loadData() {
    if (!user) return;
    const allFiles = await listFiles(user.id);
    setFiles(allFiles);
    setLoading(false);
    setRefreshing(false);
  }

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeIn, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideUp, { toValue: 0, tension: 50, friction: 10, useNativeDriver: true }),
    ]).start();
    loadData();
  }, [user]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadData();
  }, [user]);

  function getFilesByCategory(category: string): FileRecord[] {
    if (category === 'documents') {
      return files.filter(f => f.category === 'documents' || f.category === 'other');
    }
    return files.filter(f => f.category === category);
  }

  // Render active sub-section full screen
  if (activeSection === 'video') {
    const videoFiles = getFilesByCategory('videos');
    return <VideoPlayer files={videoFiles} onBack={() => setActiveSection(null)} />;
  }
  if (activeSection === 'music') {
    const musicFiles = getFilesByCategory('music');
    return <MusicPlayerFull files={musicFiles} onBack={() => setActiveSection(null)} />;
  }
  if (activeSection === 'gallery') {
    const photoFiles = getFilesByCategory('photos');
    return <GalleryViewer files={photoFiles} onBack={() => setActiveSection(null)} />;
  }
  if (activeSection === 'documents') {
    const docFiles = getFilesByCategory('documents');
    return <DocumentViewerFull files={docFiles} onBack={() => setActiveSection(null)} />;
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />
      <AppHeader title={t('players')} />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
        }
      >
        <Animated.View style={{ opacity: fadeIn, transform: [{ translateY: slideUp }] }}>
          {/* Hero banner */}
          <View style={styles.heroBanner}>
            <LinearGradient
              colors={['rgba(30,111,255,0.18)', 'rgba(0,212,255,0.06)']}
              style={StyleSheet.absoluteFill}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            />
            <View style={styles.heroIconWrap}>
              <LinearGradient colors={['#1E6FFF', '#00D4FF']} style={StyleSheet.absoluteFill} />
              <Play size={28} color="#fff" strokeWidth={2} fill="#fff" />
            </View>
            <View style={styles.heroText}>
              <Text style={styles.heroTitle}>{t('players')}</Text>
              <Text style={styles.heroSub}>{t('players_sub')}</Text>
            </View>
          </View>

          {/* Section cards */}
          <View style={styles.sectionsGrid}>
            {SECTIONS.map((section, i) => {
              const sectionFiles = getFilesByCategory(section.category);
              const count = sectionFiles.length;
              const totalSize = sectionFiles.reduce((sum, f) => sum + f.size, 0);
              const Icon = section.icon;
              return (
                <AnimatedSectionCard
                  key={section.key}
                  delay={i * 80}
                  icon={Icon}
                  color={section.color}
                  title={t(section.labelKey)}
                  subtitle={t(section.subKey)}
                  count={count}
                  totalSize={formatBytes(totalSize)}
                  onPress={() => setActiveSection(section.key as SubSection)}
                />
              );
            })}
          </View>

          {/* Recent media */}
          {!loading && files.length > 0 && (
            <>
              <Text style={styles.sectionTitle}>{t('recent_uploads')}</Text>
              <View style={styles.recentList}>
                {files.slice(0, 6).map(file => {
                  const section = SECTIONS.find(s => s.category === file.category);
                  const Icon = section?.icon ?? FileText;
                  const color = section?.color ?? colors.primary;
                  return (
                    <TouchableOpacity
                      key={file.id}
                      style={styles.recentItem}
                      onPress={() => {
                        const cat = file.category;
                        if (cat === 'videos') setActiveSection('video');
                        else if (cat === 'music') setActiveSection('music');
                        else if (cat === 'photos') setActiveSection('gallery');
                        else setActiveSection('documents');
                      }}
                      activeOpacity={0.7}
                    >
                      <View style={[styles.recentIcon, { backgroundColor: color + '18' }]}>
                        <Icon size={18} color={color} strokeWidth={1.8} />
                      </View>
                      <View style={styles.recentInfo}>
                        <Text style={styles.recentName} numberOfLines={1}>{file.name}</Text>
                        <Text style={styles.recentMeta}>
                          {formatBytes(file.size)}
                          {file.duration_seconds ? ` · ${formatDuration(file.duration_seconds)}` : ''}
                        </Text>
                      </View>
                      <ChevronRight size={16} color={colors.textTertiary} strokeWidth={2} />
                    </TouchableOpacity>
                  );
                })}
              </View>
            </>
          )}

          {loading && (
            <View style={styles.loadingWrap}>
              <ActivityIndicator size="large" color={colors.primary} />
            </View>
          )}

          {!loading && files.length === 0 && (
            <View style={styles.emptyWrap}>
              <HardDrive size={48} color={colors.textTertiary} strokeWidth={1.5} />
              <Text style={styles.emptyTitle}>{t('players_empty')}</Text>
              <Text style={styles.emptySub}>{t('players_empty_sub')}</Text>
            </View>
          )}
        </Animated.View>
      </ScrollView>
    </View>
  );
}

function AnimatedSectionCard({
  delay,
  icon: Icon,
  color,
  title,
  subtitle,
  count,
  totalSize,
  onPress,
}: {
  delay: number;
  icon: typeof Film;
  color: string;
  title: string;
  subtitle: string;
  count: number;
  totalSize: string;
  onPress: () => void;
}) {
  const scaleAnim = useRef(new Animated.Value(0.9)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.delay(delay),
      Animated.parallel([
        Animated.spring(scaleAnim, { toValue: 1, tension: 80, friction: 8, useNativeDriver: true }),
        Animated.timing(opacityAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      ]),
    ]).start();
  }, []);

  return (
    <Animated.View style={{ opacity: opacityAnim, transform: [{ scale: scaleAnim }] }}>
      <TouchableOpacity
        style={styles.sectionCard}
        onPress={onPress}
        activeOpacity={0.85}
      >
        <LinearGradient
          colors={[color + '15', 'transparent']}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
        <View style={styles.sectionTop}>
          <View style={[styles.sectionIcon, { backgroundColor: color + '20' }]}>
            <Icon size={26} color={color} strokeWidth={1.8} />
          </View>
          <View style={styles.sectionBadge}>
            <Text style={[styles.sectionBadgeText, { color }]}>{count}</Text>
          </View>
        </View>
        <Text style={styles.sectionTitle2}>{title}</Text>
        <Text style={styles.sectionSub} numberOfLines={1}>{subtitle}</Text>
        <View style={styles.sectionBottom}>
          <View style={styles.sectionMetaRow}>
            <HardDrive size={12} color={colors.textTertiary} strokeWidth={1.8} />
            <Text style={styles.sectionMetaText}>{totalSize}</Text>
          </View>
          <View style={[styles.sectionArrow, { backgroundColor: color + '20' }]}>
            <ChevronRight size={16} color={color} strokeWidth={2} />
          </View>
        </View>
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: 100 },
  heroBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.lg,
    padding: spacing.xl,
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: 'rgba(30,111,255,0.25)',
    overflow: 'hidden',
    marginBottom: spacing.xl,
  },
  heroIconWrap: {
    width: 56,
    height: 56,
    borderRadius: 18,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroText: { flex: 1 },
  heroTitle: { ...typography.h2, color: colors.text },
  heroSub: { color: colors.textSecondary, fontSize: 13, marginTop: 4 },
  sectionsGrid: { gap: spacing.md, marginBottom: spacing.xl },
  sectionCard: {
    borderRadius: radius.xl,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: 'hidden',
  },
  sectionTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  sectionIcon: {
    width: 52,
    height: 52,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: radius.full,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  sectionBadgeText: { fontSize: 14, fontWeight: '700' },
  sectionTitle2: { color: colors.text, fontSize: 18, fontWeight: '700' },
  sectionSub: { color: colors.textSecondary, fontSize: 13, marginTop: 2, marginBottom: spacing.md },
  sectionBottom: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  sectionMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  sectionMetaText: { color: colors.textTertiary, fontSize: 12 },
  sectionArrow: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionTitle: { color: colors.text, fontSize: 16, fontWeight: '600', marginBottom: spacing.md },
  recentList: { gap: spacing.sm, marginBottom: spacing.xl },
  recentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  recentIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  recentInfo: { flex: 1 },
  recentName: { color: colors.text, fontSize: 13, fontWeight: '500' },
  recentMeta: { color: colors.textSecondary, fontSize: 11, marginTop: 2 },
  loadingWrap: { paddingVertical: spacing.xxl, alignItems: 'center' },
  emptyWrap: { alignItems: 'center', paddingVertical: spacing.xxl, gap: spacing.sm },
  emptyTitle: { color: colors.text, fontSize: 16, fontWeight: '600' },
  emptySub: { color: colors.textSecondary, fontSize: 13, textAlign: 'center' },
});
