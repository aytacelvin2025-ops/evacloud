import React from 'react';
import { View } from 'react-native';
import { Tabs } from 'expo-router';
import { DrawerProvider } from '@/context/DrawerContext';
import { SideDrawer } from '@/components/SideDrawer';

export default function TabLayout() {
  return (
    <DrawerProvider>
      <View style={{ flex: 1 }}>
        <Tabs
          screenOptions={{
            headerShown: false,
            tabBarStyle: { display: 'none' },
          }}
        >
          <Tabs.Screen name="index" />
          <Tabs.Screen name="storage" />
          <Tabs.Screen name="players" />
          <Tabs.Screen name="security" />
          <Tabs.Screen name="profile" />
          <Tabs.Screen name="trash" />
        </Tabs>
        <SideDrawer />
      </View>
    </DrawerProvider>
  );
}
