import React, { useState, useCallback, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Dimensions,
  Image,
  Alert,
  RefreshControl,
  ActivityIndicator,
  Share,
  Platform,
  Modal,
  TextInput,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Upload, Folder, Image as Img, Film, FileText, Music,
  HardDrive, Trash2, ChevronDown, CheckCircle, X,
  Download, Share2, Grid, Search, Wifi, Signal, Heart,
  SortDesc, MoreVertical, Star,
} from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import {
  listFiles, deleteFile, getFileStats, formatBytes, formatDuration,
  toggleFavorite, sortFiles, FileRecord, FileStats, SortOption,
} from '@/lib/files';
import { FileUploadModal } from '@/components/FileUploadModal';
import { MediaViewer } from '@/components/MediaViewer';
import { AppHeader } from '@/components/AppHeader';
import { useLanguage } from '@/context/LanguageContext';
import { downloadFileModern, downloadMultipleFiles, DownloadProgress } from '@/lib/download';
import { colors, spacing, radius, typography } from '@/constants/theme';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const GRID_GAP = 2;

const CATEGORIES = [
  { key: 'all', nameKey: 'all_files', icon: Folder, color: '#A066FF' },
  { key: 'photos', nameKey: 'photos', icon: Img, color: '#FF9F0A' },
  { key: 'videos', nameKey: 'videos', icon: Film, color: '#FF3B30' },
  { key: 'documents', nameKey: 'documents', icon: FileText, color: colors.primary },
  { key: 'music', nameKey: 'music', icon: Music, color: '#34C759' },
  { key: 'other', nameKey: 'other', icon: Folder, color: '#6B7280' },
  { key: 'favorites', nameKey: 'favorites', icon: Heart, color: '#FF2D55' },
] as const;

const SORT_OPTIONS: { key: SortOption; label: string; labelAz: string }[] = [
  { key: 'newest', label: 'Newest', labelAz: 'Ən yeni' },
  { key: 'oldest', label: 'Oldest', labelAz: 'Ən köhnə' },
  { key: 'name_asc', label: 'A → Z', labelAz: 'A → Z' },
  { key: 'name_desc', label: 'Z → A', labelAz: 'Z → A' },
  { key: 'size_desc', label: 'Largest', labelAz: 'Ən böyük' },
  { key: 'size_asc', label: 'Smallest', labelAz: 'Ən kiçik' },
];

const GRID_COLS_OPTIONS = [3, 4, 5, 6];

// Lightweight VideoThumbnail — single frame extraction, no black-frame detection
function VideoThumbnail({ uri, size }: { uri: string; size: number }) {
  const [thumbnail, setThumbnail] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (Platform.OS !== 'web' || !uri) return;

    let cancelled = false;
    const video = document.createElement('video');
    video.crossOrigin = 'anonymous';
    video.muted = true;
    video.preload = 'metadata';
    video.playsInline = true;

    video.onloadedmetadata = () => {
      if (cancelled) return;
      // Seek to 1 second for a representative frame
      video.currentTime = 1;
    };

    video.onseeked = () => {
      if (cancelled) return;
      try {
        const canvas = document.createElement('canvas');
        canvas.width = Math.min(size, 200);
        canvas.height = Math.min(size, 200);
        const ctx = canvas.getContext('2d');
        if (!ctx) { setFailed(true); return; }
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.6);
        if (!cancelled) setThumbnail(dataUrl);
      } catch {
        if (!cancelled) setFailed(true);
      }
    };

    video.onerror = () => { if (!cancelled) setFailed(true); };
    video.src = uri;

    // Timeout: if no thumbnail after 3s, show fallback
    const timeout = setTimeout(() => {
      if (!cancelled && !thumbnail) setFailed(true);
    }, 3000);

    return () => {
      cancelled = true;
      clearTimeout(timeout);
      video.src = '';
    };
  }, [uri, size]);

  if (thumbnail) {
    return (
      <Image source={{ uri: thumbnail }} style={{ width: size, height: size }} resizeMode="cover" />
    );
  }

  return (
    <View style={{ width: size, height: size, backgroundColor: '#FF3B3022', alignItems: 'center', justifyContent: 'center' }}>
      <Film size={size * 0.35} color="#FF3B30" strokeWidth={1.5} />
      {!failed && <ActivityIndicator size="small" color="#FF3B3088" style={{ position: 'absolute', bottom: 4, right: 4 }} />}
    </View>
  );
}

function FileThumbnail({ file, size }: { file: FileRecord; size: number }) {
  const isImage = file.mime_type.startsWith('image/');
  const isVideo = file.mime_type.startsWith('video/');
  const Icon = CAT_ICON_MAP[file.category] ?? Folder;
  const color = CAT_COLOR_MAP[file.category] ?? '#6B7280';

  if (isImage && file.storage_url) {
    return <Image source={{ uri: file.storage_url }} style={{ width: size, height: size }} resizeMode="cover" />;
  }

  if (isVideo && file.storage_url) {
    if (Platform.OS === 'web') {
      return <VideoThumbnail uri={file.storage_url} size={size} />;
    }
    return (
      <View style={{ width: size, height: size, backgroundColor: '#FF3B3022', alignItems: 'center', justifyContent: 'center' }}>
        <Film size={size * 0.35} color="#FF3B30" strokeWidth={1.5} />
        {file.duration_seconds && (
          <View style={{ position: 'absolute', bottom: 4, right: 4, backgroundColor: 'rgba(0,0,0,0.7)', paddingHorizontal: 4, paddingVertical: 2, borderRadius: 2 }}>
            <Text style={{ color: '#fff', fontSize: 9, fontWeight: '600' }}>{formatDuration(file.duration_seconds)}</Text>
          </View>
        )}
      </View>
    );
  }

  return (
    <View style={{ width: size, height: size, backgroundColor: color + '18', alignItems: 'center', justifyContent: 'center' }}>
      <Icon size={size * 0.35} color={color} strokeWidth={1.5} />
    </View>
  );
}

const CAT_ICON_MAP: Record<string, typeof Img> = {
  photos: Img, videos: Film, documents: FileText, music: Music, other: Folder,
};
const CAT_COLOR_MAP: Record<string, string> = {
  photos: '#FF9F0A', videos: '#FF3B30', documents: colors.primary, music: '#34C759', other: '#6B7280',
};

export default function StorageScreen() {
  const { user, profile, refreshProfile } = useAuth();
  const { t } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [files, setFiles] = useState<FileRecord[]>([]);
  const [stats, setStats] = useState<FileStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showUpload, setShowUpload] = useState(false);
  const [viewerIndex, setViewerIndex] = useState<number | null>(null);
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [gridCols, setGridCols] = useState(3);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [fileToDelete, setFileToDelete] = useState<FileRecord | null>(null);
  const [wifiOnly, setWifiOnly] = useState(true);
  const [showWifiSettings, setShowWifiSettings] = useState(false);
  const [showBulkDelete, setShowBulkDelete] = useState(false);
  const [showSort, setShowSort] = useState(false);
  const [sortOption, setSortOption] = useState<SortOption>('newest');
  const [contextFile, setContextFile] = useState<FileRecord | null>(null);
  const [showContextMenu, setShowContextMenu] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<{ name: string; percent: number } | null>(null);
  const [downloadToast, setDownloadToast] = useState<string | null>(null);
  const searchInputRef = useRef<TextInput>(null);

  // Use stats.total_size when available (accurate), fallback to profile.storage_used
  const storageUsed = stats?.total_size ?? profile?.storage_used ?? 0;
  const storageLimit = profile?.storage_limit ?? 16_492_674_416_640;
  const usedPercent = Math.min((storageUsed / storageLimit) * 100, 100);
  const cellSize = (SCREEN_WIDTH - spacing.xl * 2 - GRID_GAP * (gridCols - 1)) / gridCols;

  useEffect(() => {
    // @ts-ignore
    if (typeof globalThis !== 'undefined' && globalThis.__pendingCategory) {
      // @ts-ignore
      const cat = globalThis.__pendingCategory;
      // @ts-ignore
      delete globalThis.__pendingCategory;
      if (cat) setActiveCategory(cat);
    }
  }, []);

  function computeStatsFromFiles(fileList: FileRecord[]) {
    const cats = ['photos', 'videos', 'music', 'documents', 'other'] as const;
    const by_category: Record<string, { count: number; size: number }> = {};
    for (const c of cats) by_category[c] = { count: 0, size: 0 };
    let totalSize = 0;
    for (const f of fileList) {
      const cat = f.category ?? 'other';
      if (!by_category[cat]) by_category[cat] = { count: 0, size: 0 };
      by_category[cat].count++;
      by_category[cat].size += f.size ?? 0;
      totalSize += f.size ?? 0;
    }
    return { total_count: fileList.length, total_size: totalSize, by_category };
  }

  async function loadData() {
    if (!user) return;
    setLoading(true);
    try {
      const fileList = await listFiles(user.id, activeCategory === 'all' || activeCategory === 'favorites' ? undefined : activeCategory);
      let filtered = fileList;
      if (activeCategory === 'favorites') {
        filtered = fileList.filter(f => f.is_favorited);
      }
      setFiles(sortFiles(filtered, sortOption));
      setStats(computeStatsFromFiles(fileList));
    } catch (e) {
      console.error('Load error:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => { loadData(); }, [user, activeCategory]);

  useEffect(() => {
    setFiles(prev => sortFiles(prev, sortOption));
  }, [sortOption]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    refreshProfile();
    loadData();
  }, [activeCategory, user]);

  function handleUploaded() { refreshProfile(); loadData(); }

  function exitSelectMode() { setSelectMode(false); setSelected(new Set()); }

  function toggleSelect(id: string) {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  async function bulkDeleteFromModal() {
    setShowBulkDelete(false);
    for (const file of files.filter(f => selected.has(f.id))) {
      await deleteFile(file);
    }
    setFiles(prev => prev.filter(f => !selected.has(f.id)));
    refreshProfile();
    exitSelectMode();
  }

  function handleBulkDelete() {
    if (selected.size === 0) return;
    setShowBulkDelete(true);
  }

  async function handleBulkShare() {
    const urls = files.filter(f => selected.has(f.id) && f.storage_url).map(f => f.storage_url!);
    if (!urls.length) return;
    try {
      await Share.share({ message: urls.join('\n'), title: 'EVA Cloud X' });
    } catch {}
  }

  async function downloadFile(file: FileRecord) {
    if (!file.storage_url) return;
    setDownloadProgress({ name: file.name, percent: 0 });
    const result = await downloadFileModern(file, (p) => {
      setDownloadProgress({ name: file.name, percent: Math.round(p.percent) });
    });
    setDownloadProgress(null);
    if (result.success) {
      setDownloadToast(`✓ ${file.name} endirildi`);
    } else {
      setDownloadToast(`✕ ${result.error ?? 'Endirmə xətası'}`);
    }
    setTimeout(() => setDownloadToast(null), 3000);
  }

  async function handleBulkDownload() {
    const selectedFiles = files.filter(f => selected.has(f.id));
    if (selectedFiles.length === 0) return;
    setDownloadProgress({ name: `${selectedFiles.length} fayl endirilir...`, percent: 0 });
    const result = await downloadMultipleFiles(
      selectedFiles,
      (file, p) => setDownloadProgress({ name: file.name, percent: Math.round(p.percent) }),
    );
    setDownloadProgress(null);
    setDownloadToast(`✓ ${result.succeeded} fayl endirildi${result.failed > 0 ? `, ${result.failed} xəta` : ''}`);
    setTimeout(() => setDownloadToast(null), 3000);
  }

  async function handleToggleFavorite(file: FileRecord) {
    const success = await toggleFavorite(file.id, file.is_favorited ?? false);
    if (success) {
      setFiles(prev => prev.map(f => f.id === file.id ? { ...f, is_favorited: !f.is_favorited } : f));
    }
    setShowContextMenu(false);
    setContextFile(null);
  }

  function confirmDelete(file: FileRecord) {
    setFileToDelete(file);
    setShowDeleteConfirm(true);
    setShowContextMenu(false);
    setContextFile(null);
  }

  async function executeDelete() {
    if (!fileToDelete) return;
    setShowDeleteConfirm(false);
    const result = await deleteFile(fileToDelete);
    if (result.success) {
      setFiles(prev => prev.filter(f => f.id !== fileToDelete.id));
      setSelected(prev => { const n = new Set(prev); n.delete(fileToDelete.id); return n; });
      refreshProfile();
    } else {
      if (Platform.OS === 'web') alert(result.error ?? 'Delete failed');
      else Alert.alert('Error', result.error ?? 'Delete failed');
    }
    setFileToDelete(null);
  }

  function openContextMenu(file: FileRecord) {
    setContextFile(file);
    setShowContextMenu(true);
  }

  const displayedFiles = files.filter(f =>
    searchQuery === '' || f.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const isGridView = activeCategory === 'photos' || activeCategory === 'videos' || activeCategory === 'all' || activeCategory === 'favorites';

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />
      <AppHeader
        title={t('storage')}
        rightContent={
          <View style={{ flexDirection: 'row', gap: 6 }}>
            {!selectMode && !showSearch && (
              <>
                <TouchableOpacity style={styles.iconBtn} onPress={() => setShowSort(true)}>
                  <SortDesc size={18} color={colors.textSecondary} strokeWidth={1.8} />
                </TouchableOpacity>
                <TouchableOpacity style={styles.iconBtn} onPress={() => setShowSearch(true)}>
                  <Search size={18} color={colors.textSecondary} strokeWidth={1.8} />
                </TouchableOpacity>
                {files.length > 0 && (
                  <TouchableOpacity style={styles.selectBtn} onPress={() => setSelectMode(true)}>
                    <Grid size={16} color={colors.textSecondary} strokeWidth={1.8} />
                    <Text style={styles.selectBtnText}>{t('select')}</Text>
                  </TouchableOpacity>
                )}
              </>
            )}
          </View>
        }
      />

      {/* Search Bar */}
      {showSearch && (
        <View style={styles.searchBar}>
          <Search size={18} color={colors.textTertiary} strokeWidth={1.8} />
          <TextInput
            ref={searchInputRef}
            style={styles.searchInput}
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder={t('find_files') || 'Search files...'}
            placeholderTextColor={colors.textTertiary}
            autoFocus
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')} style={styles.clearSearchBtn}>
              <X size={16} color={colors.textTertiary} strokeWidth={2} />
            </TouchableOpacity>
          )}
          <TouchableOpacity onPress={() => { setShowSearch(false); setSearchQuery(''); }} style={styles.searchCancelBtn}>
            <Text style={styles.searchCancelText}>{t('cancel')}</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Sort Modal */}
      <Modal visible={showSort} transparent animationType="fade" onRequestClose={() => setShowSort(false)}>
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setShowSort(false)}>
          <View style={styles.sortModal}>
            <Text style={styles.sortTitle}>Sıralama</Text>
            {SORT_OPTIONS.map(opt => (
              <TouchableOpacity
                key={opt.key}
                style={[styles.sortOption, sortOption === opt.key && styles.sortOptionActive]}
                onPress={() => { setSortOption(opt.key); setShowSort(false); }}
              >
                <Text style={[styles.sortOptionText, sortOption === opt.key && { color: colors.primary }]}>
                  {opt.labelAz}
                </Text>
                {sortOption === opt.key && <CheckCircle size={16} color={colors.primary} strokeWidth={2} />}
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
      </Modal>

      {/* WiFi Settings Modal */}
      <Modal visible={showWifiSettings} transparent animationType="fade" onRequestClose={() => setShowWifiSettings(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>{t('upload_settings') || 'Yükləmə Parametrləri'}</Text>
            <TouchableOpacity
              style={[styles.wifiOption, wifiOnly && styles.wifiOptionActive]}
              onPress={() => setWifiOnly(true)}
            >
              <Wifi size={20} color={wifiOnly ? colors.primary : colors.textTertiary} strokeWidth={1.8} />
              <View style={styles.wifiOptionText}>
                <Text style={[styles.wifiOptionTitle, wifiOnly && { color: colors.primary }]}>
                  {t('wifi_only') || 'Yalnız Wi-Fi'}
                </Text>
                <Text style={styles.wifiOptionSub}>Wi-Fi bağlantısı olduqda yüklə</Text>
              </View>
              {wifiOnly && <CheckCircle size={20} color={colors.primary} strokeWidth={2} />}
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.wifiOption, !wifiOnly && styles.wifiOptionActive]}
              onPress={() => setWifiOnly(false)}
            >
              <Signal size={20} color={!wifiOnly ? colors.primary : colors.textTertiary} strokeWidth={1.8} />
              <View style={styles.wifiOptionText}>
                <Text style={[styles.wifiOptionTitle, !wifiOnly && { color: colors.primary }]}>
                  {t('any_network') || 'İstənilən Şəbəkə'}
                </Text>
                <Text style={styles.wifiOptionSub}>Wi-Fi və ya mobil internet</Text>
              </View>
              {!wifiOnly && <CheckCircle size={20} color={colors.primary} strokeWidth={2} />}
            </TouchableOpacity>
            <TouchableOpacity style={styles.modalCloseBtn} onPress={() => setShowWifiSettings(false)}>
              <Text style={styles.modalCloseText}>{t('save') || 'Saxla'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Context Menu (long press on grid item) */}
      <Modal visible={showContextMenu} transparent animationType="fade" onRequestClose={() => setShowContextMenu(false)}>
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setShowContextMenu(false)}>
          <View style={styles.contextMenu}>
            {contextFile && (
              <Text style={styles.contextFileName} numberOfLines={1}>{contextFile.name}</Text>
            )}
            <TouchableOpacity style={styles.contextItem} onPress={() => contextFile && handleToggleFavorite(contextFile)}>
              <Heart size={18} color="#FF2D55" strokeWidth={1.8} fill={contextFile?.is_favorited ? '#FF2D55' : 'none'} />
              <Text style={styles.contextItemText}>
                {contextFile?.is_favorited ? 'Sevimlilərden Çıxart' : 'Sevimlilərə Əlavə Et'}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.contextItem} onPress={() => contextFile && downloadFile(contextFile)}>
              <Download size={18} color={colors.secondary} strokeWidth={1.8} />
              <Text style={styles.contextItemText}>Yüklə (Endir)</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.contextItem} onPress={() => contextFile && confirmDelete(contextFile)}>
              <Trash2 size={18} color={colors.error} strokeWidth={1.8} />
              <Text style={[styles.contextItemText, { color: colors.error }]}>Zibilə At</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal visible={showDeleteConfirm} transparent animationType="fade" onRequestClose={() => setShowDeleteConfirm(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.deleteModalContent}>
            <View style={styles.deleteIconWrap}>
              <Trash2 size={32} color={colors.error} strokeWidth={1.8} />
            </View>
            <Text style={styles.deleteModalTitle}>{t('move_to_trash') || 'Zibilə At'}</Text>
            <Text style={styles.deleteModalDesc}>
              {fileToDelete ? `"${fileToDelete.name}" zibil qutusuna atılsın?` : ''}
            </Text>
            <Text style={styles.deleteModalNote}>Zibil qutusundan bərpa edə bilərsiniz.</Text>
            <View style={styles.deleteModalActions}>
              <TouchableOpacity style={styles.deleteCancelBtn} onPress={() => { setShowDeleteConfirm(false); setFileToDelete(null); }}>
                <Text style={styles.deleteCancelText}>{t('cancel')}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.deleteConfirmBtn} onPress={executeDelete}>
                <Trash2 size={16} color="#fff" strokeWidth={2} />
                <Text style={styles.deleteConfirmText}>Zibilə At</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Bulk Delete Confirmation Modal */}
      <Modal visible={showBulkDelete} transparent animationType="fade" onRequestClose={() => setShowBulkDelete(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.deleteModalContent}>
            <View style={styles.deleteIconWrap}>
              <Trash2 size={32} color={colors.error} strokeWidth={1.8} />
            </View>
            <Text style={styles.deleteModalTitle}>Seçiləni Sil</Text>
            <Text style={styles.deleteModalDesc}>{selected.size} fayl zibil qutusuna atılsın?</Text>
            <Text style={styles.deleteModalNote}>Zibil qutusundan bərpa edə bilərsiniz.</Text>
            <View style={styles.deleteModalActions}>
              <TouchableOpacity style={styles.deleteCancelBtn} onPress={() => setShowBulkDelete(false)}>
                <Text style={styles.deleteCancelText}>{t('cancel')}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.deleteConfirmBtn} onPress={bulkDeleteFromModal}>
                <Trash2 size={16} color="#fff" strokeWidth={2} />
                <Text style={styles.deleteConfirmText}>Zibilə At</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
      >
        {/* Usage card */}
        <View style={styles.usageCard}>
          <LinearGradient colors={['rgba(30,111,255,0.12)', 'rgba(0,0,0,0)']} style={StyleSheet.absoluteFill} />
          <View style={styles.usageTop}>
            <HardDrive size={20} color={colors.primary} strokeWidth={1.8} />
            <Text style={styles.usageTitle}>Ümumi Yaddaş</Text>
          </View>
          <Text style={styles.usageMain}>{formatBytes(storageUsed)}</Text>
          <Text style={styles.usageSub}>{formatBytes(storageLimit)} / {usedPercent.toFixed(1)}% istifadə</Text>
          <View style={styles.usageBar}>
            <LinearGradient
              colors={usedPercent > 85 ? ['#FF3B30', '#FF6B6B'] : colors.gradientPrimary}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={[styles.usageFill, { width: `${Math.max(usedPercent, 0.5)}%` as any }]}
            />
          </View>
          {stats && (
            <View style={styles.statGrid}>
              {CATEGORIES.filter(c => c.key !== 'all' && c.key !== 'favorites').map(cat => {
                const catStats = stats.by_category[cat.key as string] ?? { count: 0, size: 0 };
                const Icon = cat.icon;
                return (
                  <View key={cat.key} style={styles.statCell}>
                    <Icon size={14} color={cat.color} strokeWidth={1.8} />
                    <Text style={styles.statCount}>{catStats.count}</Text>
                    <Text style={styles.statLabel}>{t(cat.nameKey)}</Text>
                    <Text style={[styles.statSize, { color: cat.color }]}>{formatBytes(catStats.size)}</Text>
                  </View>
                );
              })}
            </View>
          )}
        </View>

        {/* Upload + network */}
        <View style={{ gap: spacing.sm }}>
          <TouchableOpacity activeOpacity={0.85} onPress={() => setShowUpload(true)}>
            <LinearGradient colors={colors.gradientPrimary} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.uploadBtn}>
              <Upload size={20} color={colors.text} strokeWidth={2} />
              <Text style={styles.uploadBtnText}>{t('upload_files')}</Text>
            </LinearGradient>
          </TouchableOpacity>
          <TouchableOpacity style={styles.wifiSettingsBtn} onPress={() => setShowWifiSettings(true)}>
            {wifiOnly ? (
              <Wifi size={14} color={colors.textTertiary} strokeWidth={1.8} />
            ) : (
              <Signal size={14} color={colors.textTertiary} strokeWidth={1.8} />
            )}
            <Text style={styles.wifiSettingsText}>
              {wifiOnly ? 'Yalnız Wi-Fi' : 'İstənilən Şəbəkə'}
            </Text>
            <Text style={styles.wifiSettingsChange}>Dəyiş</Text>
          </TouchableOpacity>
        </View>

        {/* Category tabs */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catScroll}>
          {CATEGORIES.map(cat => {
            const Icon = cat.icon;
            const isActive = activeCategory === cat.key;
            return (
              <TouchableOpacity
                key={cat.key}
                style={[styles.catChip, isActive && { backgroundColor: cat.color + '22', borderColor: cat.color + '60' }]}
                onPress={() => { setActiveCategory(cat.key); exitSelectMode(); }}
                activeOpacity={0.75}
              >
                <Icon size={14} color={isActive ? cat.color : colors.textSecondary} strokeWidth={1.8} />
                <Text style={[styles.catChipText, isActive && { color: cat.color }]}>{t(cat.nameKey)}</Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Sort info + column selector */}
        {!loading && files.length > 0 && (
          <View style={styles.toolRow}>
            <TouchableOpacity style={styles.sortBadge} onPress={() => setShowSort(true)}>
              <SortDesc size={12} color={colors.primary} strokeWidth={2} />
              <Text style={styles.sortBadgeText}>{SORT_OPTIONS.find(o => o.key === sortOption)?.labelAz}</Text>
            </TouchableOpacity>
            <View style={styles.colSelector}>
              {GRID_COLS_OPTIONS.map(n => (
                <TouchableOpacity
                  key={n}
                  style={[styles.colBtn, gridCols === n && styles.colBtnActive]}
                  onPress={() => setGridCols(n)}
                >
                  <Text style={[styles.colBtnText, gridCols === n && styles.colBtnTextActive]}>{n}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        {/* File content */}
        {loading ? (
          <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
        ) : files.length === 0 ? (
          <View style={styles.emptyState}>
            <Upload size={48} color={colors.textTertiary} strokeWidth={1} />
            <Text style={styles.emptyTitle}>
              {activeCategory === 'favorites' ? 'Sevimlilər yoxdur' : t('no_files')}
            </Text>
            <Text style={styles.emptySub}>
              {activeCategory === 'favorites' ? 'Faylları ürək ilə sevimlilərə əlavə edin' : t('no_files_sub')}
            </Text>
          </View>
        ) : isGridView ? (
          <View>
            <Text style={styles.sectionTitle}>
              {displayedFiles.length} {t(displayedFiles.length !== 1 ? 'files' : 'file')}
            </Text>
            <View style={gridStyles.grid}>
              {displayedFiles.map((file, idx) => {
                const isSelected = selected.has(file.id);
                const isVideo = file.mime_type.startsWith('video/');
                return (
                  <TouchableWithoutFeedback
                    key={file.id}
                    onPress={() => {
                      if (selectMode) toggleSelect(file.id);
                      else setViewerIndex(idx);
                    }}
                    onLongPress={() => {
                      if (selectMode) { toggleSelect(file.id); }
                      else { openContextMenu(file); }
                    }}
                    delayLongPress={350}
                  >
                    <View style={[gridStyles.cell, { width: cellSize, height: cellSize }, isSelected && { opacity: 0.65 }]}>
                      <FileThumbnail file={file} size={cellSize} />
                      {/* Duration badge for videos */}
                      {isVideo && file.duration_seconds && (
                        <View style={gridStyles.durationBadge}>
                          <Text style={gridStyles.durationText}>{formatDuration(file.duration_seconds)}</Text>
                        </View>
                      )}
                      {/* Favorite indicator */}
                      {file.is_favorited && !selectMode && (
                        <View style={gridStyles.favBadge}>
                          <Heart size={10} color="#FF2D55" fill="#FF2D55" strokeWidth={2} />
                        </View>
                      )}
                      {/* Select checkbox */}
                      {selectMode && (
                        <View style={[gridStyles.check, isSelected && gridStyles.checkSelected]}>
                          {isSelected && <CheckCircle size={12} color="#fff" strokeWidth={3} />}
                        </View>
                      )}
                      {/* Context menu trigger (non-select mode) */}
                      {!selectMode && (
                        <TouchableOpacity
                          style={gridStyles.menuBtn}
                          onPress={() => openContextMenu(file)}
                          hitSlop={{ top: 4, bottom: 4, left: 4, right: 4 }}
                        >
                          <MoreVertical size={14} color="#fff" strokeWidth={2} />
                        </TouchableOpacity>
                      )}
                    </View>
                  </TouchableWithoutFeedback>
                );
              })}
            </View>
          </View>
        ) : (
          <View style={styles.fileList}>
            <Text style={styles.sectionTitle}>{displayedFiles.length} {t(displayedFiles.length !== 1 ? 'files' : 'file')}</Text>
            {displayedFiles.map((file, idx) => {
              const isImage = file.mime_type.startsWith('image/');
              const Icon = CAT_ICON_MAP[file.category] ?? Folder;
              const color = CAT_COLOR_MAP[file.category] ?? '#6B7280';
              const isSelected = selected.has(file.id);
              return (
                <TouchableOpacity
                  key={file.id}
                  style={[styles.fileItem, isSelected && styles.fileItemSelected]}
                  onPress={() => { if (selectMode) toggleSelect(file.id); else setViewerIndex(idx); }}
                  onLongPress={() => { setSelectMode(true); setSelected(new Set([file.id])); }}
                  activeOpacity={0.75}
                >
                  <View style={[styles.fileThumb, { backgroundColor: color + '18' }]}>
                    {isImage && file.storage_url
                      ? <Image source={{ uri: file.storage_url }} style={styles.fileThumbImg} resizeMode="cover" />
                      : <Icon size={22} color={color} strokeWidth={1.8} />
                    }
                  </View>
                  <View style={styles.fileInfo}>
                    <Text style={styles.fileName} numberOfLines={1}>{file.name}</Text>
                    <Text style={styles.fileMeta}>{formatBytes(file.size)} · {new Date(file.created_at).toLocaleDateString()}</Text>
                  </View>
                  {selectMode ? (
                    <View style={[styles.checkCircle, isSelected && styles.checkCircleSelected]}>
                      {isSelected && <CheckCircle size={16} color="#fff" strokeWidth={2.5} />}
                    </View>
                  ) : (
                    <View style={{ flexDirection: 'row', gap: 6 }}>
                      <TouchableOpacity
                        style={styles.fileActionBtn}
                        onPress={() => handleToggleFavorite(file)}
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                      >
                        <Heart
                          size={16}
                          color="#FF2D55"
                          strokeWidth={1.8}
                          fill={file.is_favorited ? '#FF2D55' : 'none'}
                        />
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={styles.fileActionBtn}
                        onPress={() => downloadFile(file)}
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                      >
                        <Download size={16} color={colors.secondary} strokeWidth={1.8} />
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={[styles.fileActionBtn, styles.deleteBtn]}
                        onPress={() => confirmDelete(file)}
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                      >
                        <Trash2 size={16} color={colors.error} strokeWidth={1.8} />
                      </TouchableOpacity>
                    </View>
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        )}
      </ScrollView>

      {/* Multi-select bar */}
      {selectMode && (
        <View style={styles.selectBar}>
          <View style={styles.selectBarTop}>
            <TouchableOpacity style={styles.selectBarBtn} onPress={exitSelectMode}>
              <X size={20} color={colors.text} strokeWidth={2} />
            </TouchableOpacity>
            <Text style={styles.selectBarCount}>{selected.size} {t('selected')}</Text>
            <TouchableOpacity onPress={() => setSelected(new Set(displayedFiles.map(f => f.id)))}>
              <Text style={styles.selectAllText}>{t('select_all')}</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.selectBarActions}>
            <TouchableOpacity
              style={[styles.selectAction, selected.size === 0 && styles.selectActionDisabled]}
              onPress={handleBulkShare} disabled={selected.size === 0}
            >
              <Share2 size={18} color={selected.size > 0 ? colors.primary : colors.textTertiary} strokeWidth={1.8} />
              <Text style={[styles.selectActionText, { color: selected.size > 0 ? colors.primary : colors.textTertiary }]}>Paylaş</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.selectAction, selected.size === 0 && styles.selectActionDisabled]}
              onPress={handleBulkDownload} disabled={selected.size === 0}
            >
              <Download size={18} color={selected.size > 0 ? colors.secondary : colors.textTertiary} strokeWidth={1.8} />
              <Text style={[styles.selectActionText, { color: selected.size > 0 ? colors.secondary : colors.textTertiary }]}>Yüklə</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.selectAction, selected.size === 0 && styles.selectActionDisabled]}
              onPress={handleBulkDelete} disabled={selected.size === 0}
            >
              <Trash2 size={18} color={selected.size > 0 ? colors.error : colors.textTertiary} strokeWidth={1.8} />
              <Text style={[styles.selectActionText, { color: selected.size > 0 ? colors.error : colors.textTertiary }]}>Sil</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <FileUploadModal
        visible={showUpload}
        onClose={() => setShowUpload(false)}
        onUploaded={handleUploaded}
      />

      {viewerIndex !== null && displayedFiles[viewerIndex] && (
        <MediaViewer
          files={displayedFiles}
          initialIndex={viewerIndex}
          visible={viewerIndex !== null}
          onClose={() => setViewerIndex(null)}
          onDeleted={(file) => {
            setFiles(prev => prev.filter(f => f.id !== file.id));
            refreshProfile();
            if (files.length <= 1) setViewerIndex(null);
          }}
        />
      )}

      {/* Download Progress Overlay */}
      {downloadProgress && (
        <View style={styles.downloadOverlay}>
          <View style={styles.downloadCard}>
            <View style={styles.downloadHeader}>
              <Download size={20} color={colors.primary} strokeWidth={1.8} />
              <Text style={styles.downloadTitle} numberOfLines={1}>{downloadProgress.name}</Text>
            </View>
            <View style={styles.downloadBarTrack}>
              <View style={[styles.downloadBarFill, { width: `${Math.max(5, downloadProgress.percent)}%` as any }]} />
            </View>
            <Text style={styles.downloadPercent}>{downloadProgress.percent}%</Text>
          </View>
        </View>
      )}

      {/* Download Toast */}
      {downloadToast && (
        <View style={styles.toastOverlay}>
          <View style={styles.toastCard}>
            <Text style={styles.toastText}>{downloadToast}</Text>
          </View>
        </View>
      )}
    </View>
  );
}

const gridStyles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: GRID_GAP, marginBottom: spacing.lg },
  cell: { position: 'relative', borderRadius: 4, overflow: 'hidden' },
  durationBadge: {
    position: 'absolute', bottom: 4, right: 4,
    backgroundColor: 'rgba(0,0,0,0.75)', paddingHorizontal: 5, paddingVertical: 2, borderRadius: 3,
  },
  durationText: { color: '#fff', fontSize: 9, fontWeight: '600' },
  favBadge: {
    position: 'absolute', top: 4, left: 4,
    backgroundColor: 'rgba(0,0,0,0.6)', padding: 3, borderRadius: 10,
  },
  check: {
    position: 'absolute', top: 4, right: 4,
    width: 20, height: 20, borderRadius: 10,
    borderWidth: 2, borderColor: '#fff',
    backgroundColor: 'rgba(0,0,0,0.35)',
    alignItems: 'center', justifyContent: 'center',
  },
  checkSelected: { backgroundColor: colors.primary, borderColor: colors.primary },
  menuBtn: {
    position: 'absolute', top: 4, right: 4,
    backgroundColor: 'rgba(0,0,0,0.5)', borderRadius: 10, padding: 3,
  },
});

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: spacing.xl, paddingTop: spacing.md, paddingBottom: 140 },
  iconBtn: { padding: 8, borderRadius: radius.sm },
  searchBar: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: colors.surface, marginHorizontal: spacing.xl, marginBottom: spacing.md,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, gap: spacing.sm,
  },
  searchInput: {
    flex: 1, color: colors.text, fontSize: 14,
    paddingVertical: Platform.OS === 'ios' ? 8 : 4,
  },
  clearSearchBtn: { padding: 4 },
  searchCancelBtn: { paddingHorizontal: spacing.sm },
  searchCancelText: { color: colors.primary, fontSize: 14, fontWeight: '600' },
  selectBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, padding: 8 },
  selectBtnText: { color: colors.textSecondary, fontSize: 14, fontWeight: '500' },
  toolRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: spacing.md },
  sortBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.primary + '18', borderRadius: radius.full,
    paddingHorizontal: spacing.sm, paddingVertical: 5,
  },
  sortBadgeText: { color: colors.primary, fontSize: 11, fontWeight: '600' },
  colSelector: { flexDirection: 'row', gap: 6 },
  colBtn: {
    width: 30, height: 30, borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.06)', alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'transparent',
  },
  colBtnActive: { backgroundColor: 'rgba(30,111,255,0.2)', borderColor: colors.primary },
  colBtnText: { color: colors.textTertiary, fontSize: 12, fontWeight: '600' },
  colBtnTextActive: { color: colors.primary },
  usageCard: {
    borderRadius: radius.xl, padding: spacing.xl,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.2)',
    overflow: 'hidden', marginBottom: spacing.lg,
  },
  usageTop: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.sm },
  usageTitle: { color: colors.textSecondary, fontSize: 14, fontWeight: '500' },
  usageMain: { ...typography.h1, color: colors.text },
  usageSub: { color: colors.textSecondary, fontSize: 13, marginBottom: spacing.md },
  usageBar: { height: 6, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 3, overflow: 'hidden', marginBottom: spacing.lg },
  usageFill: { height: '100%', borderRadius: 3 },
  statGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  statCell: {
    flex: 1, minWidth: '28%', backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: radius.md, padding: spacing.sm, alignItems: 'center', gap: 2,
  },
  statCount: { color: colors.text, fontSize: 15, fontWeight: '700' },
  statLabel: { color: colors.textTertiary, fontSize: 10 },
  statSize: { fontSize: 10, fontWeight: '500' },
  uploadBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.sm, height: 52, borderRadius: radius.full, marginBottom: spacing.sm,
  },
  uploadBtnText: { ...typography.button, color: colors.text },
  wifiSettingsBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.sm, paddingVertical: spacing.sm, marginBottom: spacing.lg,
  },
  wifiSettingsText: { color: colors.textTertiary, fontSize: 12 },
  wifiSettingsChange: { color: colors.primary, fontSize: 12, fontWeight: '600' },
  catScroll: { paddingBottom: spacing.md, gap: spacing.sm },
  catChip: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: colors.surface, borderRadius: radius.full,
    paddingHorizontal: spacing.md, paddingVertical: 8,
    borderWidth: 1, borderColor: colors.border,
  },
  catChipText: { color: colors.textSecondary, fontSize: 12, fontWeight: '500' },
  sectionTitle: { color: colors.textSecondary, fontSize: 13, marginBottom: spacing.md },
  fileList: { gap: spacing.sm },
  fileItem: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: colors.surface, borderRadius: radius.lg,
    padding: spacing.md, gap: spacing.md,
    borderWidth: 1, borderColor: colors.border,
  },
  fileItemSelected: { borderColor: colors.primary, backgroundColor: colors.primary + '12' },
  fileThumb: { width: 48, height: 48, borderRadius: 10, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  fileThumbImg: { width: 48, height: 48 },
  fileInfo: { flex: 1 },
  fileName: { color: colors.text, fontSize: 14, fontWeight: '500' },
  fileMeta: { color: colors.textSecondary, fontSize: 12, marginTop: 2 },
  checkCircle: {
    width: 26, height: 26, borderRadius: 13,
    borderWidth: 2, borderColor: colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  checkCircleSelected: { backgroundColor: colors.primary, borderColor: colors.primary },
  fileActionBtn: {
    width: 34, height: 34, borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center', justifyContent: 'center',
  },
  deleteBtn: { backgroundColor: 'rgba(255,59,48,0.12)' },
  emptyState: { alignItems: 'center', paddingTop: 60, gap: spacing.md },
  emptyTitle: { ...typography.h2, color: colors.text },
  emptySub: { color: colors.textSecondary, fontSize: 14, textAlign: 'center', lineHeight: 22, maxWidth: 280 },
  selectBar: {
    position: 'absolute', top: 0, left: 0, right: 0,
    backgroundColor: '#0D1526',
    borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: spacing.xl,
    paddingTop: Platform.OS === 'ios' ? 56 : 44,
    paddingBottom: spacing.md,
    zIndex: 100,
  },
  selectBarTop: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.md },
  selectBarBtn: { padding: spacing.sm },
  selectBarCount: { flex: 1, color: colors.text, fontSize: 14, fontWeight: '600' },
  selectAllText: { color: colors.primary, fontSize: 13, fontWeight: '600', paddingHorizontal: spacing.sm },
  selectBarActions: { flexDirection: 'row', justifyContent: 'space-around', gap: spacing.md },
  selectAction: { alignItems: 'center', gap: 4, paddingHorizontal: spacing.lg, paddingVertical: spacing.sm },
  selectActionDisabled: { opacity: 0.4 },
  selectActionText: { fontSize: 11, fontWeight: '500', color: colors.textSecondary },
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.75)',
    alignItems: 'center', justifyContent: 'center', padding: spacing.xl,
  },
  sortModal: {
    backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.xl,
    width: '100%', maxWidth: 340, borderWidth: 1, borderColor: colors.border,
  },
  sortTitle: { color: colors.text, fontSize: 16, fontWeight: '700', marginBottom: spacing.md },
  sortOption: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.06)',
  },
  sortOptionActive: {},
  sortOptionText: { color: colors.textSecondary, fontSize: 14 },
  contextMenu: {
    backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg,
    width: '100%', maxWidth: 300, borderWidth: 1, borderColor: colors.border, gap: spacing.sm,
  },
  contextFileName: { color: colors.textTertiary, fontSize: 12, marginBottom: spacing.sm, fontWeight: '500' },
  contextItem: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    padding: spacing.md, borderRadius: radius.md, backgroundColor: 'rgba(255,255,255,0.04)',
  },
  contextItemText: { color: colors.text, fontSize: 14, fontWeight: '500' },
  modalContent: {
    backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.xl,
    width: '100%', maxWidth: 400, borderWidth: 1, borderColor: colors.border,
  },
  modalTitle: { color: colors.text, fontSize: 18, fontWeight: '700', marginBottom: spacing.lg },
  modalCloseBtn: {
    backgroundColor: colors.primary, borderRadius: radius.lg,
    paddingVertical: spacing.md, alignItems: 'center', marginTop: spacing.md,
  },
  modalCloseText: { color: '#fff', fontSize: 15, fontWeight: '600' },
  wifiOption: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md, padding: spacing.md,
    borderRadius: radius.lg, marginBottom: spacing.sm,
    backgroundColor: 'rgba(255,255,255,0.04)', borderWidth: 1, borderColor: 'transparent',
  },
  wifiOptionActive: { borderColor: colors.primary, backgroundColor: colors.primary + '12' },
  wifiOptionText: { flex: 1 },
  wifiOptionTitle: { color: colors.text, fontSize: 15, fontWeight: '600' },
  wifiOptionSub: { color: colors.textTertiary, fontSize: 12, marginTop: 2 },
  deleteModalContent: {
    backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.xl,
    width: '100%', maxWidth: 400, alignItems: 'center', borderWidth: 1, borderColor: colors.border,
  },
  deleteIconWrap: {
    width: 64, height: 64, borderRadius: 32,
    backgroundColor: 'rgba(255,59,48,0.15)', alignItems: 'center', justifyContent: 'center', marginBottom: spacing.lg,
  },
  deleteModalTitle: { color: colors.text, fontSize: 18, fontWeight: '700', marginBottom: spacing.sm },
  deleteModalDesc: { color: colors.textSecondary, fontSize: 14, textAlign: 'center', marginBottom: spacing.sm },
  deleteModalNote: { color: colors.textTertiary, fontSize: 12, textAlign: 'center', marginBottom: spacing.lg },
  deleteModalActions: { flexDirection: 'row', gap: spacing.md, width: '100%' },
  deleteCancelBtn: {
    flex: 1, paddingVertical: spacing.md, borderRadius: radius.lg,
    backgroundColor: 'rgba(255,255,255,0.08)', alignItems: 'center',
  },
  deleteCancelText: { color: colors.text, fontSize: 14, fontWeight: '600' },
  deleteConfirmBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.sm, paddingVertical: spacing.md, borderRadius: radius.lg, backgroundColor: colors.error,
  },
  deleteConfirmText: { color: '#fff', fontSize: 14, fontWeight: '600' },
  downloadOverlay: {
    position: 'absolute', bottom: 100, left: spacing.lg, right: spacing.lg,
    zIndex: 1000,
  },
  downloadCard: {
    backgroundColor: 'rgba(10,20,40,0.95)',
    borderRadius: radius.lg,
    padding: spacing.lg,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)',
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4, shadowRadius: 12, elevation: 16,
  },
  downloadHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.md },
  downloadTitle: { color: colors.text, fontSize: 13, fontWeight: '600', flex: 1 },
  downloadBarTrack: {
    height: 6, backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 3, overflow: 'hidden',
  },
  downloadBarFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 3,
  },
  downloadPercent: { color: colors.primary, fontSize: 12, fontWeight: '600', marginTop: spacing.xs, textAlign: 'right' },
  toastOverlay: {
    position: 'absolute', bottom: 100, left: spacing.lg, right: spacing.lg,
    zIndex: 1000, alignItems: 'center',
  },
  toastCard: {
    backgroundColor: 'rgba(10,20,40,0.95)',
    borderRadius: radius.lg,
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)',
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4, shadowRadius: 12, elevation: 16,
  },
  toastText: { color: colors.text, fontSize: 13, fontWeight: '500' },
});
