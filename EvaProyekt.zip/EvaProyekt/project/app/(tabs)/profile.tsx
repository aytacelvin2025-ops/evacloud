import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  User,
  Settings,
  Shield,
  HelpCircle,
  LogOut,
  ChevronRight,
  Edit3,
  CreditCard,
  Bell,
  Globe,
  Moon,
  Image as ImageIcon,
  Film,
  FileText,
  Music,
  Folder,
  Sparkles,
} from 'lucide-react-native';
import { router } from 'expo-router';
import { useAuth } from '@/context/AuthContext';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { AppHeader } from '@/components/AppHeader';
import { useLanguage } from '@/context/LanguageContext';
import { getFileStats, formatBytes, FileStats } from '@/lib/files';

const MENU_SECTIONS = [
  {
    title: 'Account',
    items: [
      { label: 'Edit Profile', icon: Edit3, color: colors.primary, route: '/profile-edit' },
      { label: 'Subscription', icon: CreditCard, color: '#A066FF', route: '/subscription' },
      { label: 'Notifications', icon: Bell, color: colors.warning, route: '/profile-notifications' },
    ],
  },
  {
    title: 'Preferences',
    items: [
      { label: 'Language', icon: Globe, color: colors.secondary, route: '/language' },
      { label: 'Appearance', icon: Moon, color: '#FF9F0A', route: '/profile-appearance' },
      { label: 'Settings', icon: Settings, color: colors.textSecondary, route: '/profile-settings' },
    ],
  },
  {
    title: 'Support',
    items: [
      { label: 'Security Center', icon: Shield, color: '#34C759', route: '/(tabs)/security' },
      { label: 'Help & Support', icon: HelpCircle, color: colors.primary, route: '/help' },
      { label: 'Updates', icon: Sparkles, color: colors.secondary, route: '/updates' },
    ],
  },
];

export default function ProfileScreen() {
  const { user, profile, signOut } = useAuth();
  const { t } = useLanguage();
  const [signingOut, setSigningOut] = useState(false);
  const [confirmSignOut, setConfirmSignOut] = useState(false);
  const [stats, setStats] = useState<FileStats | null>(null);

  const displayName = [profile?.first_name, profile?.last_name].filter(Boolean).join(' ')
    || user?.user_metadata?.full_name
    || user?.email?.split('@')[0]
    || 'User';

  const email = user?.email || '';
  // Use stats.total_size (accurate from files table) when available, fallback to profile.storage_used
  const storageUsed = stats?.total_size ?? profile?.storage_used ?? 0;
  const storageLimit = profile?.storage_limit ?? 16_492_674_416_640;
  const usedPct = Math.min((storageUsed / storageLimit) * 100, 100);
  const isGuest = !user;

  useEffect(() => {
    if (user) {
      getFileStats(user.id).then(setStats);
    }
  }, [user]);

  async function handleSignOut() {
    if (!confirmSignOut) {
      setConfirmSignOut(true);
      return;
    }
    setSigningOut(true);
    setConfirmSignOut(false);
    try {
      await signOut();
      router.replace('/welcome');
    } catch {
      setSigningOut(false);
    }
  }

  const FILE_CATEGORIES = [
    { key: 'photos', labelKey: 'photos', icon: ImageIcon, color: '#FF9F0A' },
    { key: 'videos', labelKey: 'videos', icon: Film, color: '#FF3B30' },
    { key: 'documents', labelKey: 'documents', icon: FileText, color: colors.primary },
    { key: 'music', labelKey: 'music', icon: Music, color: '#34C759' },
    { key: 'other', labelKey: 'other', icon: Folder, color: '#6B7280' },
  ];

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />
      <AppHeader />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>{t('profile')}</Text>

        {/* Avatar + info */}
        <View style={styles.profileCard}>
          <LinearGradient
            colors={['rgba(30,111,255,0.12)', 'rgba(0,0,0,0)']}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.avatarSection}>
            <View style={styles.avatarWrapper}>
              {profile?.avatar_url
                ? <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
                : (
                  <LinearGradient
                    colors={colors.gradientPrimary}
                    style={styles.avatarFallback}
                  >
                    <Text style={styles.avatarInitial}>{displayName.charAt(0).toUpperCase()}</Text>
                  </LinearGradient>
                )
              }
            </View>
            <View style={styles.userInfo}>
              <Text style={styles.displayName}>{displayName}</Text>
              {profile?.username && (
                <Text style={styles.username}>@{profile.username}</Text>
              )}
              <Text style={styles.email}>{email}</Text>
            </View>
          </View>

          {/* Storage bar */}
          <View style={styles.storageRow}>
            <View style={styles.storageLabels}>
              <Text style={styles.storageUsedText}>{formatBytes(storageUsed)} {t('used')}</Text>
              <Text style={styles.storageLimitText}>{formatBytes(storageLimit)}</Text>
            </View>
            <View style={styles.storageBar}>
              <LinearGradient
                colors={colors.gradientPrimary}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={[styles.storageFill, { width: `${usedPct}%` }]}
              />
            </View>
          </View>

          {/* Category breakdown */}
          {stats && (
            <View style={styles.categoryGrid}>
              {FILE_CATEGORIES.map(cat => {
                const catStats = stats.by_category[cat.key] ?? { count: 0, size: 0 };
                const Icon = cat.icon;
                return (
                  <View key={cat.key} style={styles.categoryCell}>
                    <Icon size={14} color={cat.color} strokeWidth={1.8} />
                    <Text style={styles.categoryCount}>{catStats.count}</Text>
                    <Text style={styles.categoryLabel}>{t(cat.labelKey)}</Text>
                    <Text style={[styles.categorySize, { color: cat.color }]}>{formatBytes(catStats.size)}</Text>
                  </View>
                );
              })}
            </View>
          )}
        </View>

        {/* Plan badge */}
        <View style={styles.planBadge}>
          <View style={styles.planLeft}>
            <View style={styles.planDot} />
            <Text style={styles.planName}>{t('free_plan')}</Text>
          </View>
          <TouchableOpacity activeOpacity={0.85}>
            <LinearGradient
              colors={colors.gradientPrimary}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.upgradeBtn}
            >
              <Text style={styles.upgradeBtnText}>{t('upgrade')}</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Menu sections */}
        {MENU_SECTIONS.map((section) => (
          <View key={section.title} style={styles.section}>
            <Text style={styles.sectionTitle}>{t(section.title === 'Account' ? 'account' : section.title === 'Preferences' ? 'preferences' : 'support')}</Text>
            <View style={styles.sectionCard}>
              {section.items.map((item, i) => {
                const Icon = item.icon;
                const labelKey = item.label === 'Edit Profile' ? 'edit_profile' :
                  item.label === 'Subscription' ? 'subscription' :
                  item.label === 'Notifications' ? 'notifications' :
                  item.label === 'Language' ? 'language' :
                  item.label === 'Appearance' ? 'appearance' :
                  item.label === 'Settings' ? 'settings' :
                  item.label === 'Security Center' ? 'security_center' :
                  item.label === 'Help & Support' ? 'help_support' : item.label;
                return (
                  <View key={item.label}>
                    {i > 0 && <View style={styles.separator} />}
                    <TouchableOpacity
                      style={styles.menuRow}
                      activeOpacity={0.75}
                      onPress={() => {
                        if ('route' in item && item.route) {
                          router.push(item.route as any);
                        }
                      }}
                    >
                      <View style={[styles.menuIcon, { backgroundColor: item.color + '1A' }]}>
                        <Icon size={18} color={item.color} strokeWidth={1.8} />
                      </View>
                      <Text style={styles.menuLabel}>{t(labelKey)}</Text>
                      <ChevronRight size={16} color={colors.textTertiary} strokeWidth={2} />
                    </TouchableOpacity>
                  </View>
                );
              })}
            </View>
          </View>
        ))}

        {/* Sign out */}
        {confirmSignOut ? (
          <View style={styles.confirmBox}>
            <Text style={styles.confirmText}>{t('sign_out_confirm')}</Text>
            <View style={styles.confirmRow}>
              <TouchableOpacity
                style={styles.confirmCancel}
                onPress={() => setConfirmSignOut(false)}
                activeOpacity={0.75}
              >
                <Text style={styles.confirmCancelText}>{t('cancel')}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.confirmSignOut}
                onPress={handleSignOut}
                disabled={signingOut}
                activeOpacity={0.75}
              >
                {signingOut
                  ? <ActivityIndicator color="#fff" size="small" />
                  : <Text style={styles.confirmSignOutText}>{t('sign_out')}</Text>
                }
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <TouchableOpacity
            style={styles.signOutBtn}
            onPress={handleSignOut}
            disabled={signingOut}
            activeOpacity={0.75}
          >
            <LogOut size={18} color={colors.error} strokeWidth={2} />
            <Text style={styles.signOutText}>{t('sign_out')}</Text>
          </TouchableOpacity>
        )}

        <Text style={styles.version}>EVA Cloud X v2.2.0 · {t('all_rights_reserved')}</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: 100 },
  title: { ...typography.h1, color: colors.text, marginBottom: spacing.xl },
  profileCard: {
    borderRadius: radius.xl,
    padding: spacing.xl,
    borderWidth: 1,
    borderColor: 'rgba(30,111,255,0.2)',
    overflow: 'hidden',
    marginBottom: spacing.md,
  },
  avatarSection: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.lg },
  avatarWrapper: { width: 72, height: 72, borderRadius: 36, overflow: 'hidden' },
  avatar: { width: 72, height: 72 },
  avatarFallback: { width: 72, height: 72, alignItems: 'center', justifyContent: 'center' },
  avatarInitial: { fontSize: 30, fontWeight: '700', color: colors.text },
  userInfo: { flex: 1 },
  displayName: { ...typography.h3, color: colors.text },
  username: { color: colors.primary, fontSize: 13, marginTop: 2 },
  email: { color: colors.textSecondary, fontSize: 13, marginTop: 2 },
  storageRow: { gap: 6, marginBottom: spacing.md },
  storageLabels: { flexDirection: 'row', justifyContent: 'space-between' },
  storageUsedText: { fontSize: 12, color: colors.textSecondary },
  storageLimitText: { fontSize: 12, color: colors.textTertiary },
  storageBar: { height: 4, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 2, overflow: 'hidden' },
  storageFill: { height: '100%', borderRadius: 2 },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.sm },
  categoryCell: {
    flex: 1, minWidth: '18%', backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: radius.md, padding: spacing.sm, alignItems: 'center', gap: 2,
  },
  categoryCount: { color: colors.text, fontSize: 13, fontWeight: '700' },
  categoryLabel: { color: colors.textTertiary, fontSize: 10 },
  categorySize: { fontSize: 10, fontWeight: '500' },
  planBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.xl,
  },
  planLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  planDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.textSecondary },
  planName: { color: colors.text, fontSize: 15, fontWeight: '500' },
  upgradeBtn: { paddingHorizontal: spacing.lg, paddingVertical: 8, borderRadius: radius.full },
  upgradeBtnText: { color: colors.text, fontSize: 13, fontWeight: '600' },
  section: { marginBottom: spacing.lg },
  sectionTitle: { color: colors.textSecondary, fontSize: 12, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: spacing.sm },
  sectionCard: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    overflow: 'hidden',
  },
  separator: { height: 1, backgroundColor: colors.border, marginLeft: 58 },
  menuRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, padding: spacing.md },
  menuIcon: { width: 36, height: 36, borderRadius: radius.sm, alignItems: 'center', justifyContent: 'center' },
  menuLabel: { flex: 1, color: colors.text, fontSize: 14, fontWeight: '400' },
  signOutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    backgroundColor: 'rgba(255,59,48,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,59,48,0.2)',
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  signOutText: { color: colors.error, fontSize: 15, fontWeight: '600' },
  confirmBox: {
    backgroundColor: 'rgba(255,59,48,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,59,48,0.25)',
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
    alignItems: 'center',
    gap: spacing.md,
  },
  confirmText: { color: colors.text, fontSize: 15, fontWeight: '500', textAlign: 'center' },
  confirmRow: { flexDirection: 'row', gap: spacing.md, width: '100%' },
  confirmCancel: {
    flex: 1,
    height: 42,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmCancelText: { color: colors.textSecondary, fontSize: 14, fontWeight: '500' },
  confirmSignOut: {
    flex: 1,
    height: 42,
    borderRadius: radius.md,
    backgroundColor: colors.error,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmSignOutText: { color: '#fff', fontSize: 14, fontWeight: '600' },
  version: { color: colors.textTertiary, fontSize: 11, textAlign: 'center' },
});
