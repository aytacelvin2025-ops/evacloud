import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  RefreshControl,
  ActivityIndicator,
  Modal,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Trash2,
  RotateCcw,
  Folder,
  Image as Img,
  Film,
  FileText,
  Music,
  AlertTriangle,
  Settings,
  X,
  CheckCircle,
  Grid,
  Clock,
} from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import {
  listTrash,
  restoreFromTrash,
  permanentDelete,
  emptyTrash,
  formatBytes,
  getTrashCleanupSetting,
  setTrashCleanupSetting,
  TrashRecord,
  TrashCleanupSetting,
} from '@/lib/files';
import { AppHeader } from '@/components/AppHeader';
import { useLanguage } from '@/context/LanguageContext';
import { colors, spacing, radius, typography } from '@/constants/theme';

const CAT_ICON_MAP: Record<string, typeof Img> = {
  photos: Img,
  videos: Film,
  documents: FileText,
  music: Music,
  other: Folder,
};
const CAT_COLOR_MAP: Record<string, string> = {
  photos: '#FF9F0A',
  videos: '#FF3B30',
  documents: colors.primary,
  music: '#34C759',
  other: '#6B7280',
};

const CLEANUP_OPTIONS: { value: TrashCleanupSetting; label: string }[] = [
  { value: 0, label: 'Heç vaxt' },
  { value: 30, label: '30 gün' },
  { value: 60, label: '60 gün' },
  { value: 90, label: '90 gün' },
];

export default function TrashScreen() {
  const { user, refreshProfile } = useAuth();
  const { t } = useLanguage();
  const [trashItems, setTrashItems] = useState<TrashRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [cleanupDays, setCleanupDays] = useState<TrashCleanupSetting>(30);
  const [showSettings, setShowSettings] = useState(false);
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showEmptyConfirm, setShowEmptyConfirm] = useState(false);
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<TrashRecord | null>(null);

  async function autoCleanupExpired(items: TrashRecord[], days: TrashCleanupSetting) {
    if (days === 0) return items;
    const now = Date.now();
    const expired = items.filter(item => {
      const deletedAt = new Date(item.deleted_at).getTime();
      return now - deletedAt > days * 24 * 60 * 60 * 1000;
    });
    if (expired.length === 0) return items;
    // Silently delete expired items
    for (const item of expired) {
      await permanentDelete(item);
    }
    return items.filter(item => !expired.some(e => e.id === item.id));
  }

  async function loadData() {
    if (!user) return;
    try {
      const [rawItems, setting] = await Promise.all([
        listTrash(user.id),
        getTrashCleanupSetting(user.id),
      ]);
      setCleanupDays(setting);
      const cleaned = await autoCleanupExpired(rawItems, setting);
      setTrashItems(cleaned);
    } catch (e) {
      console.error('Trash load error:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => { loadData(); }, [user]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadData();
  }, [user]);

  function exitSelectMode() {
    setSelectMode(false);
    setSelected(new Set());
  }

  function toggleSelect(id: string) {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function handleRestore(item: TrashRecord) {
    const result = await restoreFromTrash(item);
    if (result.success) {
      setTrashItems(prev => prev.filter(i => i.id !== item.id));
      setSelected(prev => { const n = new Set(prev); n.delete(item.id); return n; });
      refreshProfile();
    }
  }

  async function handleBulkRestore() {
    const toRestore = trashItems.filter(i => selected.has(i.id));
    for (const item of toRestore) {
      await handleRestore(item);
    }
    exitSelectMode();
  }

  function confirmDeleteItem(item: TrashRecord) {
    setItemToDelete(item);
    setShowDeleteConfirm(true);
  }

  async function executeDeleteItem() {
    if (!itemToDelete) return;
    setShowDeleteConfirm(false);
    const result = await permanentDelete(itemToDelete);
    if (result.success) {
      setTrashItems(prev => prev.filter(i => i.id !== itemToDelete.id));
      setSelected(prev => { const n = new Set(prev); n.delete(itemToDelete.id); return n; });
      refreshProfile();
    }
    setItemToDelete(null);
  }

  async function executeBulkDelete() {
    setShowBulkDeleteConfirm(false);
    const toDelete = trashItems.filter(item => selected.has(item.id));
    for (const item of toDelete) {
      await permanentDelete(item);
    }
    setTrashItems(prev => prev.filter(i => !selected.has(i.id)));
    setSelected(new Set());
    setSelectMode(false);
    refreshProfile();
  }

  async function handleEmptyTrash() {
    setShowEmptyConfirm(false);
    const result = await emptyTrash(user!.id);
    if (result.success) {
      setTrashItems([]);
      refreshProfile();
    }
  }

  async function handleCleanupChange(days: TrashCleanupSetting) {
    if (!user) return;
    const success = await setTrashCleanupSetting(user.id, days);
    if (success) {
      setCleanupDays(days);
      // Run cleanup with new setting immediately
      const cleaned = await autoCleanupExpired(trashItems, days);
      setTrashItems(cleaned);
    }
    setShowSettings(false);
  }

  function daysUntilDelete(item: TrashRecord): number {
    if (cleanupDays === 0) return -1;
    const deletedDate = new Date(item.deleted_at);
    const deleteDate = new Date(deletedDate.getTime() + cleanupDays * 24 * 60 * 60 * 1000);
    const now = new Date();
    const diffDays = Math.ceil((deleteDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return Math.max(0, diffDays);
  }

  const totalSize = trashItems.reduce((s, i) => s + i.size, 0);

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#050D1A', '#000000']} style={StyleSheet.absoluteFill} />
      <AppHeader
        title={t('trash') || 'Zibil Qutusu'}
        rightContent={
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <TouchableOpacity style={styles.settingsBtn} onPress={() => setShowSettings(true)}>
              <Settings size={18} color={colors.textSecondary} strokeWidth={1.8} />
            </TouchableOpacity>
            {trashItems.length > 0 && !selectMode && (
              <TouchableOpacity style={styles.selectBtn} onPress={() => setSelectMode(true)}>
                <Grid size={16} color={colors.textSecondary} strokeWidth={1.8} />
                <Text style={styles.selectBtnText}>{t('select')}</Text>
              </TouchableOpacity>
            )}
          </View>
        }
      />

      {/* Cleanup Settings Modal */}
      <Modal visible={showSettings} transparent animationType="fade" onRequestClose={() => setShowSettings(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.settingsModal}>
            <View style={styles.settingsHeader}>
              <Clock size={20} color={colors.primary} strokeWidth={1.8} />
              <Text style={styles.settingsTitle}>Avtomatik Silinmə</Text>
            </View>
            <Text style={styles.settingsDesc}>
              Zibil qutusundakı fayllar seçilmiş müddətdən sonra avtomatik birdəfəlik silinir.
            </Text>
            <View style={styles.cleanupOptions}>
              {CLEANUP_OPTIONS.map(opt => (
                <TouchableOpacity
                  key={opt.value}
                  style={[styles.cleanupOption, cleanupDays === opt.value && styles.cleanupOptionActive]}
                  onPress={() => handleCleanupChange(opt.value)}
                >
                  <Text style={[styles.cleanupOptionText, cleanupDays === opt.value && { color: colors.primary, fontWeight: '700' }]}>
                    {opt.label}
                  </Text>
                  {cleanupDays === opt.value && <CheckCircle size={16} color={colors.primary} strokeWidth={2} />}
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity style={styles.closeSettingsBtn} onPress={() => setShowSettings(false)}>
              <Text style={styles.closeSettingsBtnText}>Bağla</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Single delete confirmation modal */}
      <Modal visible={showDeleteConfirm} transparent animationType="fade" onRequestClose={() => setShowDeleteConfirm(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.deleteModal}>
            <View style={styles.deleteIconWrap}>
              <Trash2 size={32} color={colors.error} strokeWidth={1.8} />
            </View>
            <Text style={styles.deleteModalTitle}>Birdəfəlik Sil</Text>
            <Text style={styles.deleteModalDesc}>
              {itemToDelete ? `"${itemToDelete.name}"` : ''} fayl birdəfəlik silinsin?
            </Text>
            <Text style={styles.deleteModalNote}>Bu əməliyyat geri qaytarıla bilməz.</Text>
            <View style={styles.deleteModalActions}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => { setShowDeleteConfirm(false); setItemToDelete(null); }}>
                <Text style={styles.cancelBtnText}>{t('cancel')}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.deleteBtn} onPress={executeDeleteItem}>
                <Trash2 size={16} color="#fff" strokeWidth={2} />
                <Text style={styles.deleteBtnText}>Sil</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Bulk delete confirmation modal */}
      <Modal visible={showBulkDeleteConfirm} transparent animationType="fade" onRequestClose={() => setShowBulkDeleteConfirm(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.deleteModal}>
            <View style={styles.deleteIconWrap}>
              <Trash2 size={32} color={colors.error} strokeWidth={1.8} />
            </View>
            <Text style={styles.deleteModalTitle}>Seçilənləri Sil</Text>
            <Text style={styles.deleteModalDesc}>{selected.size} fayl birdəfəlik silinsin?</Text>
            <Text style={styles.deleteModalNote}>Bu əməliyyat geri qaytarıla bilməz.</Text>
            <View style={styles.deleteModalActions}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowBulkDeleteConfirm(false)}>
                <Text style={styles.cancelBtnText}>{t('cancel')}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.deleteBtn} onPress={executeBulkDelete}>
                <Trash2 size={16} color="#fff" strokeWidth={2} />
                <Text style={styles.deleteBtnText}>Sil</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Empty trash confirmation modal */}
      <Modal visible={showEmptyConfirm} transparent animationType="fade" onRequestClose={() => setShowEmptyConfirm(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.deleteModal}>
            <View style={styles.deleteIconWrap}>
              <Trash2 size={32} color={colors.error} strokeWidth={1.8} />
            </View>
            <Text style={styles.deleteModalTitle}>Zibil Qutusunu Boşalt</Text>
            <Text style={styles.deleteModalDesc}>
              Bütün {trashItems.length} fayl birdəfəlik silinsin?
            </Text>
            <Text style={styles.deleteModalNote}>Bu əməliyyat geri qaytarıla bilməz.</Text>
            <View style={styles.deleteModalActions}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowEmptyConfirm(false)}>
                <Text style={styles.cancelBtnText}>{t('cancel')}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.deleteBtn} onPress={handleEmptyTrash}>
                <Trash2 size={16} color="#fff" strokeWidth={2} />
                <Text style={styles.deleteBtnText}>Hamısını Sil</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Select mode bar */}
      {selectMode && (
        <View style={styles.selectBar}>
          <View style={styles.selectBarTop}>
            <TouchableOpacity style={styles.selectBarBtn} onPress={exitSelectMode}>
              <X size={20} color={colors.text} strokeWidth={2} />
            </TouchableOpacity>
            <Text style={styles.selectBarCount}>{selected.size} {t('selected')}</Text>
            <TouchableOpacity onPress={() => setSelected(new Set(trashItems.map(i => i.id)))}>
              <Text style={styles.selectAllText}>{t('select_all')}</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.selectBarActions}>
            <TouchableOpacity
              style={[styles.selectAction, selected.size === 0 && styles.selectActionDisabled]}
              onPress={handleBulkRestore}
              disabled={selected.size === 0}
            >
              <RotateCcw size={18} color={selected.size > 0 ? colors.success : colors.textTertiary} strokeWidth={1.8} />
              <Text style={[styles.selectActionText, { color: selected.size > 0 ? colors.success : colors.textTertiary }]}>
                Bərpa et
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.selectAction, selected.size === 0 && styles.selectActionDisabled]}
              onPress={() => selected.size > 0 && setShowBulkDeleteConfirm(true)}
              disabled={selected.size === 0}
            >
              <Trash2 size={18} color={selected.size > 0 ? colors.error : colors.textTertiary} strokeWidth={1.8} />
              <Text style={[styles.selectActionText, { color: selected.size > 0 ? colors.error : colors.textTertiary }]}>
                Sil
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <ScrollView
        contentContainerStyle={[styles.content, selectMode && { paddingTop: 140 }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
      >
        {/* Auto-cleanup info bar */}
        <View style={styles.cleanupBar}>
          <Clock size={14} color={cleanupDays > 0 ? colors.warning : colors.textTertiary} strokeWidth={1.8} />
          <Text style={[styles.cleanupBarText, { color: cleanupDays > 0 ? colors.warning : colors.textTertiary }]}>
            {cleanupDays === 0
              ? 'Avtomatik silinmə: Heç vaxt'
              : `Avtomatik silinmə: ${cleanupDays} gün sonra`}
          </Text>
          <TouchableOpacity onPress={() => setShowSettings(true)}>
            <Text style={styles.cleanupBarChange}>Dəyiş</Text>
          </TouchableOpacity>
        </View>

        {loading ? (
          <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
        ) : trashItems.length === 0 ? (
          <View style={styles.emptyState}>
            <Trash2 size={56} color={colors.textTertiary} strokeWidth={1} />
            <Text style={styles.emptyTitle}>{t('trash_empty') || 'Zibil Qutusu Boşdur'}</Text>
            <Text style={styles.emptySub}>Silinmiş fayllar burada görünəcək</Text>
          </View>
        ) : (
          <>
            <View style={styles.headerRow}>
              <View>
                <Text style={styles.countText}>{trashItems.length} fayl</Text>
                <Text style={styles.sizeText}>{formatBytes(totalSize)} tutum</Text>
              </View>
              <TouchableOpacity style={styles.emptyBtn} onPress={() => setShowEmptyConfirm(true)}>
                <Trash2 size={14} color={colors.error} strokeWidth={1.8} />
                <Text style={styles.emptyBtnText}>Hamısını Sil</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.fileList}>
              {trashItems.map(item => {
                const Icon = CAT_ICON_MAP[item.category] ?? Folder;
                const color = CAT_COLOR_MAP[item.category] ?? '#6B7280';
                const daysLeft = daysUntilDelete(item);
                const isSelected = selected.has(item.id);
                const isUrgent = daysLeft >= 0 && daysLeft <= 3;
                return (
                  <TouchableOpacity
                    key={item.id}
                    style={[styles.fileItem, isSelected && styles.fileItemSelected]}
                    onPress={() => { if (selectMode) toggleSelect(item.id); }}
                    onLongPress={() => { setSelectMode(true); setSelected(new Set([item.id])); }}
                    activeOpacity={selectMode ? 0.7 : 1}
                  >
                    <View style={[styles.fileThumb, { backgroundColor: color + '18' }]}>
                      {item.mime_type.startsWith('image/') && item.storage_url ? (
                        <Image source={{ uri: item.storage_url }} style={styles.fileThumbImg} resizeMode="cover" />
                      ) : (
                        <Icon size={22} color={color} strokeWidth={1.8} />
                      )}
                    </View>
                    <View style={styles.fileInfo}>
                      <Text style={styles.fileName} numberOfLines={1}>{item.name}</Text>
                      <Text style={styles.fileMeta}>{formatBytes(item.size)}</Text>
                      {cleanupDays > 0 && daysLeft >= 0 && (
                        <Text style={[styles.daysLeft, isUrgent && { color: colors.error }]}>
                          {daysLeft === 0 ? 'Bu gün silinəcək!' : `${daysLeft} gün qaldı`}
                        </Text>
                      )}
                    </View>
                    {selectMode ? (
                      <TouchableOpacity
                        style={[styles.checkCircle, isSelected && styles.checkCircleSelected]}
                        onPress={() => toggleSelect(item.id)}
                        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                      >
                        {isSelected && <CheckCircle size={16} color="#fff" strokeWidth={2.5} />}
                      </TouchableOpacity>
                    ) : (
                      <View style={styles.fileActions}>
                        <TouchableOpacity
                          style={styles.restoreBtn}
                          onPress={() => handleRestore(item)}
                          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                        >
                          <RotateCcw size={16} color={colors.success} strokeWidth={1.8} />
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={styles.deleteItemBtn}
                          onPress={() => confirmDeleteItem(item)}
                          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                        >
                          <Trash2 size={16} color={colors.error} strokeWidth={1.8} />
                        </TouchableOpacity>
                      </View>
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: spacing.xl, paddingTop: spacing.md, paddingBottom: 120 },
  settingsBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
  },
  selectBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, padding: 8 },
  selectBtnText: { color: colors.textSecondary, fontSize: 14, fontWeight: '500' },
  selectBar: {
    position: 'absolute', top: 0, left: 0, right: 0,
    backgroundColor: '#0D1526',
    borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: spacing.xl,
    paddingTop: Platform.OS === 'ios' ? 56 : 44,
    paddingBottom: spacing.md,
    zIndex: 100,
  },
  selectBarTop: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.md },
  selectBarBtn: { padding: spacing.sm },
  selectBarCount: { flex: 1, color: colors.text, fontSize: 14, fontWeight: '600' },
  selectAllText: { color: colors.primary, fontSize: 13, fontWeight: '600', paddingHorizontal: spacing.sm },
  selectBarActions: { flexDirection: 'row', justifyContent: 'space-around', gap: spacing.md },
  selectAction: { alignItems: 'center', gap: 4, paddingHorizontal: spacing.xl, paddingVertical: spacing.sm },
  selectActionDisabled: { opacity: 0.4 },
  selectActionText: { fontSize: 12, fontWeight: '600' },
  cleanupBar: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: 'rgba(255,255,255,0.04)', borderRadius: radius.md,
    padding: spacing.md, marginBottom: spacing.md,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)',
  },
  cleanupBarText: { flex: 1, fontSize: 12, fontWeight: '500' },
  cleanupBarChange: { color: colors.primary, fontSize: 12, fontWeight: '600' },
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.75)',
    alignItems: 'center', justifyContent: 'center', padding: spacing.xl,
  },
  settingsModal: {
    backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.xl,
    width: '100%', maxWidth: 380, borderWidth: 1, borderColor: colors.border,
  },
  settingsHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.sm },
  settingsTitle: { color: colors.text, fontSize: 18, fontWeight: '700' },
  settingsDesc: { color: colors.textSecondary, fontSize: 13, marginBottom: spacing.lg, lineHeight: 20 },
  cleanupOptions: { gap: spacing.sm, marginBottom: spacing.lg },
  cleanupOption: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: spacing.md, borderRadius: radius.lg,
    backgroundColor: 'rgba(255,255,255,0.04)', borderWidth: 1, borderColor: 'transparent',
  },
  cleanupOptionActive: { borderColor: colors.primary, backgroundColor: colors.primary + '12' },
  cleanupOptionText: { color: colors.textSecondary, fontSize: 15 },
  closeSettingsBtn: {
    backgroundColor: colors.primary, borderRadius: radius.lg,
    paddingVertical: spacing.md, alignItems: 'center',
  },
  closeSettingsBtnText: { color: '#fff', fontSize: 15, fontWeight: '600' },
  deleteModal: {
    backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.xl,
    width: '100%', maxWidth: 380, alignItems: 'center', borderWidth: 1, borderColor: colors.border,
  },
  deleteIconWrap: {
    width: 64, height: 64, borderRadius: 32,
    backgroundColor: 'rgba(255,59,48,0.15)', alignItems: 'center', justifyContent: 'center', marginBottom: spacing.lg,
  },
  deleteModalTitle: { color: colors.text, fontSize: 18, fontWeight: '700', marginBottom: spacing.sm },
  deleteModalDesc: { color: colors.textSecondary, fontSize: 14, textAlign: 'center', marginBottom: spacing.sm },
  deleteModalNote: { color: colors.textTertiary, fontSize: 12, textAlign: 'center', marginBottom: spacing.lg },
  deleteModalActions: { flexDirection: 'row', gap: spacing.md, width: '100%' },
  cancelBtn: {
    flex: 1, paddingVertical: spacing.md, borderRadius: radius.lg,
    backgroundColor: 'rgba(255,255,255,0.08)', alignItems: 'center',
  },
  cancelBtnText: { color: colors.text, fontSize: 14, fontWeight: '600' },
  deleteBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.sm, paddingVertical: spacing.md, borderRadius: radius.lg, backgroundColor: colors.error,
  },
  deleteBtnText: { color: '#fff', fontSize: 14, fontWeight: '600' },
  emptyState: { alignItems: 'center', justifyContent: 'center', marginTop: 60, gap: spacing.md },
  emptyTitle: { ...typography.h2, color: colors.text },
  emptySub: { color: colors.textSecondary, fontSize: 14 },
  headerRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md,
  },
  countText: { color: colors.text, fontSize: 15, fontWeight: '600' },
  sizeText: { color: colors.textTertiary, fontSize: 12, marginTop: 2 },
  emptyBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderRadius: radius.md, backgroundColor: 'rgba(255,59,48,0.12)',
  },
  emptyBtnText: { color: colors.error, fontSize: 12, fontWeight: '600' },
  fileList: { gap: spacing.sm },
  fileItem: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md,
    borderWidth: 1, borderColor: colors.border,
  },
  fileItemSelected: { borderColor: colors.primary, backgroundColor: colors.primary + '12' },
  fileThumb: {
    width: 48, height: 48, borderRadius: radius.md,
    alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
  },
  fileThumbImg: { width: 48, height: 48 },
  fileInfo: { flex: 1 },
  fileName: { color: colors.text, fontSize: 14, fontWeight: '500' },
  fileMeta: { color: colors.textSecondary, fontSize: 12, marginTop: 2 },
  daysLeft: { color: colors.warning, fontSize: 11, marginTop: 2, fontWeight: '500' },
  checkCircle: {
    width: 28, height: 28, borderRadius: 14,
    borderWidth: 2, borderColor: colors.border, alignItems: 'center', justifyContent: 'center',
  },
  checkCircleSelected: { backgroundColor: colors.primary, borderColor: colors.primary },
  fileActions: { flexDirection: 'row', gap: spacing.sm },
  restoreBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: 'rgba(52,199,89,0.12)', alignItems: 'center', justifyContent: 'center',
  },
  deleteItemBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: 'rgba(255,59,48,0.12)', alignItems: 'center', justifyContent: 'center',
  },
});
