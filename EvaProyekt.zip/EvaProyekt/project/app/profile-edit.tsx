import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Image,
  Alert,
  Platform,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowLeft, User, Mail, Phone, Globe, AtSign, Camera } from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { colors, spacing, radius, typography } from '@/constants/theme';

async function uploadAvatar(userId: string, uri: string, mimeType: string): Promise<string | null> {
  try {
    let blob: Blob;
    if (Platform.OS === 'web') {
      const resp = await fetch(uri);
      blob = await resp.blob();
    } else {
      const resp = await fetch(uri);
      blob = await resp.blob();
    }

    const path = `${userId}/avatar.jpg`;
    const { error } = await supabase.storage.from('avatars').upload(path, blob, {
      contentType: mimeType,
      upsert: true,
    });
    if (error) return null;

    const { data } = await supabase.storage.from('avatars').createSignedUrl(path, 60 * 60 * 24 * 365);
    return data?.signedUrl ?? null;
  } catch {
    return null;
  }
}

export default function EditProfileScreen() {
  const { user, profile, refreshProfile } = useAuth();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('');
  const [avatarUri, setAvatarUri] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    if (profile && !initialized) {
      setFirstName(profile.first_name ?? '');
      setLastName(profile.last_name ?? '');
      setUsername(profile.username ?? '');
      setPhone(profile.phone ?? '');
      setCountry(profile.country ?? '');
      setAvatarUri(profile.avatar_url ?? null);
      setInitialized(true);
    }
  }, [profile, initialized]);

  async function pickAvatar() {
    if (Platform.OS === 'web') {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.onchange = async () => {
        const file = input.files?.[0];
        if (!file) return;
        const uri = URL.createObjectURL(file);
        setAvatarUri(uri);
      };
      input.click();
    } else {
      try {
        const ImagePicker = await import('expo-image-picker');
        const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (!perm.granted) { Alert.alert('Permission needed', 'Allow photo access to change your avatar'); return; }
        const result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          allowsEditing: true,
          aspect: [1, 1],
          quality: 0.8,
        });
        if (!result.canceled && result.assets[0]) {
          setAvatarUri(result.assets[0].uri);
        }
      } catch {
        Alert.alert('Error', 'Could not open image picker');
      }
    }
  }

  async function handleSave() {
    if (!user) return;
    setError('');
    setSaving(true);
    try {
      let avatarUrl = profile?.avatar_url ?? null;

      // Upload new avatar if changed
      if (avatarUri && avatarUri !== profile?.avatar_url) {
        const mimeType = avatarUri.startsWith('blob:') ? 'image/jpeg' : 'image/jpeg';
        const uploaded = await uploadAvatar(user.id, avatarUri, mimeType);
        if (uploaded) avatarUrl = uploaded;
      }

      const { error: err } = await supabase.from('profiles').upsert({
        id: user.id,
        first_name: firstName.trim() || null,
        last_name: lastName.trim() || null,
        username: username.trim() || null,
        phone: phone.trim() || null,
        country: country.trim() || null,
        avatar_url: avatarUrl,
        updated_at: new Date().toISOString(),
      });

      if (err) { setError(err.message); return; }
      await refreshProfile();
      setSuccess(true);
      setTimeout(() => router.back(), 800);
    } catch {
      setError('Failed to save. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  const displayInitial = (firstName || user?.email || 'U').charAt(0).toUpperCase();

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#030810', '#000000']} style={StyleSheet.absoluteFill} />
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <ArrowLeft size={22} color={colors.text} strokeWidth={2} />
        </TouchableOpacity>

        <Text style={styles.title}>Edit Profile</Text>
        <Text style={styles.subtitle}>Update your personal information</Text>

        {/* Avatar */}
        <TouchableOpacity style={styles.avatarSection} onPress={pickAvatar} activeOpacity={0.85}>
          {avatarUri ? (
            <Image source={{ uri: avatarUri }} style={styles.avatar} />
          ) : (
            <LinearGradient colors={colors.gradientPrimary} style={styles.avatarFallback}>
              <Text style={styles.avatarInitial}>{displayInitial}</Text>
            </LinearGradient>
          )}
          <View style={styles.cameraBtn}>
            <Camera size={16} color="#fff" strokeWidth={2} />
          </View>
        </TouchableOpacity>
        <Text style={styles.avatarHint}>Tap to change photo</Text>

        {!!error && (
          <View style={styles.errorBox}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}

        {success && (
          <View style={styles.successBox}>
            <Text style={styles.successText}>Profile saved!</Text>
          </View>
        )}

        {[
          { label: 'First Name', value: firstName, set: setFirstName, icon: User, placeholder: 'Elvin', cap: 'words' as const },
          { label: 'Last Name', value: lastName, set: setLastName, icon: User, placeholder: 'Surname', cap: 'words' as const },
          { label: 'Username', value: username, set: setUsername, icon: AtSign, placeholder: 'username', cap: 'none' as const },
          { label: 'Phone', value: phone, set: setPhone, icon: Phone, placeholder: '+994 50 000 0000', cap: 'none' as const },
          { label: 'Country', value: country, set: setCountry, icon: Globe, placeholder: 'Azerbaijan', cap: 'words' as const },
        ].map(({ label, value, set, icon: Icon, placeholder, cap }) => (
          <View key={label} style={styles.field}>
            <Text style={styles.label}>{label}</Text>
            <View style={styles.inputWrap}>
              <Icon size={17} color={colors.textSecondary} strokeWidth={1.8} />
              <TextInput
                style={styles.input}
                value={value}
                onChangeText={set}
                placeholder={placeholder}
                placeholderTextColor={colors.textTertiary}
                autoCapitalize={cap}
              />
            </View>
          </View>
        ))}

        <TouchableOpacity
          style={styles.saveBtn}
          onPress={handleSave}
          disabled={saving}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={colors.gradientPrimary}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.saveBtnInner}
          >
            {saving
              ? <ActivityIndicator color="#fff" />
              : <Text style={styles.saveBtnText}>Save Changes</Text>
            }
          </LinearGradient>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingHorizontal: spacing.xl, paddingTop: 56, paddingBottom: 48 },
  backBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: colors.border, marginBottom: spacing.xl,
  },
  title: { ...typography.h1, color: colors.text, marginBottom: spacing.sm },
  subtitle: { color: colors.textSecondary, fontSize: 14, marginBottom: spacing.xl },
  avatarSection: { alignSelf: 'center', marginBottom: spacing.sm, position: 'relative' },
  avatar: { width: 96, height: 96, borderRadius: 48 },
  avatarFallback: { width: 96, height: 96, borderRadius: 48, alignItems: 'center', justifyContent: 'center' },
  avatarInitial: { color: '#fff', fontSize: 36, fontWeight: '700' },
  cameraBtn: {
    position: 'absolute', bottom: 0, right: 0,
    width: 30, height: 30, borderRadius: 15,
    backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: colors.background,
  },
  avatarHint: { color: colors.textTertiary, fontSize: 12, textAlign: 'center', marginBottom: spacing.xl },
  errorBox: {
    backgroundColor: 'rgba(255,59,48,0.12)', borderWidth: 1, borderColor: 'rgba(255,59,48,0.3)',
    borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md,
  },
  errorText: { color: colors.error, fontSize: 13 },
  successBox: {
    backgroundColor: 'rgba(52,199,89,0.12)', borderWidth: 1, borderColor: 'rgba(52,199,89,0.3)',
    borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md,
  },
  successText: { color: colors.success, fontSize: 13, textAlign: 'center' },
  field: { marginBottom: spacing.md },
  label: { color: colors.textSecondary, fontSize: 12, fontWeight: '600', marginBottom: spacing.sm, letterSpacing: 0.5, textTransform: 'uppercase' },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.md, paddingHorizontal: spacing.lg, paddingVertical: 14,
  },
  input: { flex: 1, color: colors.text, fontSize: 15 },
  saveBtn: { marginTop: spacing.lg, borderRadius: radius.full, overflow: 'hidden' },
  saveBtnInner: { paddingVertical: 16, alignItems: 'center', borderRadius: radius.full },
  saveBtnText: { ...typography.button, color: colors.text },
});
