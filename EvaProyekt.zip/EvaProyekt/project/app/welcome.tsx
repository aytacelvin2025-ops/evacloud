import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Platform,
  ScrollView,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Mail, Chrome, Github, Monitor, Facebook, Apple, User } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { AnimatedLogo } from '@/components/AnimatedLogo';
import { colors, spacing, radius, typography } from '@/constants/theme';

const { width, height } = Dimensions.get('window');

type SocialProvider = 'google' | 'apple' | 'facebook' | 'azure' | 'github';

const SOCIAL_BUTTONS: {
  label: string;
  icon: React.ComponentType<any>;
  color: string;
  provider?: SocialProvider;
  route?: string;
}[] = [
  { label: 'Continue with Google', icon: Chrome, color: '#EA4335', provider: 'google' },
  { label: 'Continue with Apple', icon: Apple, color: '#FFFFFF', provider: 'apple' },
  { label: 'Continue with Facebook', icon: Facebook, color: '#1877F2', provider: 'facebook' },
  { label: 'Continue with Microsoft', icon: Monitor, color: '#00A4EF', provider: 'azure' },
  { label: 'Continue with GitHub', icon: Github, color: '#FFFFFF', provider: 'github' },
  { label: 'Continue with Email', icon: Mail, color: colors.primary, route: '/(auth)/login' },
];

export default function WelcomeScreen() {
  const [oauthLoading, setOauthLoading] = useState<string | null>(null);
  const [error, setError] = useState('');

  const fadeIn = useRef(new Animated.Value(0)).current;
  const slideUp = useRef(new Animated.Value(24)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeIn, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideUp, { toValue: 0, tension: 50, friction: 10, useNativeDriver: true }),
    ]).start();
  }, []);

  async function handleSocialLogin(provider?: SocialProvider, route?: string) {
    if (route) {
      router.push(route as any);
      return;
    }
    if (!provider) return;

    setError('');
    setOauthLoading(provider);
    try {
      const redirectTo = Platform.OS === 'web' && typeof window !== 'undefined'
        ? `${window.location.origin}/`
        : 'myapp:///';
      const { error: err } = await supabase.auth.signInWithOAuth({
        provider,
        options: { redirectTo },
      });
      if (err) {
        setError(`${provider} sign-in failed: ${err.message}`);
      }
    } catch {
      setError('Connection error. Please try again.');
    } finally {
      setOauthLoading(null);
    }
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#020A16', '#000000']} style={StyleSheet.absoluteFill} />

      {/* Background glow */}
      <View style={styles.bgGlow} />

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        bounces={false}
      >
        <Animated.View style={{ opacity: fadeIn, transform: [{ translateY: slideUp }], alignItems: 'center' }}>
          {/* Animated EVA logo */}
          <View style={styles.logoSection}>
            <AnimatedLogo size={160} />
            <Text style={styles.tagline}>
              Your Life.{'\n'}Your Cloud.{'\n'}Your Control.
            </Text>
          </View>

          {!!error && (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          {/* Primary action buttons */}
          <View style={styles.primaryButtons}>
            <TouchableOpacity
              style={styles.primaryBtn}
              onPress={() => router.push('/(auth)/login')}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={colors.gradientPrimary}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.primaryBtnInner}
              >
                <Text style={styles.primaryBtnText}>Sign In</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.outlineBtn}
              onPress={() => router.push('/(auth)/register')}
              activeOpacity={0.85}
            >
              <Text style={styles.outlineBtnText}>Create Account</Text>
            </TouchableOpacity>
          </View>

          {/* Divider */}
          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or continue with</Text>
            <View style={styles.dividerLine} />
          </View>

          {/* Social login buttons */}
          <View style={styles.socialList}>
            {SOCIAL_BUTTONS.map((btn) => {
              const Icon = btn.icon;
              const isLoading = oauthLoading === btn.provider;
              return (
                <TouchableOpacity
                  key={btn.label}
                  style={styles.socialBtn}
                  onPress={() => handleSocialLogin(btn.provider, btn.route)}
                  disabled={!!oauthLoading}
                  activeOpacity={0.75}
                >
                  {isLoading
                    ? <ActivityIndicator size="small" color={btn.color} />
                    : <Icon size={20} color={btn.color} strokeWidth={1.8} />
                  }
                  <Text style={styles.socialBtnText}>{btn.label}</Text>
                </TouchableOpacity>
              );
            })}

            <TouchableOpacity
              style={styles.guestBtn}
              onPress={() => router.replace('/(tabs)')}
              activeOpacity={0.75}
            >
              <User size={17} color={colors.textTertiary} strokeWidth={1.8} />
              <Text style={styles.guestBtnText}>Continue as Guest (Limited Mode)</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.terms}>
            By continuing, you agree to our Terms of Service and Privacy Policy.
          </Text>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  bgGlow: {
    position: 'absolute',
    width: width * 0.8,
    height: height * 0.35,
    top: 0,
    alignSelf: 'center',
    backgroundColor: '#0A2050',
    opacity: 0.5,
    ...(Platform.OS === 'web' ? { filter: 'blur(80px)' } : {}),
  } as any,
  scroll: {
    paddingHorizontal: spacing.xl,
    paddingTop: 48,
    paddingBottom: 40,
    alignItems: 'center',
  },
  logoSection: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  tagline: {
    ...typography.h2,
    color: colors.text,
    textAlign: 'center',
    lineHeight: 36,
    letterSpacing: -0.5,
    marginTop: spacing.sm,
  },
  errorBox: {
    backgroundColor: 'rgba(255,59,48,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(255,59,48,0.3)',
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    width: '100%',
  },
  errorText: {
    color: colors.error,
    fontSize: 14,
    textAlign: 'center',
  },
  primaryButtons: {
    width: '100%',
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  primaryBtn: {
    borderRadius: radius.full,
    overflow: 'hidden',
  },
  primaryBtnInner: {
    paddingVertical: 16,
    alignItems: 'center',
    borderRadius: radius.full,
  },
  primaryBtnText: {
    ...typography.button,
    color: colors.text,
  },
  outlineBtn: {
    borderWidth: 1.5,
    borderColor: colors.borderHigh,
    borderRadius: radius.full,
    paddingVertical: 16,
    alignItems: 'center',
  },
  outlineBtnText: {
    ...typography.button,
    color: colors.text,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: colors.border,
  },
  dividerText: {
    color: colors.textSecondary,
    fontSize: 13,
    fontWeight: '500',
  },
  socialList: {
    width: '100%',
    gap: spacing.sm,
    marginBottom: spacing.xl,
  },
  socialBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingVertical: 14,
    paddingHorizontal: spacing.lg,
  },
  socialBtnText: {
    fontSize: 15,
    color: colors.text,
    fontWeight: '500',
  },
  guestBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
  },
  guestBtnText: {
    color: colors.textTertiary,
    fontSize: 13,
    fontWeight: '400',
  },
  terms: {
    color: colors.textTertiary,
    fontSize: 11,
    textAlign: 'center',
    lineHeight: 18,
    maxWidth: 280,
  },
});
