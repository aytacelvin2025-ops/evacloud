import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Switch,
  TouchableOpacity, Platform, Alert, ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowLeft, Cloud, Wifi, WifiOff, RefreshCw, Trash2, Settings, Camera, Image as ImageIcon, Check } from 'lucide-react-native';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';

type DbSettings = {
  auto_backup_enabled: boolean;
  wifi_only: boolean;
  backup_photos: boolean;
  backup_videos: boolean;
  backup_docs: boolean;
  camera_auto_upload: boolean;
};

export default function SettingsScreen() {
  const { user } = useAuth();
  const [autoBackup, setAutoBackup] = useState(true);
  const [wifiOnly, setWifiOnly] = useState(true);
  const [backupPhotos, setBackupPhotos] = useState(true);
  const [backupVideos, setBackupVideos] = useState(false);
  const [backupDocs, setBackupDocs] = useState(true);
  const [cameraAutoUpload, setCameraAutoUpload] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!user) return;
    loadSettings();
  }, [user]);

  async function loadSettings() {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        const db = data as DbSettings;
        setAutoBackup(db.auto_backup_enabled ?? false);
        setWifiOnly(db.wifi_only ?? true);
        setBackupPhotos(db.backup_photos ?? true);
        setBackupVideos(db.backup_videos ?? false);
        setBackupDocs(db.backup_docs ?? true);
        setCameraAutoUpload(db.camera_auto_upload ?? false);
      }
    } catch {}
    setLoading(false);
  }

  async function saveSettings(newSettings: Partial<DbSettings>) {
    if (!user) return;
    setSaving(true);
    setSaved(false);
    try {
      const { error } = await supabase
        .from('user_preferences')
        .upsert({
          user_id: user.id,
          auto_backup_enabled: newSettings.auto_backup_enabled ?? autoBackup,
          wifi_only: newSettings.wifi_only ?? wifiOnly,
          backup_photos: newSettings.backup_photos ?? backupPhotos,
          backup_videos: newSettings.backup_videos ?? backupVideos,
          backup_docs: newSettings.backup_docs ?? backupDocs,
          camera_auto_upload: newSettings.camera_auto_upload ?? cameraAutoUpload,
          updated_at: new Date().toISOString(),
        });

      if (!error) {
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
      }
    } catch {}
    setSaving(false);
  }

  function updateAutoBackup(val: boolean) {
    setAutoBackup(val);
    saveSettings({ auto_backup_enabled: val });
  }

  function updateWifiOnly(val: boolean) {
    setWifiOnly(val);
    saveSettings({ wifi_only: val });
  }

  function updateBackupPhotos(val: boolean) {
    setBackupPhotos(val);
    saveSettings({ backup_photos: val });
  }

  function updateBackupVideos(val: boolean) {
    setBackupVideos(val);
    saveSettings({ backup_videos: val });
  }

  function updateBackupDocs(val: boolean) {
    setBackupDocs(val);
    saveSettings({ backup_docs: val });
  }

  function updateCameraUpload(val: boolean) {
    setCameraAutoUpload(val);
    saveSettings({ camera_auto_upload: val });
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#030810', '#000000']} style={StyleSheet.absoluteFill} />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <ArrowLeft size={22} color={colors.text} strokeWidth={2} />
        </TouchableOpacity>

        <View style={styles.header}>
          <Settings size={28} color={colors.primary} strokeWidth={1.5} />
          <View style={styles.headerText}>
            <Text style={styles.title}>Settings</Text>
            {(saving || saved) && (
              <View style={styles.saveIndicator}>
                {saving ? (
                  <ActivityIndicator size="small" color={colors.primary} />
                ) : saved ? (
                  <View style={styles.savedBadge}>
                    <Check size={12} color={colors.success} strokeWidth={2.5} />
                    <Text style={styles.savedText}>Saved</Text>
                  </View>
                ) : null}
              </View>
            )}
          </View>
        </View>

        {loading ? (
          <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 40 }} />
        ) : (
        <>
        {/* Auto Backup */}
        <Text style={styles.groupTitle}>AUTO BACKUP</Text>
        <View style={styles.card}>
          <View style={styles.mainToggleRow}>
            <View style={styles.mainToggleLeft}>
              <Cloud size={22} color={autoBackup ? colors.primary : colors.textTertiary} strokeWidth={1.8} />
              <View>
                <Text style={styles.mainToggleLabel}>Enable Auto Backup</Text>
                <Text style={styles.mainToggleSub}>Automatically back up your files to EVA Cloud</Text>
              </View>
            </View>
            <Switch
              value={autoBackup}
              onValueChange={updateAutoBackup}
              trackColor={{ false: 'rgba(255,255,255,0.1)', true: colors.primary + '80' }}
              thumbColor={autoBackup ? colors.primary : 'rgba(255,255,255,0.4)'}
            />
          </View>

          {autoBackup && (
            <>
              <View style={styles.separator} />
              {[
                { label: 'Photos', icon: ImageIcon, value: backupPhotos, set: updateBackupPhotos, color: '#FF9F0A' },
                { label: 'Videos', icon: Camera, value: backupVideos, set: updateBackupVideos, color: '#FF3B30' },
                { label: 'Documents', icon: Cloud, value: backupDocs, set: updateBackupDocs, color: colors.primary },
              ].map(({ label, icon: Icon, value, set, color }, i) => (
                <View key={label}>
                  {i > 0 && <View style={styles.separator} />}
                  <View style={styles.subRow}>
                    <Icon size={16} color={color} strokeWidth={1.8} />
                    <Text style={styles.subLabel}>{label}</Text>
                    <Switch
                      value={value}
                      onValueChange={set}
                      trackColor={{ false: 'rgba(255,255,255,0.08)', true: color + '80' }}
                      thumbColor={value ? color : 'rgba(255,255,255,0.3)'}
                      style={{ transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }] }}
                    />
                  </View>
                </View>
              ))}
            </>
          )}
        </View>

        {/* Camera Roll */}
        <Text style={styles.groupTitle}>CAMERA ROLL</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <View style={[styles.iconWrap, { backgroundColor: '#FF9F0A18' }]}>
              <Camera size={18} color="#FF9F0A" strokeWidth={1.8} />
            </View>
            <View style={styles.rowContent}>
              <Text style={styles.rowLabel}>Auto Upload New Photos</Text>
              <Text style={styles.rowSub}>Upload new photos as soon as they are taken</Text>
            </View>
            <Switch
              value={cameraAutoUpload}
              onValueChange={updateCameraUpload}
              trackColor={{ false: 'rgba(255,255,255,0.1)', true: '#FF9F0A80' }}
              thumbColor={cameraAutoUpload ? '#FF9F0A' : 'rgba(255,255,255,0.4)'}
            />
          </View>
        </View>

        {/* Network */}
        <Text style={styles.groupTitle}>NETWORK</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <View style={[styles.iconWrap, { backgroundColor: colors.primary + '18' }]}>
              {wifiOnly ? <Wifi size={18} color={colors.primary} strokeWidth={1.8} /> : <WifiOff size={18} color={colors.textSecondary} />}
            </View>
            <View style={styles.rowContent}>
              <Text style={styles.rowLabel}>Wi-Fi Only</Text>
              <Text style={styles.rowSub}>Only backup and upload when connected to Wi-Fi</Text>
            </View>
            <Switch
              value={wifiOnly}
              onValueChange={updateWifiOnly}
              trackColor={{ false: 'rgba(255,255,255,0.1)', true: colors.primary + '80' }}
              thumbColor={wifiOnly ? colors.primary : 'rgba(255,255,255,0.4)'}
            />
          </View>
        </View>

        {/* Storage */}
        <Text style={styles.groupTitle}>STORAGE & DATA</Text>
        <View style={styles.card}>
          <TouchableOpacity style={styles.row} activeOpacity={0.75}>
            <View style={[styles.iconWrap, { backgroundColor: '#34C75918' }]}>
              <RefreshCw size={18} color="#34C759" strokeWidth={1.8} />
            </View>
            <View style={styles.rowContent}>
              <Text style={styles.rowLabel}>Clear Cache</Text>
              <Text style={styles.rowSub}>Free up local storage space</Text>
            </View>
          </TouchableOpacity>
          <View style={styles.separator} />
          <TouchableOpacity
            style={styles.row}
            activeOpacity={0.75}
            onPress={() => Alert.alert('Danger Zone', 'This will delete all your data. Contact support to proceed.')}
          >
            <View style={[styles.iconWrap, { backgroundColor: colors.error + '18' }]}>
              <Trash2 size={18} color={colors.error} strokeWidth={1.8} />
            </View>
            <View style={styles.rowContent}>
              <Text style={[styles.rowLabel, { color: colors.error }]}>Delete All Data</Text>
              <Text style={styles.rowSub}>Permanently delete all your files</Text>
            </View>
          </TouchableOpacity>
        </View>
        </>
        )}

        <Text style={styles.version}>EVA Cloud X v2.2.0 · Build 220</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingHorizontal: spacing.xl, paddingTop: 56, paddingBottom: 48 },
  backBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: colors.border, marginBottom: spacing.xl,
  },
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.xl },
  headerText: { flex: 1 },
  saveIndicator: { position: 'absolute', right: 0, top: 4 },
  savedBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(52,199,89,0.15)', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 12 },
  savedText: { color: colors.success, fontSize: 12, fontWeight: '600' },
  title: { ...typography.h1, color: colors.text },
  groupTitle: { color: colors.textTertiary, fontSize: 11, fontWeight: '600', letterSpacing: 1, marginBottom: spacing.md, marginTop: spacing.lg },
  card: {
    backgroundColor: colors.surface, borderRadius: radius.lg,
    borderWidth: 1, borderColor: colors.border, overflow: 'hidden',
    marginBottom: spacing.sm,
  },
  mainToggleRow: {
    flexDirection: 'row', alignItems: 'center', padding: spacing.lg, gap: spacing.md,
  },
  mainToggleLeft: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  mainToggleLabel: { color: colors.text, fontSize: 14, fontWeight: '600' },
  mainToggleSub: { color: colors.textSecondary, fontSize: 12, marginTop: 2, maxWidth: 220 },
  separator: { height: 1, backgroundColor: colors.border },
  subRow: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
  },
  subLabel: { flex: 1, color: colors.textSecondary, fontSize: 13 },
  row: { flexDirection: 'row', alignItems: 'center', padding: spacing.lg, gap: spacing.md },
  iconWrap: { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  rowContent: { flex: 1 },
  rowLabel: { color: colors.text, fontSize: 14, fontWeight: '500' },
  rowSub: { color: colors.textSecondary, fontSize: 12, marginTop: 2, lineHeight: 16 },
  version: { color: colors.textTertiary, fontSize: 12, textAlign: 'center', marginTop: spacing.xl },
});
