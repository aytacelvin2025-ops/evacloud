import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking, Platform } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowLeft, HelpCircle, ChevronDown, ChevronRight, Mail, MessageCircle, Shield, Info, User, Sparkles } from 'lucide-react-native';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { useLanguage } from '@/context/LanguageContext';

const WHATSAPP_NUMBER = '+994517571777';
const EMAIL_ADDRESS = 'elvinaliyev11@gmail.com';

export default function HelpScreen() {
  const { t } = useLanguage();
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const FAQ = [
    { q: t('faq_q1'), a: t('faq_a1') },
    { q: t('faq_q2'), a: t('faq_a2') },
    { q: t('faq_q3'), a: t('faq_a3') },
    { q: t('faq_q4'), a: t('faq_a4') },
    { q: t('faq_q5'), a: t('faq_a5') },
    { q: t('faq_q6'), a: t('faq_a6') },
    { q: t('faq_q7'), a: t('faq_a7') },
    { q: t('faq_q8'), a: t('faq_a8') },
  ];

  function openWhatsApp() {
    const num = WHATSAPP_NUMBER.replace(/[^0-9]/g, '');
    const url = Platform.OS === 'web'
      ? `https://wa.me/${num}`
      : `https://wa.me/${num}`;
    Linking.openURL(url).catch(() => {});
  }

  function openEmail() {
    Linking.openURL(`mailto:${EMAIL_ADDRESS}`).catch(() => {});
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#030810', '#000000']} style={StyleSheet.absoluteFill} />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <ArrowLeft size={22} color={colors.text} strokeWidth={2} />
        </TouchableOpacity>

        <View style={styles.header}>
          <HelpCircle size={28} color={colors.primary} strokeWidth={1.5} />
          <Text style={styles.title}>{t('help_support_title')}</Text>
        </View>
        <Text style={styles.subtitle}>{t('help_support_sub')}</Text>

        {/* About Us */}
        <Text style={styles.groupTitle}>{t('about_section')}</Text>
        <View style={styles.aboutCard}>
          <LinearGradient
            colors={['rgba(30,111,255,0.12)', 'rgba(0,212,255,0.06)']}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.aboutHeader}>
            <View style={styles.aboutLogoWrap}>
              <Sparkles size={22} color={colors.primary} strokeWidth={1.8} />
            </View>
            <View style={styles.aboutHeaderText}>
              <Text style={styles.aboutAppName}>{t('about_app_name')}</Text>
              <Text style={styles.aboutTagline}>{t('about_updates')}</Text>
            </View>
          </View>
          <View style={styles.aboutInfoRow}>
            <User size={15} color={colors.textSecondary} strokeWidth={1.8} />
            <Text style={styles.aboutInfoText}>{t('about_creator')}</Text>
          </View>
          <View style={styles.aboutInfoRow}>
            <Info size={15} color={colors.textSecondary} strokeWidth={1.8} />
            <Text style={styles.aboutInfoText}>{t('about_designer')}</Text>
          </View>
          <View style={styles.aboutInfoRow}>
            <Sparkles size={15} color={colors.textSecondary} strokeWidth={1.8} />
            <Text style={styles.aboutInfoText}>{t('about_ai')}</Text>
          </View>
          <Text style={styles.aboutRights}>{t('about_rights')}</Text>
        </View>

        {/* FAQ */}
        <Text style={styles.groupTitle}>{t('faq_title')}</Text>
        {FAQ.map((item, i) => (
          <TouchableOpacity
            key={i}
            style={styles.faqItem}
            onPress={() => setOpenFaq(openFaq === i ? null : i)}
            activeOpacity={0.8}
          >
            <View style={styles.faqHeader}>
              <Text style={styles.faqQ}>{item.q}</Text>
              {openFaq === i
                ? <ChevronDown size={18} color={colors.textSecondary} />
                : <ChevronRight size={18} color={colors.textSecondary} />
              }
            </View>
            {openFaq === i && (
              <Text style={styles.faqA}>{item.a}</Text>
            )}
          </TouchableOpacity>
        ))}

        {/* Contact */}
        <Text style={styles.groupTitle}>{t('contact_support_title')}</Text>
        <View style={styles.contactCard}>
          <TouchableOpacity style={styles.contactRow} activeOpacity={0.75} onPress={openEmail}>
            <View style={[styles.contactIcon, { backgroundColor: colors.primary + '18' }]}>
              <Mail size={20} color={colors.primary} strokeWidth={1.8} />
            </View>
            <View style={styles.contactContent}>
              <Text style={styles.contactLabel}>{t('contact_email')}</Text>
              <Text style={styles.contactSub}>{t('contact_email_sub')}</Text>
            </View>
            <ChevronRight size={16} color={colors.textTertiary} />
          </TouchableOpacity>
          <View style={styles.separator} />
          <TouchableOpacity style={styles.contactRow} activeOpacity={0.75} onPress={openWhatsApp}>
            <View style={[styles.contactIcon, { backgroundColor: '#34C75918' }]}>
              <MessageCircle size={20} color="#34C759" strokeWidth={1.8} />
            </View>
            <View style={styles.contactContent}>
              <Text style={styles.contactLabel}>{t('contact_chat')}</Text>
              <Text style={styles.contactSub}>{t('contact_chat_sub')}</Text>
            </View>
            <ChevronRight size={16} color={colors.textTertiary} />
          </TouchableOpacity>
          <View style={styles.separator} />
          <TouchableOpacity style={styles.contactRow} activeOpacity={0.75} onPress={() => router.push('/(tabs)/security')}>
            <View style={[styles.contactIcon, { backgroundColor: '#A066FF18' }]}>
              <Shield size={20} color="#A066FF" strokeWidth={1.8} />
            </View>
            <View style={styles.contactContent}>
              <Text style={styles.contactLabel}>{t('contact_security')}</Text>
              <Text style={styles.contactSub}>{t('contact_security_sub')}</Text>
            </View>
            <ChevronRight size={16} color={colors.textTertiary} />
          </TouchableOpacity>
        </View>

        {/* Updates / Changelog */}
        <Text style={styles.groupTitle}>YENİLƏMƏLƏR</Text>
        <TouchableOpacity style={styles.updatesCard} activeOpacity={0.8} onPress={() => router.push('/updates')}>
          <LinearGradient
            colors={['rgba(30,111,255,0.12)', 'rgba(0,212,255,0.06)']}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.updatesLeft}>
            <View style={styles.updatesIconWrap}>
              <Sparkles size={20} color={colors.primary} strokeWidth={1.8} />
            </View>
            <View style={styles.updatesInfo}>
              <Text style={styles.updatesTitle}>Versiya Tarixi və Planlar</Text>
              <Text style={styles.updatesSub}>v2.2.0 — 09.07.2026 tarixində yeniləndi</Text>
            </View>
          </View>
          <View style={styles.newBadge}>
            <Text style={styles.newBadgeText}>YENİ</Text>
          </View>
        </TouchableOpacity>

        <Text style={styles.version}>{t('version_footer')}</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingHorizontal: spacing.xl, paddingTop: 56, paddingBottom: 48 },
  backBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: colors.border, marginBottom: spacing.xl,
  },
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.sm },
  title: { ...typography.h1, color: colors.text },
  subtitle: { color: colors.textSecondary, fontSize: 14, marginBottom: spacing.xl },
  groupTitle: { color: colors.textTertiary, fontSize: 11, fontWeight: '600', letterSpacing: 1, marginBottom: spacing.md, marginTop: spacing.lg },
  aboutCard: {
    borderRadius: radius.lg,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.25)',
    padding: spacing.lg, marginBottom: spacing.sm, overflow: 'hidden',
  },
  aboutHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.md },
  aboutLogoWrap: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: 'rgba(30,111,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)',
  },
  aboutHeaderText: { flex: 1 },
  aboutAppName: { color: colors.text, fontSize: 16, fontWeight: '700' },
  aboutTagline: { color: colors.textSecondary, fontSize: 12, marginTop: 2, lineHeight: 17 },
  aboutInfoRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: 6 },
  aboutInfoText: { color: colors.textSecondary, fontSize: 13 },
  aboutRights: { color: colors.textTertiary, fontSize: 11, marginTop: spacing.sm, textAlign: 'right' },
  faqItem: {
    backgroundColor: colors.surface, borderRadius: radius.md,
    borderWidth: 1, borderColor: colors.border, padding: spacing.lg,
    marginBottom: spacing.sm,
  },
  faqHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  faqQ: { flex: 1, color: colors.text, fontSize: 14, fontWeight: '500', lineHeight: 20 },
  faqA: { color: colors.textSecondary, fontSize: 13, lineHeight: 20, marginTop: spacing.md },
  contactCard: {
    backgroundColor: colors.surface, borderRadius: radius.lg,
    borderWidth: 1, borderColor: colors.border, overflow: 'hidden',
  },
  contactRow: { flexDirection: 'row', alignItems: 'center', padding: spacing.lg, gap: spacing.md },
  contactIcon: { width: 40, height: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  contactContent: { flex: 1 },
  contactLabel: { color: colors.text, fontSize: 14, fontWeight: '500' },
  contactSub: { color: colors.textSecondary, fontSize: 12, marginTop: 2 },
  separator: { height: 1, backgroundColor: colors.border },
  version: { color: colors.textTertiary, fontSize: 12, textAlign: 'center', marginTop: spacing.xxl },
  updatesCard: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderRadius: radius.lg, padding: spacing.lg, marginBottom: spacing.md,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.25)', overflow: 'hidden',
  },
  updatesLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, flex: 1 },
  updatesIconWrap: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: 'rgba(30,111,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)',
  },
  updatesInfo: { flex: 1 },
  updatesTitle: { color: colors.text, fontSize: 14, fontWeight: '600', marginBottom: 2 },
  updatesSub: { color: colors.textSecondary, fontSize: 12 },
  newBadge: {
    backgroundColor: colors.primary, paddingHorizontal: 10, paddingVertical: 3,
    borderRadius: radius.sm,
  },
  newBadgeText: { color: '#fff', fontSize: 10, fontWeight: '700', letterSpacing: 0.5 },
});
