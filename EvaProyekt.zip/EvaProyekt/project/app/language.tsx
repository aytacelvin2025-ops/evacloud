import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowLeft, Check } from 'lucide-react-native';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { useLanguage, Lang } from '@/context/LanguageContext';

const LANGUAGES = [
  { code: 'az' as Lang, name: 'Azerbaijani', native: 'Azərbaycan dili' },
  { code: 'en' as Lang, name: 'English', native: 'English' },
  { code: 'ru' as Lang, name: 'Russian', native: 'Русский' },
  { code: 'tr' as Lang, name: 'Turkish', native: 'Türkçe' },
  { code: 'de' as Lang, name: 'German', native: 'Deutsch' },
  { code: 'fr' as Lang, name: 'French', native: 'Français' },
  { code: 'es' as Lang, name: 'Spanish', native: 'Español' },
  { code: 'ar' as Lang, name: 'Arabic', native: 'العربية' },
  { code: 'zh' as Lang, name: 'Chinese', native: '中文' },
  { code: 'ja' as Lang, name: 'Japanese', native: '日本語' },
];

export default function LanguageScreen() {
  const { lang, setLang, t } = useLanguage();

  function handleSelect(code: Lang) {
    setLang(code);
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#030810', '#000000']} style={StyleSheet.absoluteFill} />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <ArrowLeft size={22} color={colors.text} strokeWidth={2} />
        </TouchableOpacity>

        <Text style={styles.title}>{t('language')}</Text>
        <Text style={styles.subtitle}>{t('select_preferred_language') || 'Select your preferred language'}</Text>

        <View style={styles.card}>
          {LANGUAGES.map((l, i) => (
            <View key={l.code}>
              {i > 0 && <View style={styles.separator} />}
              <TouchableOpacity
                style={styles.langRow}
                onPress={() => handleSelect(l.code)}
                activeOpacity={0.75}
              >
                <View style={styles.langContent}>
                  <Text style={styles.langName}>{l.name}</Text>
                  <Text style={styles.langNative}>{l.native}</Text>
                </View>
                {lang === l.code && (
                  <Check size={20} color={colors.primary} strokeWidth={2.5} />
                )}
              </TouchableOpacity>
            </View>
          ))}
        </View>

        <Text style={styles.note}>
          {t('language_saved_automatically') || 'Language selection is saved automatically.'}
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingHorizontal: spacing.xl, paddingTop: 56, paddingBottom: 48 },
  backBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: colors.border, marginBottom: spacing.xl,
  },
  title: { ...typography.h1, color: colors.text, marginBottom: spacing.sm },
  subtitle: { color: colors.textSecondary, fontSize: 14, marginBottom: spacing.xl },
  card: {
    backgroundColor: colors.surface, borderRadius: radius.lg,
    borderWidth: 1, borderColor: colors.border, overflow: 'hidden',
  },
  separator: { height: 1, backgroundColor: colors.border },
  langRow: { flexDirection: 'row', alignItems: 'center', padding: spacing.lg },
  langContent: { flex: 1 },
  langName: { color: colors.text, fontSize: 15, fontWeight: '500' },
  langNative: { color: colors.textSecondary, fontSize: 12, marginTop: 2 },
  note: { color: colors.textTertiary, fontSize: 12, textAlign: 'center', marginTop: spacing.xl, lineHeight: 18 },
});
