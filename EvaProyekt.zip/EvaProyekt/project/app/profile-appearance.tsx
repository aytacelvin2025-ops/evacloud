import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowLeft, Moon, Sun, Monitor, Check } from 'lucide-react-native';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';

const THEMES = [
  { key: 'dark', label: 'Dark', sub: 'Dark background, recommended', icon: Moon, color: colors.primary },
  { key: 'light', label: 'Light', sub: 'Light background', icon: Sun, color: '#F59E0B' },
  { key: 'system', label: 'System', sub: 'Follow device setting', icon: Monitor, color: colors.textSecondary },
];

const ACCENT_COLORS = [
  { key: 'blue', color: '#1E6FFF', label: 'Blue' },
  { key: 'cyan', color: '#00D4FF', label: 'Cyan' },
  { key: 'green', color: '#34C759', label: 'Green' },
  { key: 'orange', color: '#FF9F0A', label: 'Orange' },
  { key: 'red', color: '#FF3B30', label: 'Red' },
  { key: 'purple', color: '#A066FF', label: 'Purple' },
];

const FONT_SIZES = ['small', 'default', 'large'];

type AppearanceSettings = {
  theme: string;
  accent_color: string;
  font_size: string;
};

export default function AppearanceScreen() {
  const { user } = useAuth();
  const [theme, setTheme] = useState('dark');
  const [accent, setAccent] = useState('blue');
  const [fontSize, setFontSize] = useState('default');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!user) return;
    loadSettings();
  }, [user]);

  async function loadSettings() {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('user_preferences')
        .select('theme, accent_color, font_size')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setTheme(data.theme ?? 'dark');
        setAccent(data.accent_color ?? 'blue');
        setFontSize(data.font_size ?? 'default');
      }
    } catch {}
    setLoading(false);
  }

  async function saveSettings(newSettings: Partial<AppearanceSettings>) {
    if (!user) return;
    setSaving(true);
    setSaved(false);
    try {
      const { error } = await supabase
        .from('user_preferences')
        .upsert({
          user_id: user.id,
          theme: newSettings.theme ?? theme,
          accent_color: newSettings.accent_color ?? accent,
          font_size: newSettings.font_size ?? fontSize,
          updated_at: new Date().toISOString(),
        });

      if (!error) {
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
      }
    } catch {}
    setSaving(false);
  }

  function updateTheme(val: string) {
    setTheme(val);
    saveSettings({ theme: val });
  }

  function updateAccent(val: string) {
    setAccent(val);
    saveSettings({ accent_color: val });
  }

  function updateFontSize(val: string) {
    setFontSize(val);
    saveSettings({ font_size: val });
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#030810', '#000000']} style={StyleSheet.absoluteFill} />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <ArrowLeft size={22} color={colors.text} strokeWidth={2} />
        </TouchableOpacity>

        <View style={styles.header}>
          <Text style={styles.title}>Appearance</Text>
          {(saving || saved) && (
            <View style={styles.saveIndicator}>
              {saving ? (
                <ActivityIndicator size="small" color={colors.primary} />
              ) : saved ? (
                <View style={styles.savedBadge}>
                  <Check size={12} color={colors.success} strokeWidth={2.5} />
                  <Text style={styles.savedText}>Saved</Text>
                </View>
              ) : null}
            </View>
          )}
        </View>
        <Text style={styles.subtitle}>Customize the look and feel of the app</Text>

        {loading ? (
          <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 40 }} />
        ) : (
        <>
        <Text style={styles.groupTitle}>THEME</Text>
        <View style={styles.themeGrid}>
          {THEMES.map(t => {
            const Icon = t.icon;
            const isSelected = theme === t.key;
            return (
              <TouchableOpacity
                key={t.key}
                style={[styles.themeCard, isSelected && styles.themeCardSelected]}
                onPress={() => updateTheme(t.key)}
                activeOpacity={0.8}
              >
                {isSelected && (
                  <LinearGradient
                    colors={['rgba(30,111,255,0.15)', 'transparent']}
                    style={StyleSheet.absoluteFill}
                  />
                )}
                <View style={[styles.themeIcon, { backgroundColor: t.color + '18' }]}>
                  <Icon size={22} color={t.color} strokeWidth={1.8} />
                </View>
                <Text style={[styles.themeLabel, isSelected && { color: colors.primary }]}>{t.label}</Text>
                <Text style={styles.themeSub}>{t.sub}</Text>
                {isSelected && <View style={styles.selectedDot} />}
              </TouchableOpacity>
            );
          })}
        </View>

        <Text style={styles.groupTitle}>ACCENT COLOR</Text>
        <View style={styles.colorGrid}>
          {ACCENT_COLORS.map(c => (
            <TouchableOpacity
              key={c.key}
              style={[styles.colorBtn, { backgroundColor: c.color }, accent === c.key && styles.colorBtnSelected]}
              onPress={() => updateAccent(c.key)}
              activeOpacity={0.8}
            >
              {accent === c.key && <View style={styles.colorCheck} />}
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.groupTitle}>FONT SIZE</Text>
        <View style={styles.fontRow}>
          {['Small', 'Default', 'Large'].map((size, i) => {
            const fontKey = FONT_SIZES[i];
            const isSelected = fontSize === fontKey;
            return (
              <TouchableOpacity
                key={size}
                style={[styles.fontBtn, isSelected && styles.fontBtnActive]}
                onPress={() => updateFontSize(fontKey)}
                activeOpacity={0.8}
              >
                <Text style={[styles.fontBtnText, isSelected && styles.fontBtnTextActive, { fontSize: 11 + i * 2 }]}>Aa</Text>
                <Text style={[styles.fontLabel, isSelected && { color: colors.primary }]}>{size}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
        </>
        )}

        <Text style={styles.note}>Theme and color changes will be applied in a future update for the native app.</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingHorizontal: spacing.xl, paddingTop: 56, paddingBottom: 48 },
  backBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: colors.border, marginBottom: spacing.xl,
  },
  title: { ...typography.h1, color: colors.text, marginBottom: spacing.sm },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: spacing.sm },
  saveIndicator: { position: 'absolute', right: 0, top: 4 },
  savedBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(52,199,89,0.15)', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 12 },
  savedText: { color: colors.success, fontSize: 12, fontWeight: '600' },
  subtitle: { color: colors.textSecondary, fontSize: 14, marginBottom: spacing.xl },
  groupTitle: { color: colors.textTertiary, fontSize: 11, fontWeight: '600', letterSpacing: 1, marginBottom: spacing.md, marginTop: spacing.lg },
  themeGrid: { flexDirection: 'row', gap: spacing.md, marginBottom: spacing.sm },
  themeCard: {
    flex: 1, backgroundColor: colors.surface, borderRadius: radius.lg,
    borderWidth: 1, borderColor: colors.border, padding: spacing.md,
    alignItems: 'center', gap: spacing.sm, overflow: 'hidden',
  },
  themeCardSelected: { borderColor: colors.primary },
  themeIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  themeLabel: { color: colors.text, fontSize: 13, fontWeight: '600' },
  themeSub: { color: colors.textTertiary, fontSize: 10, textAlign: 'center' },
  selectedDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary },
  colorGrid: { flexDirection: 'row', gap: spacing.md, marginBottom: spacing.sm, flexWrap: 'wrap' },
  colorBtn: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  colorBtnSelected: { borderWidth: 3, borderColor: '#fff' },
  colorCheck: { width: 14, height: 14, borderRadius: 7, backgroundColor: '#fff' },
  fontRow: { flexDirection: 'row', gap: spacing.md },
  fontBtn: {
    flex: 1, backgroundColor: colors.surface, borderRadius: radius.md,
    borderWidth: 1, borderColor: colors.border, padding: spacing.md,
    alignItems: 'center', gap: spacing.sm,
  },
  fontBtnActive: { borderColor: colors.primary },
  fontBtnText: { color: colors.textSecondary },
  fontBtnTextActive: { color: colors.primary },
  fontLabel: { color: colors.textSecondary, fontSize: 11 },
  note: { color: colors.textTertiary, fontSize: 12, textAlign: 'center', marginTop: spacing.xl, lineHeight: 18 },
});
