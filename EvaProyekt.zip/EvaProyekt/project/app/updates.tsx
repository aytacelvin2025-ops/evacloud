import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking, Platform } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
  ArrowLeft, Sparkles, CheckCircle, Clock, Zap, Cloud, Shield,
  Download, Bot, Trash2, Image as ImageIcon, ChevronDown, ChevronRight,
  Star, Bell, Lock, HardDrive, Smartphone, Play, Film, Music, FileText,
  Maximize, Minimize, PictureInPicture2,
} from 'lucide-react-native';
import { colors, spacing, radius, typography } from '@/constants/theme';

type UpdateItem = {
  icon: React.ComponentType<any>;
  color: string;
  title: string;
  desc: string;
};

type VersionEntry = {
  version: string;
  date: string;
  type: 'major' | 'minor' | 'patch';
  items: UpdateItem[];
};

const VERSIONS: VersionEntry[] = [
  {
    version: '2.2.0',
    date: '09.07.2026',
    type: 'major',
    items: [
      { icon: Play, color: '#FF2D55', title: 'Pleyerlər Bölməsi', desc: 'Menyuya tam yeni pleyerlər bölməsi əlavə edildi — video, musiqi, qalereya və sənəd görüntüleyici' },
      { icon: Film, color: '#FF3B30', title: 'Yeni Nəsil Video Pleyer', desc: 'Tam ekran, pəncərə rejimi, arxa fona almaq (PiP), sürət nizamlaması, pleylist və avtomatik thumbnail' },
      { icon: Music, color: '#34C759', title: 'Musiqi Pleyer', desc: 'Fırlanan albart, qarışdırma (shuffle), təkrar rejimi, pleylist, səs və vaxt idarəsi' },
      { icon: ImageIcon, color: '#FF9F0A', title: 'Qalereya Görüntüleyici', desc: 'Şəbəkə görünüşü, zoom, tam ekran, sürüşdürmə ilə keçid və paylaşma' },
      { icon: FileText, color: colors.primary, title: 'Sənəd Görüntüleyici', desc: 'PDF, Word, Excel, PowerPoint və mətn faylları üçün dəstək, Google Docs inteqrasiyası' },
      { icon: Maximize, color: colors.secondary, title: 'Pəncərə İdarəsi', desc: 'Bütün pleyerlərdə kiçildib kənara qoyma, tam ekran, arxa fona almaq və bağlama düymələri' },
      { icon: Zap, color: colors.warning, title: 'Performans və Stabillik', desc: 'Asset optimallaşdırması, MIME xətası düzəldildi, build sürəti artırıldı' },
    ],
  },
  {
    version: '2.1.0',
    date: '08.07.2026',
    type: 'major',
    items: [
      { icon: Download, color: colors.primary, title: 'Müasir Endirmə Sistemi', desc: 'Fayllar artıq doğru formatda, avtomatik uzantı ilə və endirmə prosesi zamanı faiz göstəricisi ilə endirilir' },
      { icon: Bot, color: '#A066FF', title: 'EVA AI Yenilənməsi', desc: '20+ yeni mövzu, sürətli əmr çipləri, daha ağıllı və insan kimi cavablar əlavə olundu' },
      { icon: Zap, color: colors.warning, title: 'Performans Optimallaşdırması', desc: 'Açılış sürəti 2x artırıldı, video thumbnail donması düzəldildi, fayl yükləmə optimallaşdırıldı' },
      { icon: Sparkles, color: colors.secondary, title: 'Yeniləmə Mərkəzi', desc: 'Versiya tarixi, gələcək planlar və dəyişiklik jurnalı əlavə olundu' },
    ],
  },
  {
    version: '2.0.0',
    date: '01.07.2026',
    type: 'major',
    items: [
      { icon: Cloud, color: colors.primary, title: 'EVA Cloud X Lansman', desc: 'Tamamilen yenidən dizayn edilmiş bulud yaddaş proqramı' },
      { icon: Shield, color: colors.success, title: 'AES-256 Şifrələmə', desc: 'Bütün fayllar hər səviyyədə şifrələnir' },
      { icon: ImageIcon, color: '#FF9F0A', title: 'Şəbəkə Görünüşü', desc: 'Şəkillər və videolar üçün qalereya stili görünüş' },
      { icon: Trash2, color: colors.error, title: 'Zibil Qutusu', desc: 'Silinmiş faylları bərpa etmə və avtomatik silinmə' },
      { icon: Bot, color: '#A066FF', title: 'EVA AI Köməkçisi', desc: 'Süni intellekt əsaslı köməkçi' },
      { icon: Lock, color: colors.secondary, title: 'Təhlükəsizlik Mərkəzi', desc: 'Aktiv sessiyalar, şifrə dəyişmə, 2FA' },
    ],
  },
];

const ROADMAP = [
  { icon: HardDrive, color: colors.primary, title: 'Limitsiz Yaddaş', desc: 'Premium plan ilə limitsiz bulud yaddaş', eta: 'Planlaşdırılır' },
  { icon: Smartphone, color: colors.secondary, title: 'Mobil Tətbiq', desc: 'iOS və Android üçün native tətbiq', eta: 'İnkişaf mərhələsində' },
  { icon: Bell, color: colors.warning, title: 'Real-vaxt Bildirişlər', desc: 'Push bildirişləri və real-vaxt sinxronizasiya', eta: 'Planlaşdırılır' },
  { icon: Star, color: '#A066FF', title: 'Ağıllı Kateqoriya', desc: 'AI əsaslı avtomatik fayl təsnifatı', eta: 'Tədqiq edilir' },
  { icon: Cloud, color: colors.success, title: 'Offline Rejim', desc: 'İnternet olmadan fayl görüntüləmə', eta: 'Planlaşdırılır' },
  { icon: Shield, color: colors.error, title: 'Biometrik Giriş', desc: 'Barmaq izi və Face ID ilə giriş', eta: 'İnkişaf mərhələsində' },
];

export default function UpdatesScreen() {
  const [expanded, setExpanded] = useState<string | null>('2.2.0');

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#030810', '#000000']} style={StyleSheet.absoluteFill} />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <ArrowLeft size={22} color={colors.text} strokeWidth={2} />
        </TouchableOpacity>

        <View style={styles.header}>
          <Sparkles size={28} color={colors.primary} strokeWidth={1.5} />
          <Text style={styles.title}>Yeniləmələr</Text>
        </View>
        <Text style={styles.subtitle}>Versiya tarixi və gələcək planlar</Text>

        {/* Current version badge */}
        <View style={styles.currentVersionCard}>
          <LinearGradient
            colors={['rgba(30,111,255,0.15)', 'rgba(0,212,255,0.05)']}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.currentVersionLeft}>
            <View style={styles.versionIconWrap}>
              <Zap size={24} color={colors.primary} strokeWidth={1.8} />
            </View>
            <View>
              <Text style={styles.currentVersionLabel}>Cari Versiya</Text>
              <Text style={styles.currentVersionNum}>v2.2.0</Text>
            </View>
          </View>
          <View style={styles.currentVersionRight}>
            <View style={styles.newBadge}>
              <Text style={styles.newBadgeText}>YENİ</Text>
            </View>
            <Text style={styles.currentVersionDate}>09.07.2026</Text>
          </View>
        </View>

        {/* Version history */}
        <Text style={styles.groupTitle}>VERSİYA TARİXİ</Text>
        {VERSIONS.map(ver => {
          const isExpanded = expanded === ver.version;
          return (
            <View key={ver.version} style={styles.versionCard}>
              <TouchableOpacity
                style={styles.versionHeader}
                onPress={() => setExpanded(isExpanded ? null : ver.version)}
                activeOpacity={0.8}
              >
                <View style={styles.versionHeaderLeft}>
                  <View style={[styles.versionTypeDot, { backgroundColor: ver.type === 'major' ? colors.primary : ver.type === 'minor' ? colors.secondary : colors.success }]} />
                  <Text style={styles.versionNumber}>v{ver.version}</Text>
                  <Text style={styles.versionDate}>{ver.date}</Text>
                </View>
                {isExpanded
                  ? <ChevronDown size={18} color={colors.textSecondary} strokeWidth={2} />
                  : <ChevronRight size={18} color={colors.textSecondary} strokeWidth={2} />
                }
              </TouchableOpacity>

              {isExpanded && (
                <View style={styles.versionItems}>
                  {ver.items.map((item, i) => {
                    const Icon = item.icon;
                    return (
                      <View key={i} style={styles.versionItem}>
                        <View style={[styles.versionItemIcon, { backgroundColor: item.color + '18' }]}>
                          <Icon size={16} color={item.color} strokeWidth={1.8} />
                        </View>
                        <View style={styles.versionItemInfo}>
                          <Text style={styles.versionItemTitle}>{item.title}</Text>
                          <Text style={styles.versionItemDesc}>{item.desc}</Text>
                        </View>
                        <CheckCircle size={14} color={colors.success} strokeWidth={2} />
                      </View>
                    );
                  })}
                </View>
              )}
            </View>
          );
        })}

        {/* Roadmap */}
        <Text style={styles.groupTitle}>GƏLƏCƏK PLANLAR</Text>
        <View style={styles.roadmapGrid}>
          {ROADMAP.map((item, i) => {
            const Icon = item.icon;
            return (
              <View key={i} style={styles.roadmapCard}>
                <View style={[styles.roadmapIcon, { backgroundColor: item.color + '18' }]}>
                  <Icon size={20} color={item.color} strokeWidth={1.8} />
                </View>
                <Text style={styles.roadmapTitle}>{item.title}</Text>
                <Text style={styles.roadmapDesc}>{item.desc}</Text>
                <View style={styles.roadmapEta}>
                  <Clock size={10} color={colors.textTertiary} strokeWidth={1.8} />
                  <Text style={styles.roadmapEtaText}>{item.eta}</Text>
                </View>
              </View>
            );
          })}
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>EVA Cloud X v2.2.0</Text>
          <Text style={styles.footerSub}>Elvin Əliyev tərəfindən hazırlanmışdır</Text>
          <Text style={styles.footerRights}>Bütün hüquqlar qorunur © 2026</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingHorizontal: spacing.xl, paddingTop: 56, paddingBottom: 48 },
  backBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: colors.border, marginBottom: spacing.xl,
  },
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.sm },
  title: { ...typography.h1, color: colors.text },
  subtitle: { color: colors.textSecondary, fontSize: 14, marginBottom: spacing.xl },
  currentVersionCard: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderRadius: radius.xl, padding: spacing.lg, marginBottom: spacing.xl,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)', overflow: 'hidden',
  },
  currentVersionLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  versionIconWrap: {
    width: 48, height: 48, borderRadius: 12,
    backgroundColor: 'rgba(30,111,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)',
  },
  currentVersionLabel: { color: colors.textSecondary, fontSize: 12 },
  currentVersionNum: { color: colors.text, fontSize: 22, fontWeight: '700' },
  currentVersionRight: { alignItems: 'flex-end' },
  newBadge: {
    backgroundColor: colors.primary, paddingHorizontal: 10, paddingVertical: 3,
    borderRadius: radius.sm, marginBottom: 4,
  },
  newBadgeText: { color: '#fff', fontSize: 10, fontWeight: '700', letterSpacing: 0.5 },
  currentVersionDate: { color: colors.textTertiary, fontSize: 12 },
  groupTitle: { color: colors.textTertiary, fontSize: 11, fontWeight: '600', letterSpacing: 1, marginBottom: spacing.md, marginTop: spacing.lg },
  versionCard: {
    backgroundColor: colors.surface, borderRadius: radius.lg,
    borderWidth: 1, borderColor: colors.border, marginBottom: spacing.sm, overflow: 'hidden',
  },
  versionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: spacing.lg },
  versionHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  versionTypeDot: { width: 10, height: 10, borderRadius: 5 },
  versionNumber: { color: colors.text, fontSize: 16, fontWeight: '700' },
  versionDate: { color: colors.textTertiary, fontSize: 13 },
  versionItems: { paddingHorizontal: spacing.lg, paddingBottom: spacing.lg, gap: spacing.md },
  versionItem: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.md },
  versionItemIcon: {
    width: 36, height: 36, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center', marginTop: 2,
  },
  versionItemInfo: { flex: 1 },
  versionItemTitle: { color: colors.text, fontSize: 14, fontWeight: '600', marginBottom: 2 },
  versionItemDesc: { color: colors.textSecondary, fontSize: 12, lineHeight: 18 },
  roadmapGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  roadmapCard: {
    flex: 1, minWidth: '47%', backgroundColor: colors.surface,
    borderRadius: radius.lg, padding: spacing.lg, borderWidth: 1, borderColor: colors.border,
  },
  roadmapIcon: {
    width: 44, height: 44, borderRadius: 12,
    alignItems: 'center', justifyContent: 'center', marginBottom: spacing.sm,
  },
  roadmapTitle: { color: colors.text, fontSize: 14, fontWeight: '600', marginBottom: 4 },
  roadmapDesc: { color: colors.textSecondary, fontSize: 12, lineHeight: 17, marginBottom: spacing.sm },
  roadmapEta: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  roadmapEtaText: { color: colors.textTertiary, fontSize: 11, fontWeight: '500' },
  footer: { alignItems: 'center', marginTop: spacing.xxl, gap: 4 },
  footerText: { color: colors.text, fontSize: 14, fontWeight: '600' },
  footerSub: { color: colors.textSecondary, fontSize: 12 },
  footerRights: { color: colors.textTertiary, fontSize: 11 },
});
