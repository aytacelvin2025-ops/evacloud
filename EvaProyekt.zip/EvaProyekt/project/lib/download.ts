import { Platform } from 'react-native';
import { FileRecord } from './files';

export type DownloadProgress = {
  loaded: number;
  total: number;
  percent: number;
};

export type DownloadResult = {
  success: boolean;
  error?: string;
  url?: string;
};

/**
 * Get the proper file extension from mime type
 */
function getExtensionFromMime(mimeType: string): string {
  const map: Record<string, string> = {
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/png': 'png',
    'image/gif': 'gif',
    'image/webp': 'webp',
    'image/svg+xml': 'svg',
    'image/bmp': 'bmp',
    'image/tiff': 'tiff',
    'video/mp4': 'mp4',
    'video/webm': 'webm',
    'video/quicktime': 'mov',
    'video/x-msvideo': 'avi',
    'video/x-matroska': 'mkv',
    'audio/mpeg': 'mp3',
    'audio/mp3': 'mp3',
    'audio/wav': 'wav',
    'audio/ogg': 'ogg',
    'audio/aac': 'aac',
    'audio/flac': 'flac',
    'audio/x-m4a': 'm4a',
    'audio/mp4': 'm4a',
    'application/pdf': 'pdf',
    'application/msword': 'doc',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
    'application/vnd.ms-excel': 'xls',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
    'application/vnd.ms-powerpoint': 'ppt',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
    'text/plain': 'txt',
    'text/csv': 'csv',
    'text/html': 'html',
    'application/zip': 'zip',
    'application/x-rar-compressed': 'rar',
    'application/x-7z-compressed': '7z',
    'application/json': 'json',
    'application/xml': 'xml',
  };
  return map[mimeType] ?? '';
}

/**
 * Ensure filename has the correct extension
 */
function ensureExtension(name: string, mimeType: string): string {
  const hasExt = /\.[a-z0-9]{2,5}$/i.test(name);
  if (hasExt) return name;
  const ext = getExtensionFromMime(mimeType);
  return ext ? `${name}.${ext}` : name;
}

/**
 * Modern file download with fetch + blob, proper progress tracking, and correct format.
 * On web: fetches the file as a blob, creates an object URL, and triggers download
 * with the correct filename and extension.
 * On native: opens the URL in the browser (expo-linking fallback).
 */
export async function downloadFileModern(
  file: FileRecord,
  onProgress?: (p: DownloadProgress) => void
): Promise<DownloadResult> {
  if (!file.storage_url) {
    return { success: false, error: 'No download URL available' };
  }

  const fileName = ensureExtension(file.name, file.mime_type);

  try {
    if (Platform.OS === 'web') {
      // Fetch with progress tracking
      const response = await fetch(file.storage_url);
      if (!response.ok) {
        return { success: false, error: `Download failed: ${response.status}` };
      }

      const contentLength = response.headers.get('content-length');
      const total = contentLength ? parseInt(contentLength, 10) : file.size || 0;

      // If we can read the stream, track progress
      if (response.body && response.body.getReader) {
        const reader = response.body.getReader();
        const chunks: Uint8Array[] = [];
        let loaded = 0;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            chunks.push(value);
            loaded += value.length;
            if (onProgress) {
              onProgress({
                loaded,
                total,
                percent: total > 0 ? (loaded / total) * 100 : 0,
              });
            }
          }
        }

        const blob = new Blob(chunks as BlobPart[], { type: file.mime_type });
        triggerBrowserDownload(blob, fileName);
        return { success: true };
      }

      // Fallback: no stream support, just get blob
      const blob = await response.blob();
      triggerBrowserDownload(blob, fileName);
      return { success: true };
    }

    // Native: open URL in browser
    try {
      const { openURL } = await import('expo-linking');
      await openURL(file.storage_url);
      return { success: true, url: file.storage_url };
    } catch {
      return { success: false, error: 'Could not open download URL' };
    }
  } catch (err: any) {
    return { success: false, error: err.message ?? 'Download failed' };
  }
}

/**
 * Trigger browser download from a blob with proper filename
 */
function triggerBrowserDownload(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.style.display = 'none';
  a.target = '_self';
  document.body.appendChild(a);
  a.click();

  // Clean up
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 100);
}

/**
 * Download multiple files sequentially with progress callback
 */
export async function downloadMultipleFiles(
  files: FileRecord[],
  onFileProgress?: (file: FileRecord, p: DownloadProgress) => void,
  onFileComplete?: (file: FileRecord, success: boolean) => void,
): Promise<{ succeeded: number; failed: number }> {
  let succeeded = 0;
  let failed = 0;

  for (const file of files) {
    const result = await downloadFileModern(file, (p) => onFileProgress?.(file, p));
    if (result.success) {
      succeeded++;
      onFileComplete?.(file, true);
    } else {
      failed++;
      onFileComplete?.(file, false);
    }
    // Small delay between downloads
    await new Promise(r => setTimeout(r, 300));
  }

  return { succeeded, failed };
}
