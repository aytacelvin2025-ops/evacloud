import { supabase } from './supabase';
import { Platform } from 'react-native';

export type FileRecord = {
  id: string;
  user_id: string;
  name: string;
  size: number;
  mime_type: string;
  category: 'photos' | 'videos' | 'documents' | 'music' | 'other';
  storage_path: string;
  storage_url: string | null;
  created_at: string;
  last_accessed_at?: string;
  uploaded_from_device?: string;
  width?: number;
  height?: number;
  duration_seconds?: number;
  access_count?: number;
  is_favorited?: boolean;
};

export type SortOption = 'newest' | 'oldest' | 'name_asc' | 'name_desc' | 'size_desc' | 'size_asc';

export type TrashRecord = {
  id: string;
  user_id: string;
  original_file_id: string;
  name: string;
  size: number;
  mime_type: string;
  category: 'photos' | 'videos' | 'documents' | 'music' | 'other';
  storage_path: string;
  storage_url: string | null;
  created_at: string;
  deleted_at: string;
};

export type FileStats = {
  total_size: number;
  total_count: number;
  by_category: Record<string, { count: number; size: number }>;
};

export type TrashCleanupSetting = 0 | 30 | 60 | 90;

export function getCategory(mimeType: string): FileRecord['category'] {
  if (mimeType.startsWith('image/')) return 'photos';
  if (mimeType.startsWith('video/')) return 'videos';
  if (mimeType.startsWith('audio/')) return 'music';
  if (
    mimeType.includes('pdf') ||
    mimeType.includes('word') ||
    mimeType.includes('excel') ||
    mimeType.includes('powerpoint') ||
    mimeType.includes('spreadsheet') ||
    mimeType.includes('presentation') ||
    mimeType.startsWith('text/')
  ) return 'documents';
  return 'other';
}

export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const gb = bytes / 1_073_741_824;
  if (gb >= 1) return gb.toFixed(1) + ' GB';
  const mb = bytes / 1_048_576;
  if (mb >= 1) return mb.toFixed(1) + ' MB';
  return (bytes / 1024).toFixed(0) + ' KB';
}

export function formatDuration(seconds: number): string {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  if (hrs > 0) {
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function getDeviceInfo(): string {
  if (Platform.OS === 'web') {
    const ua = typeof navigator !== 'undefined' ? navigator.userAgent : 'Web Browser';
    if (ua.includes('Mobile')) return 'Mobile Web';
    if (ua.includes('Tablet')) return 'Tablet Web';
    return 'Desktop Web';
  }
  return `${Platform.OS} ${Platform.Version}`;
}

export async function uploadFile(options: {
  uri: string;
  name: string;
  mimeType: string;
  size: number;
  userId: string;
  width?: number;
  height?: number;
  duration?: number;
}): Promise<{ success: boolean; error?: string; file?: FileRecord }> {
  const { uri, name, mimeType, size, userId, width, height, duration } = options;
  const timestamp = Date.now();
  const safeFileName = name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const storagePath = `${userId}/${timestamp}-${safeFileName}`;

  try {
    let uploadData: Blob | ArrayBuffer;

    if (Platform.OS === 'web') {
      const response = await fetch(uri);
      uploadData = await response.blob();
    } else {
      const response = await fetch(uri);
      uploadData = await response.blob();
    }

    const { error: uploadError } = await supabase.storage
      .from('user-files')
      .upload(storagePath, uploadData, {
        contentType: mimeType,
        upsert: false,
      });

    if (uploadError) {
      return { success: false, error: uploadError.message };
    }

    // Get signed URL (valid 30 days)
    const { data: urlData } = await supabase.storage
      .from('user-files')
      .createSignedUrl(storagePath, 60 * 60 * 24 * 30);

    const category = getCategory(mimeType);
    const deviceInfo = getDeviceInfo();

    const { data: fileRecord, error: dbError } = await supabase
      .from('files')
      .insert({
        user_id: userId,
        name,
        size,
        mime_type: mimeType,
        category,
        storage_path: storagePath,
        storage_url: urlData?.signedUrl ?? null,
        uploaded_from_device: deviceInfo,
        width: width ?? null,
        height: height ?? null,
        duration_seconds: duration ?? null,
        access_count: 0,
      })
      .select()
      .single();

    if (dbError) {
      // Clean up storage if DB insert fails
      await supabase.storage.from('user-files').remove([storagePath]);
      return { success: false, error: dbError.message };
    }

    // Manually update storage_used in profile
    await updateStorageUsed(userId, size);

    return { success: true, file: fileRecord as FileRecord };
  } catch (err: any) {
    return { success: false, error: err.message ?? 'Upload failed' };
  }
}

// Move file to trash (soft delete)
export async function deleteFile(file: FileRecord): Promise<{ success: boolean; error?: string }> {
  try {
    // Insert into trash_bin
    const { error: trashError } = await supabase
      .from('trash_bin')
      .insert({
        user_id: file.user_id,
        original_file_id: file.id,
        name: file.name,
        size: file.size,
        mime_type: file.mime_type,
        category: file.category,
        storage_path: file.storage_path,
        storage_url: file.storage_url,
        created_at: file.created_at,
        deleted_at: new Date().toISOString(),
      });

    if (trashError) {
      console.error('Trash insert error:', trashError);
      return { success: false, error: trashError.message };
    }

    // Delete from files table
    const { error: deleteError } = await supabase
      .from('files')
      .delete()
      .eq('id', file.id);

    if (deleteError) {
      console.error('Files delete error:', deleteError);
      // Try to rollback trash insert
      await supabase.from('trash_bin').delete().eq('original_file_id', file.id);
      return { success: false, error: deleteError.message };
    }

    // Manually decrease storage_used
    await updateStorageUsed(file.user_id, -file.size);

    return { success: true };
  } catch (err: any) {
    console.error('Delete exception:', err);
    return { success: false, error: err.message ?? 'Delete failed' };
  }
}

// List files in trash
export async function listTrash(userId: string): Promise<TrashRecord[]> {
  const { data, error } = await supabase
    .from('trash_bin')
    .select('*')
    .eq('user_id', userId)
    .order('deleted_at', { ascending: false });

  if (error || !data) return [];
  return data as TrashRecord[];
}

// Restore file from trash
export async function restoreFromTrash(trashItem: TrashRecord): Promise<{ success: boolean; error?: string }> {
  try {
    // Insert back into files table
    const { error: insertError } = await supabase
      .from('files')
      .insert({
        user_id: trashItem.user_id,
        name: trashItem.name,
        size: trashItem.size,
        mime_type: trashItem.mime_type,
        category: trashItem.category,
        storage_path: trashItem.storage_path,
        storage_url: trashItem.storage_url,
        created_at: trashItem.created_at,
      });

    if (insertError) {
      return { success: false, error: insertError.message };
    }

    // Delete from trash
    const { error: deleteError } = await supabase
      .from('trash_bin')
      .delete()
      .eq('id', trashItem.id);

    if (deleteError) {
      return { success: false, error: deleteError.message };
    }

    // Manually increase storage_used
    await updateStorageUsed(trashItem.user_id, trashItem.size);

    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message ?? 'Restore failed' };
  }
}

// Permanently delete file from trash (removes from storage too)
export async function permanentDelete(trashItem: TrashRecord): Promise<{ success: boolean; error?: string }> {
  try {
    // Delete from storage
    await supabase.storage.from('user-files').remove([trashItem.storage_path]);

    // Delete from trash_bin
    const { error } = await supabase
      .from('trash_bin')
      .delete()
      .eq('id', trashItem.id);

    if (error) return { success: false, error: error.message };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message ?? 'Permanent delete failed' };
  }
}

// Empty entire trash
export async function emptyTrash(userId: string): Promise<{ success: boolean; error?: string; count?: number }> {
  try {
    // Get all trash items for user
    const { data: trashItems, error: listError } = await supabase
      .from('trash_bin')
      .select('id, storage_path')
      .eq('user_id', userId);

    if (listError || !trashItems) {
      return { success: false, error: listError?.message ?? 'Failed to list trash' };
    }

    // Delete from storage
    const paths = trashItems.map(t => t.storage_path);
    if (paths.length > 0) {
      await supabase.storage.from('user-files').remove(paths);
    }

    // Delete all from trash_bin
    const { error: deleteError } = await supabase
      .from('trash_bin')
      .delete()
      .eq('user_id', userId);

    if (deleteError) {
      return { success: false, error: deleteError.message };
    }

    return { success: true, count: trashItems.length };
  } catch (err: any) {
    return { success: false, error: err.message ?? 'Empty trash failed' };
  }
}

// Get/Set trash cleanup setting
export async function getTrashCleanupSetting(userId: string): Promise<TrashCleanupSetting> {
  const { data } = await supabase
    .from('user_preferences')
    .select('trash_auto_cleanup_days')
    .eq('user_id', userId)
    .maybeSingle();

  return (data?.trash_auto_cleanup_days ?? 30) as TrashCleanupSetting;
}

export async function setTrashCleanupSetting(userId: string, days: TrashCleanupSetting): Promise<boolean> {
  const { error } = await supabase
    .from('user_preferences')
    .upsert({
      user_id: userId,
      trash_auto_cleanup_days: days,
      updated_at: new Date().toISOString(),
    });

  return !error;
}

export async function listFiles(userId: string, category?: string, limit?: number): Promise<FileRecord[]> {
  let query = supabase
    .from('files')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (category) {
    query = query.eq('category', category);
  }
  if (limit) {
    query = query.limit(limit);
  }

  const { data, error } = await query;
  if (error || !data) return [];
  return data as FileRecord[];
}

export async function listFavorites(userId: string): Promise<FileRecord[]> {
  const { data, error } = await supabase
    .from('files')
    .select('*')
    .eq('user_id', userId)
    .eq('is_favorited', true)
    .order('created_at', { ascending: false });
  if (error || !data) return [];
  return data as FileRecord[];
}

export async function toggleFavorite(fileId: string, isFavorited: boolean): Promise<boolean> {
  const { error } = await supabase
    .from('files')
    .update({ is_favorited: !isFavorited })
    .eq('id', fileId);
  return !error;
}

export function sortFiles(files: FileRecord[], sort: SortOption): FileRecord[] {
  const arr = [...files];
  switch (sort) {
    case 'newest': return arr.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    case 'oldest': return arr.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
    case 'name_asc': return arr.sort((a, b) => a.name.localeCompare(b.name));
    case 'name_desc': return arr.sort((a, b) => b.name.localeCompare(a.name));
    case 'size_desc': return arr.sort((a, b) => b.size - a.size);
    case 'size_asc': return arr.sort((a, b) => a.size - b.size);
    default: return arr;
  }
}

// Track file access (call when viewing a file)
export async function trackFileAccess(fileId: string): Promise<void> {
  await supabase
    .from('files')
    .update({
      last_accessed_at: new Date().toISOString(),
      access_count: supabase.rpc('increment_access_count', { fid: fileId }),
    })
    .eq('id', fileId);
}

// Get signed URL for viewing
export async function getFileUrl(storagePath: string): Promise<string | null> {
  const { data } = await supabase.storage
    .from('user-files')
    .createSignedUrl(storagePath, 60 * 60 * 24 * 7);
  return data?.signedUrl ?? null;
}

export async function getFileStats(userId: string): Promise<FileStats> {
  const { data } = await supabase
    .from('files')
    .select('size, category')
    .eq('user_id', userId);

  const stats: FileStats = {
    total_size: 0,
    total_count: 0,
    by_category: {
      photos: { count: 0, size: 0 },
      videos: { count: 0, size: 0 },
      documents: { count: 0, size: 0 },
      music: { count: 0, size: 0 },
      other: { count: 0, size: 0 },
    },
  };

  for (const row of (data ?? [])) {
    stats.total_size += row.size;
    stats.total_count += 1;
    const cat = row.category as string;
    if (stats.by_category[cat]) {
      stats.by_category[cat].count += 1;
      stats.by_category[cat].size += row.size;
    }
  }

  return stats;
}

// Update profile storage_used field manually (since trigger may not work)
async function updateStorageUsed(userId: string, deltaBytes: number): Promise<void> {
  try {
    const { data: profile } = await supabase
      .from('profiles')
      .select('storage_used')
      .eq('id', userId)
      .single();

    const currentStorage = profile?.storage_used ?? 0;
    const newStorage = Math.max(0, currentStorage + deltaBytes);

    await supabase
      .from('profiles')
      .update({ storage_used: newStorage })
      .eq('id', userId);
  } catch (err) {
    console.error('Failed to update storage_used:', err);
  }
}

// Refresh a signed URL if it has expired
export async function refreshSignedUrl(storagePath: string): Promise<string | null> {
  const { data } = await supabase.storage
    .from('user-files')
    .createSignedUrl(storagePath, 60 * 60 * 24 * 7);
  return data?.signedUrl ?? null;
}
